"""Package T (stochastic model): latency sweep, student on the matched-information critic, label budget,
distribution shift. Runs on the outputs of evalS.py (same RESULTS_S folder, same critics and labels).
Usage: STOCH=1 DUAL_LANE=1 DUAL_MODE=hold CRITIC_NODIST=1 N_LANES=L RESULTS_S=dir python evalT.py SEED MODE
MODE: lat | acc | budget | shift. Writes RESULTS_S/T_{MODE}_s{SEED}.pkl (resumable by method).
  lat:    deployable Monte-Carlo gate (4 and 16 samples) and band cascade with a query delay of K samples,
          K in {0,1,2,4,7} (K = ceil(query time / 0.1 s)); shows where run-time simulation would beat the student.
  acc:    the whole student pipeline (labels, on-policy round, student, privileged reference) on top of the critic
          that also sees the measured leader accelerations (same information as the student).
  budget: students trained on 1/16 ... 1 of the labels (offline teacher simulation vs. test return).
  shift:  test traffic with more hard braking (ST_PBRAKE=0.4) and noisier targets (ST_SIG=1.0), everything trained on
          the nominal traffic; returns and the realized episode-loss rates of the certified candidates.
"""
import sys, os, time, pickle, json
import numpy as np
from config import Cfg
from env import Env
from nn import MLP
from hl import metrics
from hl3 import run3, make_rule_greedy3, make_rule_stay_then
from stochhl import GateS, labels_to_arrays, train_models
from evalS import sets, make_rule_greedy_acc

RS = os.environ.get('RESULTS_S', os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, 'results_s'))
N_LAB = int(os.environ.get('N_LAB', 2048)); N_DAG = int(os.environ.get('N_DAG', 1024)); N_CAL = int(os.environ.get('N_CAL', 500))
N_VAL = int(os.environ.get('N_VAL', 300))


def main(seed, mode):
    c = Cfg(); assert c.stoch
    t0 = time.time(); log = lambda *a: print(f'[{time.time()-t0:7.1f}s]', *a, flush=True)
    fname = f'{RS}/T_{mode}_s{seed}.pkl'
    out = pickle.load(open(fname, 'rb')) if os.path.exists(fname) else dict(seed=seed, mode=mode, test={}, stats={})
    save = lambda: pickle.dump(out, open(fname, 'wb'))
    actor = MLP.load(f'{RS}/ppo_s{seed}/actor.pkl')
    q = MLP.load(f'{RS}/dqnS_c010_s{seed}/q.pkl'); qa = MLP.load(f'{RS}/dqnS_acc_s{seed}/q.pkl')
    ev = pickle.load(open(f'{RS}/evalS_s{seed}.pkl', 'rb'))
    F, test, load_set, Smp = sets(c)
    D = {k: np.concatenate([ev['labels0'][k], ev['labels1'][k]]) for k in ev['labels0']}
    tau, delta = ev['tuned']['tau'], ev['tuned']['delta']

    def env_of(scen):
        e = Env(c, len(scen)); load_set(e, scen); e.done[:] = False; return e

    def env_smp(sd, n):
        e = Env(c, n); Smp(c, sd).reset_rows(e, range(n)); e.done[:] = False; return e

    def run_on(rule, src):
        e = src.subset(np.arange(src.B)); e.done[:] = False
        return e, run3(e, actor, rule, c)

    def test_all(name, mk):
        if name in out['test'] and len(out['test'][name]) == len(F):
            return
        out['test'][name] = {}; out['stats'][name] = {}
        for f in F:
            rule = mk(); e = env_of(test[f]); res = run3(e, actor, rule, c); m = metrics(e, res)
            out['test'][name][f] = {k: m[k] for k in ('G', 'n_sw', 'n_cut_hard', 'min_front', 'min_rear', 'collided', 'fail')}
            st = getattr(rule, 'st', None); n = len(test[f])
            out['stats'][name][f] = dict(queries=st.queries / n, steps=st.sim_steps / n, late_drop=st.late_drop / n) if st else {}
        G = np.concatenate([out['test'][name][f]['G'] for f in F])
        log(name, f'G={G.mean():.2f}', f"queries/ep={np.mean([out['stats'][name][f].get('queries', 0) for f in F]):.2f}")
        save()

    if mode == 'lat':
        student, router, _ = train_models(D, seed)
        test_all('critic', lambda: make_rule_greedy3(q))
        test_all('student', lambda: GateS(q, actor, c, 'student', student=student, tau=tau))
        for K in [0, 1, 2, 4, 7]:
            test_all(f'mc4_K{K}', lambda K=K: GateS(q, actor, c, 'mc', M=4, lat_k=K))
            test_all(f'band_K{K}', lambda K=K: GateS(q, actor, c, 'band', student=student, delta=delta, lat_k=K))
        for K in [0, 1, 4]:
            test_all(f'mc16_K{K}', lambda K=K: GateS(q, actor, c, 'mc', M=16, lat_k=K))
    elif mode == 'acc':
        base = make_rule_greedy_acc(qa)
        def label(act, student, n, sd):
            g = GateS(qa, actor, c, 'label', act=act, student=student, base=base)
            B = 64; e = Env(c, B); s = Smp(c, sd)
            for k in range(max(1, n // B)):
                s.reset_rows(e, range(B)); e.done[:] = False; run3(e, actor, g, c)
            return g.rec
        if 'labels0' not in out:
            out['labels0'] = labels_to_arrays(label('priv', None, N_LAB, 70_000 + seed)); save(); log('labels0', len(out['labels0']['g']))
        s0, _, _ = train_models(out['labels0'], seed)
        if 'labels1' not in out:
            rec = label('student', s0, N_DAG, 90_000 + seed)
            out['labels1'] = labels_to_arrays(rec) if rec else {k: v[:0] for k, v in out['labels0'].items()}; save(); log('labels1', len(out['labels1']['g']))
        Da = {k: np.concatenate([out['labels0'][k], out['labels1'][k]]) for k in out['labels0']}
        sa, _, _ = train_models(Da, seed)
        if 'tau' not in out:
            venv = env_smp(55_555, N_VAL)
            tv = {t: float(run_on(GateS(qa, actor, c, 'student', student=sa, tau=t, base=base), venv)[1]['G'].mean()) for t in [-1.0, 0.0, 1.0]}
            out['tau'] = max(tv, key=tv.get); out['tau_val'] = tv; save()
        test_all('critic', lambda: make_rule_greedy3(q))
        test_all('critic_acc', lambda: base)
        test_all('student_acc', lambda: GateS(qa, actor, c, 'student', student=sa, tau=out['tau'], base=base))
        test_all('student_acc_r0', lambda: GateS(qa, actor, c, 'student', student=s0, tau=0.0, base=base))
        test_all('priv16_acc', lambda: GateS(qa, actor, c, 'priv', M=16, base=base))
    elif mode == 'budget':
        test_all('critic', lambda: make_rule_greedy3(q))
        rng = np.random.default_rng(seed + 5); n = len(D['g']); perm = rng.permutation(n)
        out['n_labels'] = int(n)
        for frac in [1 / 16, 1 / 8, 1 / 4, 1 / 2, 1.0]:
            idx = np.sort(perm[:max(20, int(frac * n))]); Dk = {k: v[idx] for k, v in D.items()}
            sk, _, _ = train_models(Dk, seed)
            test_all(f'student_f{frac:g}', lambda sk=sk: GateS(q, actor, c, 'student', student=sk, tau=0.0))
    elif mode == 'shift':
        assert c.st_pbrake != 0.2 or c.st_sig != 0.6, 'run with shifted ST_PBRAKE / ST_SIG'
        student, router, _ = train_models(D, seed)
        test_all('critic', lambda: make_rule_greedy3(q))
        test_all('critic_acc', lambda: make_rule_greedy_acc(qa))
        test_all('student', lambda: GateS(q, actor, c, 'student', student=student, tau=tau))
        test_all('priv16', lambda: GateS(q, actor, c, 'priv', M=16))
        test_all('never_change', lambda: make_rule_stay_then(make_rule_greedy3(q)))   # pi_s for reference
        if 'loss' not in out:
            cal = env_smp(124_000 + seed, N_CAL)
            Gb = run_on(make_rule_greedy3(q), cal)[1]['G']; Gs = run_on(make_rule_stay_then(make_rule_greedy3(q)), cal)[1]['G']
            W = np.maximum(Gb, Gs); Lr = {}
            for nm, mk in {'student': lambda: GateS(q, actor, c, 'student', student=student, tau=tau)}.items():
                Gp = run_on(mk(), cal)[1]['G']; Lr[nm] = np.maximum(W - Gp, 0.0)
            out['loss'] = dict(L=Lr, eps={e: {k: float(np.mean(v > e)) for k, v in Lr.items()} for e in [1.0, 2.0, 5.0]}); save()
            log('shifted loss rates', json.dumps(out['loss']['eps']))
    save(); log('saved', fname)


if __name__ == '__main__':
    main(int(sys.argv[1]), sys.argv[2])
