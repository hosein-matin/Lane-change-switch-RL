#!/usr/bin/env python3
"""Parallel, resumable runner for the stochastic experiments of the paper: package V (uncertainty sweep, margin baseline,
validated switching cost, larger label budget), packages W, W2 and Z (information split: Vpost, Vpost2, Zpost3 jobs),
package X (kernel filter and terminal-safe guards: Xfilt jobs) and package Y (frozen policies, stale-state sensitivity,
decision-charge audit: Yfix, Ylat, Yaudit jobs). Self-contained (bundled longitudinal controllers).

    python runV.py --lanes 2 --cores 16          # two lanes (results_v2)
    python runV.py --lanes 3 --cores 16          # three lanes (results_v3)
    python runV.py --lanes 2 --status            # progress
    python runV.py --lanes 2 --smoke --cores 4   # short end-to-end test (smoke_v2)

The longitudinal controllers are reused from the earlier runs (bundled in ppo2/ and ppo3/). Every job writes its
log to <results>/logs/<job>.log and, on success, a marker <results>/.done/<job>; re-running the same command
resumes. A progress summary is rewritten every minute to <results>/status.txt.
"""
import argparse, os, subprocess, sys, time, json, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, 'code')
SEEDS_ALL = list(range(10))
HEAVY = ['mc1', 'mc4', 'mc16', 'mc4_nolat', 'priv16', 'rollall4']


LEVELS = [0.0, 0.5, 1.0, 2.0]


def level_env(u):
    return dict(ST_SIG=f'{0.6 * u:g}', ST_PBRAKE=f'{min(0.2 * u, 0.6):g}')


def build_jobs(R, lanes, smoke=False):
    """Uncertainty sweep u in LEVELS (leader target noise 0.6u A, hard-braking probability 0.2u), 10 seeds per level and
    10 more at u = 1; validated switching cost and a 4x label budget at u = 1."""
    ep = '96' if smoke else '6400'
    J = {}
    base_env = dict(STOCH='1', DUAL_LANE='1', DUAL_MODE='hold', CRITIC_NODIST='1', N_LANES=str(lanes))
    if smoke:
        base_env.update(N_TEST='3', N_VAL='12', N_LAB='64', N_DAG='64', N_CAL='20')

    def job(name, cmd, deps=(), env=None, prio=0):
        e = dict(base_env); e.update(env or {})
        J[name] = dict(cmd=[sys.executable] + cmd, deps=list(deps), env=e, prio=prio)

    levels = [0.0, 1.0] if smoke else LEVELS
    for u in levels:
        Ru = os.path.join(R, f'u{u:g}'); le = dict(level_env(u), RESULTS_V=Ru)
        seeds = [7] if smoke else (list(range(20)) if u == 1.0 else list(range(10)))
        for s in seeds:
            S = str(s); act = f'{Ru}/ppo_s{s}/actor.pkl'
            job(f'dqnV_u{u:g}_c010_s{s}', ['dqnS.py', S, act, ep, f'{Ru}/dqnV_c010_s{s}'], [], dict(le, C0_TRAIN='10'), prio=90 if u == 1.0 else 85)
            job(f'V_u{u:g}_s{s}', ['evalV.py', S, 'sweep'], [f'dqnV_u{u:g}_c010_s{s}'], le, prio=80 if u == 1.0 else 75)
            if u == 1.0 and (smoke or s < 10):
                for c0 in ['5', '14']:
                    job(f'dqnV_u1_c0{c0}_s{s}', ['dqnS.py', S, act, ep, f'{Ru}/dqnV_c0{c0}_s{s}'], [], dict(le, C0_TRAIN=c0), prio=50)
                job(f'Vc0_u1_s{s}', ['evalV.py', S, 'c0'], [f'dqnV_u1_c010_s{s}', f'dqnV_u1_c05_s{s}', f'dqnV_u1_c014_s{s}'], le, prio=45)
                job(f'Vbig_u1_s{s}', ['evalV.py', S, 'big'], [f'dqnV_u1_c010_s{s}'], le, prio=40)
            if u in (0.0, 1.0, 2.0) and (smoke or s < 10):
                job(f'Vpost_u{u:g}_s{s}', ['evalV.py', S, 'post'], [f'dqnV_u{u:g}_c010_s{s}'], le, prio=30)
                job(f'Vpost2_u{u:g}_s{s}', ['evalV.py', S, 'post2'], [f'dqnV_u{u:g}_c010_s{s}'], le, prio=25)
                job(f'Zpost3_u{u:g}_s{s}', ['evalV.py', S, 'post3'], [f'dqnV_u{u:g}_c010_s{s}'], le, prio=24)
            if u == 1.0 and (smoke or s < 10):
                # package X: filters and guards of Theorems 1-2 with the frozen policies of V_u1_s{s}
                for fm, gm in [('base', 'hold'), ('kernel', 'hold'), ('kernel', 'const'), ('kernel', 'two')]:
                    job(f'Xfilt_{fm}_{gm}_s{s}', ['evalV.py', S, 'filt'], [f'dqnV_u1_c010_s{s}'], dict(le, FILTER_MODE=fm, GUARD_MODE=gm), prio=20)
                # package Y: high-budget decision-charge audit and sensing latency (frozen nu = 1 policies)
                job(f'Yaudit_s{s}', ['evalV.py', S, 'audit'], [f'dqnV_u1_c010_s{s}'], le, prio=16)
                for j in (1, 3, 5):
                    job(f'Ylat_j{j}_s{s}', ['evalV.py', S, 'lat'], [f'dqnV_u1_c010_s{s}'], dict(le, SENSE_LAG=str(j)), prio=15)
            if u in (0.0, 0.5, 2.0) and (smoke or s < 10):
                # package Y: the nu = 1 policies, frozen, in the traffic of level u
                job(f'Yfix_u{u:g}_s{s}', ['evalV.py', S, 'fixed'], [f'dqnV_u1_c010_s{s}'], le, prio=14)
    return J


def done_dir(R):
    d = os.path.join(R, '.done'); os.makedirs(d, exist_ok=True); return d


def is_done(R, name):
    return os.path.exists(os.path.join(done_dir(R), name))


def status(R, J, running=None, failed=None):
    n = len(J); d = sum(is_done(R, k) for k in J)
    lines = [time.strftime('%Y-%m-%d %H:%M:%S'), f'done {d}/{n}']
    if running:
        lines.append('running: ' + ', '.join(f'{k} ({(time.time()-t)/60:.0f} min)' for k, (_, t, _) in running.items()))
    if failed:
        lines.append('FAILED (see logs/<job>.log): ' + ', '.join(sorted(failed)))
    blocked = [k for k in J if not is_done(R, k) and failed and any(x in failed for x in J[k]['deps'])]
    if blocked:
        lines.append(f'blocked by failures: {len(blocked)} jobs')
    txt = '\n'.join(lines)
    open(os.path.join(R, 'status.txt'), 'w').write(txt + '\n')
    return txt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cores', type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument('--lanes', type=int, choices=[2, 3], required=True)
    ap.add_argument('--results', default=None)
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--smoke', action='store_true')
    ap.add_argument('--only', default=None, help='run only jobs whose name contains this text (and their dependencies)')
    a = ap.parse_args()
    R = os.path.abspath(a.results or os.path.join(HERE, f'results_v{a.lanes}'))
    if a.smoke:
        R = os.path.join(HERE, f'smoke_v{a.lanes}')
    os.makedirs(R, exist_ok=True)
    J = build_jobs(R, a.lanes, a.smoke)
    # longitudinal controllers of the earlier runs (seed s uses controller s mod 10)
    for k, jb in J.items():
        Ru = jb['env']['RESULTS_V']; s = int(k.rsplit('_s', 1)[1])
        dst = os.path.join(Ru, f'ppo_s{s}')
        if not os.path.exists(os.path.join(dst, 'actor.pkl')):
            shutil.copytree(os.path.join(HERE, f'ppo{a.lanes}', f'ppo_s{s % 10}'), dst, dirs_exist_ok=True)
    if a.only:
        need = set(k for k in J if a.only in k)
        stack = list(need)
        while stack:
            for d in J[stack.pop()]['deps']:
                if d not in need:
                    need.add(d); stack.append(d)
        J = {k: v for k, v in J.items() if k in need}
    for d in [R, os.path.join(R, 'logs')]:
        os.makedirs(d, exist_ok=True)
    if a.status:
        print(status(R, J)); return
    print(f'{len(J)} jobs, {sum(is_done(R, k) for k in J)} already done, {a.cores} parallel workers; results in {R}', flush=True)
    running, failed = {}, set()
    last = 0
    try:
        while True:
            for k, (p, t0, lf) in list(running.items()):
                rc = p.poll()
                if rc is None:
                    continue
                lf.close(); del running[k]
                if rc == 0:
                    open(os.path.join(done_dir(R), k), 'w').write(time.strftime('%Y-%m-%d %H:%M:%S'))
                    print(f'[{time.strftime("%H:%M:%S")}] done   {k} ({(time.time()-t0)/60:.1f} min)', flush=True)
                else:
                    failed.add(k)
                    print(f'[{time.strftime("%H:%M:%S")}] FAILED {k} (exit {rc}), see {R}/logs/{k}.log', flush=True)
            todo = [k for k in J if not is_done(R, k) and k not in running and k not in failed]
            if not todo and not running:
                break
            ready = [k for k in todo if all(is_done(R, d) for d in J[k]['deps'])]
            ready.sort(key=lambda k: -J[k]['prio'])
            while ready and len(running) < a.cores:
                k = ready.pop(0)
                env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                           PYTHONUNBUFFERED='1', **J[k]['env'])
                lf = open(os.path.join(R, 'logs', f'{k}.log'), 'a')
                lf.write(f'\n===== start {time.strftime("%Y-%m-%d %H:%M:%S")}\n'); lf.flush()
                p = subprocess.Popen(J[k]['cmd'], cwd=CODE, env=env, stdout=lf, stderr=subprocess.STDOUT)
                running[k] = (p, time.time(), lf)
                print(f'[{time.strftime("%H:%M:%S")}] start  {k}', flush=True)
            if not running and not ready:
                break   # everything left is blocked by a failure
            if time.time() - last > 60:
                status(R, J, running, failed); last = time.time()
            time.sleep(2)
    except KeyboardInterrupt:
        print('\nInterrupted: stopping running jobs (they will restart next time).', flush=True)
        for k, (p, _, lf) in running.items():
            p.terminate()
        for k, (p, _, lf) in running.items():
            try:
                p.wait(10)
            except Exception:
                p.kill()
            lf.close()
    print(status(R, J, {}, failed), flush=True)
    if failed:
        sys.exit(1)


if __name__ == '__main__':
    main()
