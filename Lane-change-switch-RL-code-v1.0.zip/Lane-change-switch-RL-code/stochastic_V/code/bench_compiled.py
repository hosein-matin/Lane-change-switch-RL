"""Benchmark B: cost of one compiled rollout of the lane-selection model as a function of the number of vehicles and
the horizon (Numba). Same per-step work as the simulator used in the paper: OVM followers (each follows its
predecessor in its lane, the ego where it is the predecessor), leaders tracking random target speeds with clipped
acceleration, ego through the held-input filter (front and rear m-function terms) with the PPO actor (10-64-64-1,
evaluated every sample), and the lane-selection critic (26-128-128-3) at every decision epoch, n_sub = 10 substeps.
Usage: pip install numba; python bench_compiled.py [ACTOR_PKL]   ->  bench_compiled.json
"""
import sys, json, time, pickle, platform
import numpy as np
from numba import njit


@njit(cache=True)
def mlp(x, W0, b0, W1, b1, W2, b2):
    h = np.tanh(x @ W0 + b0)
    h = np.tanh(h @ W1 + b1)
    return h @ W2 + b2


@njit(cache=True)
def m_fun(H, D, T):
    if H <= 0.0 and D < 0.0:
        return -1e9
    if H > 0.0 and D < 0.0 and -2.0 * H / D <= T:
        return -D * D / (2.0 * H)
    return 2.0 * (H + D * T) / (T * T)


@njit(cache=True)
def ovm(d, vmax):
    t0 = np.tanh(15.0 / 8.0)
    dd = d if d > 0.0 else 0.0
    return vmax * (np.tanh((dd - 15.0) / 8.0) + t0) / (1.0 + t0)


@njit(cache=True)
def rollout(x, v, lane, alpha, fvmax, tgt, b, L, H, seed, A0, A1, A2, A3, A4, A5, C0, C1, C2, C3, C4, C5):
    """x, v, lane, alpha, fvmax: arrays for N vehicles (index 0 = ego); returns the return of one rollout."""
    np.random.seed(seed)
    N = x.shape[0]; dt = 0.1; nsub = 10; h = dt / nsub
    steps = int(H / dt); G = 0.0; eta = 0.0
    obs = np.zeros(10); cobs = np.zeros(26)
    for n in range(steps):
        # neighbours of the ego in its lane (linear scan)
        lead = -1; foll = -1; dl = 1e9; df = 1e9
        for i in range(1, N):
            if lane[i] == lane[0]:
                d = x[i] - x[0]
                if d > 0 and d < dl:
                    dl = d; lead = i
                if d < 0 and -d < df:
                    df = -d; foll = i
        Hp = dl - 7.0; Dp = (v[lead] - v[0]) if lead >= 0 else 0.0
        Hm = df - 7.0; Dm = (v[0] - v[foll]) if foll >= 0 else 0.0
        hi = min(2.5, -b + m_fun(Hp, Dp, dt)); lo = max(-6.0, 2.5 - m_fun(Hm, Dm, dt))
        obs[0] = v[0] / 20.0; obs[1] = Hp / 50.0; obs[2] = Dp / 10.0; obs[3] = Hm / 50.0; obs[4] = Dm / 10.0
        obs[5] = -b / 3.0; obs[6] = 0.8; obs[7] = lo / 6.0; obs[8] = hi / 6.0; obs[9] = 1.0 - n / steps
        a = mlp(obs, A0, A1, A2, A3, A4, A5)[0]
        uc = -6.0 + 0.5 * (min(max(a, -1.0), 1.0) + 1.0) * 8.5
        u = min(max(uc, lo), hi) if lo <= hi else lo
        # lane-selection critic at the decision epoch (every sample while staying)
        for k in range(26):
            cobs[k] = obs[k % 10]
        qv = mlp(cobs, C0, C1, C2, C3, C4, C5)
        eta += dt
        if eta > 2.0 and qv[1] > qv[0] + 1.0 and lane[0] < L - 1:
            lane[0] += 1; eta = 0.0
        # predecessor of every vehicle in its lane, once per sample (sort by lane, then position): O(N log N)
        order = np.argsort(lane * 1e6 + x)
        pred = -np.ones(N, np.int64)
        for k in range(N - 1):
            i = order[k]; j = order[k + 1]
            if lane[i] == lane[j]:
                pred[i] = j
        # physics substeps
        for s in range(nsub):
            for i in range(1, N):
                p = pred[i]
                dp = x[p] - x[i] if p >= 0 else 1e9
                if p < 0:      # lane head: tracks a random target speed
                    if np.random.random() < h / 1.5:
                        tgt[i] = v[i] + np.random.uniform(-2.0, 2.0)
                    acc = min(max(tgt[i] - v[i], -b), b)
                else:
                    acc = min(max(alpha[i] * (ovm(dp - 5.0, fvmax[i]) - v[i]), -7.0), 2.5)
                x[i] += v[i] * h + 0.5 * acc * h * h; v[i] = max(v[i] + acc * h, 0.0)
            x[0] += v[0] * h + 0.5 * u * h * h; v[0] = max(v[0] + u * h, 0.0)
        G += (x[0]) * 0.0 + v[0] * dt - u * u * dt
    return G


def main():
    rng = np.random.default_rng(0)
    if len(sys.argv) > 1:
        d = pickle.load(open(sys.argv[1], 'rb')); A = [d['W'][0], d['b'][0], d['W'][1], d['b'][1], d['W'][2], d['b'][2]]
    else:
        A = [rng.normal(size=(10, 64)), np.zeros(64), rng.normal(size=(64, 64)), np.zeros(64), rng.normal(size=(64, 1)), np.zeros(1)]
    A = [np.ascontiguousarray(a, dtype=np.float64) for a in A]
    C = [rng.normal(size=(26, 128)) * 0.1, np.zeros(128), rng.normal(size=(128, 128)) * 0.1, np.zeros(128), rng.normal(size=(128, 3)) * 0.1, np.zeros(3)]
    out = dict(machine=platform.platform(), processor=platform.processor(), results=[])
    for L in [2, 3]:
        for N in [3 if L == 2 else 4, 5, 7, 10, 20, 40, 80]:
            if N < 2 * L + 1 and N not in (5, 7):
                pass
            for H in [5.0, 15.0, 30.0]:
                def state():
                    lane = np.array([0] + [i % L for i in range(N - 1)], dtype=np.int64)
                    x = np.zeros(N); v = np.full(N, 12.0)
                    for k in range(L):
                        idx = np.where(lane[1:] == k)[0] + 1
                        for m, i in enumerate(idx):
                            x[i] = (m - len(idx) // 2 + 0.5) * 25.0
                    x[0] = 0.0
                    return x, v, lane, rng.uniform(0.5, 1.1, N), rng.uniform(15, 20, N), np.full(N, 12.0)
                s = state(); rollout(*[a.copy() for a in s], 1.0, L, H, 1, *A, *C)      # compile
                reps = 200 if N <= 20 else 50
                t0 = time.perf_counter()
                for r in range(reps):
                    s = state(); rollout(*s, 1.0, L, H, r, *A, *C)
                us = 1e6 * (time.perf_counter() - t0) / reps
                pairs = 100_000.0 / (2 * us)            # comparisons of two rollouts within 100 ms
                out['results'].append(dict(L=L, N=N, H=H, us_per_rollout=us, samples_per_100ms=pairs))
                print(f'L={L} N={N:3d} H={H:4.0f}s  {us:9.1f} us/rollout  {pairs:8.1f} two-rollout samples per 100 ms', flush=True)
    json.dump(out, open('bench_compiled.json', 'w'), indent=1)


if __name__ == '__main__':
    main()
