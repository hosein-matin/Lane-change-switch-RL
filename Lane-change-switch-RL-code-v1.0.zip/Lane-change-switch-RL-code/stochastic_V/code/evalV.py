"""Package V (stochastic model): uncertainty sweep, margin baseline, validated switching cost, larger label budget.
Usage: STOCH=1 DUAL_LANE=1 DUAL_MODE=hold CRITIC_NODIST=1 N_LANES=L ST_SIG=.. ST_PBRAKE=.. RESULTS_V=dir \
       python evalV.py SEED MODE
MODE sweep: labels (privileged, K=4; 16 deployable samples stored per proposal), on-policy round, student, router,
            margin baseline, tests (critic, margin, student, band with a 1-sample delay, privileged reference,
            deployable MC gates with 1/4/16 samples instantaneous and 4 samples with a 1-sample delay),
            offline decision-charge analysis, failure causes. Output RESULTS_V/V_s{SEED}.pkl
MODE big:   student from 4x the labels (critic c010 of this folder). Output RESULTS_V/Vbig_s{SEED}.pkl
MODE c0:    validated switching cost among the critics c02 (from c010 folder is not needed), c05, c010, c014.
"""
import sys, os, time, pickle, json, math
import numpy as np
from config import Cfg
from env import Env
from nn import MLP
from hl import metrics
from hl3 import run3, make_rule_greedy3, make_rule_stay_then
from stochhl import GateS, labels_to_arrays, train_models, feats
from hl3 import DIRS
from evalS import sets

RV = os.environ.get('RESULTS_V', os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, 'results_v'))
N_LAB = int(os.environ.get('N_LAB', 2048)); N_DAG = int(os.environ.get('N_DAG', 1024)); N_VAL = int(os.environ.get('N_VAL', 300))
N_CAL = int(os.environ.get('N_CAL', 500))
KEYS = ('G', 'n_sw', 'n_cut_hard', 'hb_time', 'jerk_rms', 'min_front', 'min_rear', 'collided', 'fail')


def make_rule_margin(q, theta, c):
    """Critic with an acceptance margin: change iff Q(change) - Q(stay) > theta (return units)."""
    def rule(env, rows, M):
        qq = np.where(M, q.forward(env.critic_obs()[rows]), -np.inf) / c.rew_scale
        best = np.argmax(np.where(np.arange(3)[None, :] > 0, qq, -np.inf), 1)
        gain = qq[np.arange(len(rows)), best] - np.where(M[:, 0], qq[:, 0], -np.inf)
        stay_ok = M[:, 0]
        return np.where(stay_ok, np.where(gain > theta, best, 0), np.argmax(qq, 1))
    return rule


def main(seed, mode):
    c = Cfg(); assert c.stoch
    t0 = time.time(); log = lambda *a: print(f'[{time.time()-t0:7.1f}s]', *a, flush=True)
    fname = f'{RV}/V{"big" if mode == "big" else "c0" if mode == "c0" else "post" if mode == "post" else "post2" if mode == "post2" else "post3" if mode == "post3" else ""}_s{seed}.pkl'
    if mode == 'filt':
        fname = f'{RV}/Vfilt_{c.filter_mode}_{c.guard_mode}_s{seed}.pkl'
    if mode in ('lat', 'fixed', 'audit'):
        fname = {'lat': f'{RV}/Vlat_j{c.sense_lag}_s{seed}.pkl', 'fixed': f'{RV}/Vfix_s{seed}.pkl', 'audit': f'{RV}/Vaudit_s{seed}.pkl'}[mode]
    out = pickle.load(open(fname, 'rb')) if os.path.exists(fname) else dict(seed=seed, mode=mode, test={}, stats={}, cfg=dict(sig=c.st_sig, pb=c.st_pbrake))
    save = lambda: pickle.dump(out, open(fname, 'wb'))
    actor = MLP.load(f'{RV}/ppo_s{seed}/actor.pkl')
    F, test, load_set, Smp = sets(c)

    def env_of(scen):
        e = Env(c, len(scen)); load_set(e, scen); e.done[:] = False; return e

    def env_smp(sd, n):
        e = Env(c, n); Smp(c, sd).reset_rows(e, range(n)); e.done[:] = False; return e

    venv = env_smp(55_555, N_VAL)

    def run_on(rule, src):
        e = src.subset(np.arange(src.B)); e.done[:] = False
        return e, run3(e, actor, rule, c)

    def test_all(name, mk):
        if name in out['test'] and len(out['test'][name]) == len(F):
            return
        out['test'][name] = {}; out['stats'][name] = {}
        for f in F:
            rule = mk(); e = env_of(test[f]); res = run3(e, actor, rule, c); m = metrics(e, res)
            d = {k: m[k] for k in KEYS}; d['fcause'] = e.fcause.copy()
            for kk in ('k_out', 'k_out0', 'k_act', 'g_rej', 'dual_fallback', 'n_steps', 'n_filter_active'):
                d[kk] = getattr(e, kk).copy()
            out['test'][name][f] = d
            st = getattr(rule, 'st', None); n = len(test[f])
            out['stats'][name][f] = dict(props=st.props / n, queries=st.queries / n, steps=st.sim_steps / n, rollouts=st.rollouts / n,
                                         late_drop=st.late_drop / n) if st else {}
        G = np.concatenate([out['test'][name][f]['G'] for f in F])
        log(name, f'G={G.mean():.2f}', f"queries/ep={np.mean([out['stats'][name][f].get('queries', 0) for f in F]):.2f}")
        save()

    def label(q, act, student, n, sd, store):
        g = GateS(q, actor, c, 'label', act=act, student=student, Mq_store=16 if store else None)
        B = 64; e = Env(c, B); s = Smp(c, sd)
        for k in range(max(1, n // B)):
            s.reset_rows(e, range(B)); e.done[:] = False; run3(e, actor, g, c)
        return g.rec

    if mode == 'c0':
        sc = {}
        for tag in ['c05', 'c010', 'c014']:
            p = f'{RV}/dqnV_{tag}_s{seed}/dqn_log.json'
            sc[tag] = json.load(open(p))['best_val']
        best = max(sc, key=sc.get); out['val'] = sc; out['best'] = best
        for tag in ['c05', 'c010', 'c014']:
            qq = MLP.load(f'{RV}/dqnV_{tag}_s{seed}/q.pkl'); test_all(f'critic_{tag}', lambda qq=qq: make_rule_greedy3(qq))
        save(); log('saved', fname, 'best', best); return

    if mode in ('lat', 'fixed', 'audit'):
        # package Y. Frozen nu = 1 critic and student (labels and validated thresholds of the sweep, V_s{seed}.pkl in u1)
        RV1 = os.path.join(os.path.dirname(RV.rstrip('/')), 'u1')
        q = MLP.load(f'{RV1}/dqnV_c010_s{seed}/q.pkl')
        src = pickle.load(open(f'{RV1}/V_s{seed}.pkl', 'rb'))
        out['cfg'].update(sense_lag=c.sense_lag, n_sub=c.n_sub, models_from='u1')
        D = {k: np.concatenate([src['labels0'][k], src['labels1'][k]]) for k in src['labels0']}
        student, router, info = train_models(D, seed)
        tau = src['tuned']['tau']; delta = src['tuned']['delta']
        if mode == 'lat':
            # sensing-to-actuation latency: the query simulates from the state c.sense_lag substeps before the decision
            # instant, the vehicle keeps its lane meanwhile, the change is executed only if admissible now
            assert c.sense_lag > 0
            test_all('mc4_K0', lambda: GateS(q, actor, c, 'mc', M=4, lat_k=0))
            test_all('band_K0', lambda: GateS(q, actor, c, 'band', student=student, delta=delta, lat_k=0))
            test_all('mc16_K0', lambda: GateS(q, actor, c, 'mc', M=16, lat_k=0))
            test_all('priv16', lambda: GateS(q, actor, c, 'priv', M=16))
        elif mode == 'fixed':
            # nu = 1 policies, frozen, in the traffic of this folder's level
            test_all('critic', lambda: make_rule_greedy3(q))
            test_all('student', lambda: GateS(q, actor, c, 'student', student=student, tau=tau))
            test_all('band_K1', lambda: GateS(q, actor, c, 'band', student=student, delta=delta, lat_k=1))
            test_all('priv16', lambda: GateS(q, actor, c, 'priv', M=16))
            test_all('mc4_K0', lambda: GateS(q, actor, c, 'mc', M=4, lat_k=0))
            test_all('mc4_K1', lambda: GateS(q, actor, c, 'mc', M=4, lat_k=1))
            test_all('mc16_K0', lambda: GateS(q, actor, c, 'mc', M=16, lat_k=0))
        else:
            # decision-charge audit: the student drives; at each of its proposals a privileged reference with K_REF
            # rollout pairs (salt 1, so its first 4 are the sweep's label samples) and 16 deployable samples are stored
            K_REF = int(os.environ.get('K_REF', '256')); N_AUD = int(os.environ.get('N_AUD', '20'))
            recs = []
            for f in F:
                if f in out.get('audit_done', []):
                    continue
                g8 = GateS(q, actor, c, 'label', student=student, tau=tau, K_label=K_REF, Mq=4, Mq_store=16, act='student')
                e = env_of(test[f][:N_AUD]); res = run3(e, actor, g8, c)
                for d in g8.rec:
                    d = dict(d); d['dec_student'] = (g8.ghat(d['X']) > tau); d['ghat'] = g8.ghat(d['X']); d['fam'] = f
                    recs.append(d)
                out.setdefault('audit', []).extend(recs); recs = []
                out.setdefault('audit_done', []).append(f); out['audit_G'] = out.get('audit_G', {}); out['audit_G'][f] = res['G']
                out['K_ref'] = K_REF; save(); log(f, 'proposals', sum(len(d['g']) for d in out['audit'] if d['fam'] == f))
        save(); log('saved', fname); return
    q = MLP.load(f'{RV}/dqnV_c010_s{seed}/q.pkl')
    if mode == 'filt':
        # package X: frozen critic / student / gates of the sweep (V_s{seed}.pkl) evaluated under the filter and guard
        # selected by FILTER_MODE / GUARD_MODE (base+hold = the sweep's own controller)
        src = pickle.load(open(f'{RV}/V_s{seed}.pkl', 'rb'))
        out['cfg'].update(filter=c.filter_mode, guard=c.guard_mode)
        D = {k: np.concatenate([src['labels0'][k], src['labels1'][k]]) for k in src['labels0']}
        student, router, info = train_models(D, seed)
        tau = src['tuned']['tau']; delta = src['tuned']['delta']
        test_all('critic', lambda: make_rule_greedy3(q))
        test_all('student', lambda: GateS(q, actor, c, 'student', student=student, tau=tau))
        test_all('band_K1', lambda: GateS(q, actor, c, 'band', student=student, delta=delta, lat_k=1))
        test_all('priv16', lambda: GateS(q, actor, c, 'priv', M=16))
        test_all('mc4_K0', lambda: GateS(q, actor, c, 'mc', M=4, lat_k=0))     # slowest under the plan guards: last
        save(); log('saved', fname); return
    if mode == 'post3':                            # package Z: true leader state with the prior generator, and vice versa
        test_all('mcls16_K0', lambda: GateS(q, actor, c, 'mc', M=16, lat_k=0, mcmodel='mcls'))
        test_all('mclg16_K0', lambda: GateS(q, actor, c, 'mc', M=16, lat_k=0, mcmodel='mclg'))
        save(); log('saved', fname); return
    if mode == 'post2':                            # deployable leader-conditioned query (observable leader history only)
        test_all('mcidl16_K0', lambda: GateS(q, actor, c, 'mc', M=16, lat_k=0, mcmodel='mcidl'))
        save(); log('saved', fname); return
    if mode == 'post':
        # queries with partial or identified information (same critic, test set and random traffic as the sweep's V_s{seed}.pkl)
        for name, model, M in [('mcf16_K0', 'mcf', 16), ('mcl16_K0', 'mcl', 16), ('mcid16_K0', 'mcid', 16), ('mcid4_K0', 'mcid', 4)]:
            test_all(name, lambda model=model, M=M: GateS(q, actor, c, 'mc', M=M, lat_k=0, mcmodel=model))
        if 'ident' not in out:                     # quality of the identification at the end of the critic's episodes
            from env import ALPHA_GRID, FV_GRID
            err = []
            for f in F:
                e = env_of(test[f]); run3(e, actor, make_rule_greedy3(q), c)
                lp = e.fpost - e.fpost.max(axis=(2, 3), keepdims=True); pr = np.exp(lp); pr /= pr.sum(axis=(2, 3), keepdims=True)
                ea = (pr.sum(3) * ALPHA_GRID).sum(2); ev = (pr.sum(2) * FV_GRID).sum(2)
                err.append(np.stack([np.abs(ea - e.f_alpha).mean(1), np.abs(ev - e.fvmax).mean(1)], 1))
            err = np.concatenate(err); out['ident'] = dict(alpha_mae=float(err[:, 0].mean()), fv_mae=float(err[:, 1].mean()),
                                                           prior_alpha_mae=float((c.st_alpha[1] - c.st_alpha[0]) / 4), prior_fv_mae=float((c.st_fv[1] - c.st_fv[0]) / 4))
            save(); log('ident', json.dumps(out['ident']))
        log('saved', fname); return
    nl, nd = (4 * N_LAB, 4 * N_DAG) if mode == 'big' else (N_LAB, N_DAG)
    store = mode == 'sweep'
    if 'labels0' not in out:
        rec = label(q, 'priv', None, nl, 70_000 + seed, store)
        out['labels0'] = labels_to_arrays(rec); save(); log('labels0', len(out['labels0']['g']))
    s0, r0, _ = train_models(out['labels0'], seed)
    if 'labels1' not in out:
        rec = label(q, 'student', s0, nd, 90_000 + seed, store)
        out['labels1'] = labels_to_arrays(rec) if rec else {k: v[:0] for k, v in out['labels0'].items()}; save()
        log('labels1', len(out['labels1']['g']))
    D = {k: np.concatenate([out['labels0'][k], out['labels1'][k]]) for k in out['labels0']}
    student, router, info = train_models(D, seed)
    if 'tuned' not in out:
        tv = {t: float(run_on(GateS(q, actor, c, 'student', student=student, tau=t), venv)[1]['G'].mean()) for t in [-1.0, 0.0, 1.0]}
        tuned = dict(tau=max(tv, key=tv.get), tau_val=tv)
        if mode == 'sweep':
            mv = {th: float(run_on(make_rule_margin(q, th, c), venv)[1]['G'].mean()) for th in [0.0, 0.5, 1.0, 2.0, 4.0, 8.0]}
            bv = {}
            for dl in [1.0, 2.0, 4.0, 8.0]:
                g_ = GateS(q, actor, c, 'band', student=student, delta=dl, lat_k=1); bv[dl] = float(run_on(g_, venv)[1]['G'].mean())
            tuned.update(theta=max(mv, key=mv.get), theta_val=mv, delta=max(bv, key=bv.get), delta_val=bv)
        out['tuned'] = tuned; save(); log('tuned', json.dumps(tuned, default=str))
    tau = out['tuned']['tau']
    test_all('critic', lambda: make_rule_greedy3(q))
    test_all('student', lambda: GateS(q, actor, c, 'student', student=student, tau=tau))
    if mode == 'big':
        save(); log('saved', fname); return
    test_all('student_r0', lambda: GateS(q, actor, c, 'student', student=s0, tau=0.0))
    test_all('margin', lambda: make_rule_margin(q, out['tuned']['theta'], c))
    test_all('stay', lambda: (lambda env, rows, M: np.zeros(len(rows), int)))
    test_all('band_K1', lambda: GateS(q, actor, c, 'band', student=student, delta=out['tuned']['delta'], lat_k=1))
    test_all('priv16', lambda: GateS(q, actor, c, 'priv', M=16))
    for M in [1, 4, 16]:
        test_all(f'mc{M}_K0', lambda M=M: GateS(q, actor, c, 'mc', M=M, lat_k=0))
    test_all('mc4_K1', lambda: GateS(q, actor, c, 'mc', M=4, lat_k=1))
    # offline decision charges on held-out labels (reference: K=4 privileged mean)
    if 'charges' not in out:
        va = info['va_router']; g = D['g'][va]; Gq = D['Gq'][va]
        def charge(acc):
            return float(np.mean(np.where(acc, np.maximum(-g, 0), np.maximum(g, 0))))
        X = D['X'][va]; gs = GateS(q, actor, c, 'student', student=student)
        gh = gs.ghat(X); rr, rho = GateS(q, actor, c, 'router', router=router).rhat(X)
        ch = dict(oracle=charge(g >= 0), student=charge(gh > tau), student_tau0=charge(gh >= 0),
                  kappa_router=float(np.mean(np.minimum(rr[:, 0], rr[:, 1]))),
                  mc={M: charge(Gq[:, :M].mean(1) >= 0) for M in [1, 2, 4, 8, 16]},
                  label_sd=float(np.mean(D['gs'][va].std(1, ddof=1))), dep_sd=float(np.mean(Gq.std(1, ddof=1))),
                  bias=float(np.mean(np.abs(Gq.mean(1) - g))), mae_student=float(np.mean(np.abs(gh - g))),
                  sign_dep16=float(np.mean((Gq.mean(1) >= 0) == (g >= 0))), sign_student=float(np.mean((gh >= 0) == (g >= 0))),
                  n=int(len(va)), props_per_ep=float(len(D['g']) / (N_LAB + N_DAG)))
        out['charges'] = ch; save(); log('charges', json.dumps(ch))
    # episode-loss certification of the student and of the critic itself
    if 'loss' not in out:
        cal = env_smp(123_000 + seed, N_CAL)
        Gb = run_on(make_rule_greedy3(q), cal)[1]['G']; Gs = run_on(make_rule_stay_then(make_rule_greedy3(q)), cal)[1]['G']
        W = np.maximum(Gb, Gs)
        Lst = np.maximum(W - run_on(GateS(q, actor, c, 'student', student=student, tau=tau), cal)[1]['G'], 0.0)
        out['loss'] = dict(student=Lst, critic=np.maximum(W - Gb, 0.0), mc4_K0=np.maximum(W - run_on(GateS(q, actor, c, 'mc', M=4, lat_k=0), cal)[1]['G'], 0.0))
        save()
    save(); log('saved', fname)


if __name__ == '__main__':
    main(int(sys.argv[1]), sys.argv[2])
