"""Exact sampled front kernel (Theorem 1), safe first-input bound (eq. safeinput) and terminal-safe commitment
plans (Theorem 2, constant and two-input restrictions), vectorised over rows.

Conventions (paper Sec. III): ego brakes with authority b through held inputs with u >= -v/dt; the emergency
input beta(v) = -min(b, v/dt) gives sample speeds e_k = (v - k b dt)_+ interpolated affinely (envelope E_dt);
a front vehicle at speed vp >= 0 never reverses and brakes no harder than bL (displacement L(vp, t)).
D_dt(v, vp) = max_t E_dt(v, t) - L(vp, t); kernel K_dt = {H+ >= D_dt}. Requires b >= bL (asserted), which makes
E_dt - L unimodal: its maximum lies at the first zero of the relative speed e(t) - l(t).
"""
import numpy as np


def _rel_grid(v, vp, b, bL, dt, K):
    """Sampled ego envelope e_k and leader lower-envelope speed l(k dt), shapes (B, K+1)."""
    k = np.arange(K + 1)[None, :]
    e = np.maximum(v[:, None] - k * b * dt, 0.0)
    l = np.maximum(vp[:, None] - bL[:, None] * k * dt, 0.0)
    return e, l


def L_env(vp, bL, t):
    """Minimal leader displacement over [0, t]: integral of (vp - bL s)_+."""
    ts = np.where(bL > 0, vp / np.where(bL > 0, bL, 1.0), np.inf)
    tt = np.minimum(t, ts)
    return vp * tt - 0.5 * bL * tt ** 2


def E_env(v, b, dt, t, K=None):
    """Displacement of the sampled emergency envelope over [0, t] (affine interpolation of e_k)."""
    v = np.asarray(v, float); t = np.asarray(t, float)
    if K is None:
        K = int(np.ceil(v.max() / (b * dt))) + 1 if v.size else 1
    k = np.arange(K + 1)[None, :]
    e = np.maximum(v[:, None] - k * b * dt, 0.0)                       # (B, K+1)
    seg = 0.5 * (e[:, :-1] + e[:, 1:]) * dt                            # displacement of each full piece
    cum = np.concatenate([np.zeros((v.shape[0], 1)), np.cumsum(seg, 1)], 1)
    kk = np.clip(np.floor(t / dt).astype(int), 0, K - 1)
    s = np.clip(t - kk * dt, 0.0, dt)
    i = np.arange(v.shape[0])
    ek, ek1 = e[i, kk], e[i, kk + 1]
    return cum[i, kk] + ek * s + (ek1 - ek) * s ** 2 / (2 * dt)


def D_delta(v, vp, b, bL, dt):
    """D_dt(v, vp) = max_t {E_dt(v,t) - L(vp,t)} for arrays v, vp, bL (B,). E_dt - L is piecewise quadratic with
    breakpoints at the sample instants and the leader's stop time; its maximum is attained at a breakpoint or at a
    zero of the relative speed e(t) - l(t) inside a piece, so all such candidates are evaluated."""
    v = np.asarray(v, float); vp = np.asarray(vp, float); bL = np.asarray(bL, float)
    B = v.shape[0]
    K = int(np.ceil(v.max() / (b * dt) - 1e-12)) + 1 if B else 1
    e, l = _rel_grid(v, vp, b, bL, dt, K)
    r = e - l                                                           # (B, K+1)
    ta = (np.arange(K) * dt)[None, :]                                   # piece starts (1, K)
    ts = np.where(bL > 0, vp / np.where(bL > 0, bL, 1.0), np.inf)[:, None]
    inside = (ts > ta) & (ts < ta + dt)
    # zero of the affine relative speed on the piece (no kink inside)
    rk, rk1 = r[:, :-1], r[:, 1:]
    den = rk - rk1
    frac = np.where(np.abs(den) > 1e-15, rk / np.where(np.abs(den) > 1e-15, den, 1.0), -1.0)
    z1 = np.where((frac > 0) & (frac < 1) & ~inside, ta + frac * dt, 0.0)
    # kink inside: zero on [ta, ts] between r_k and e(ts) (l(ts) = 0)
    e_ts = e[:, :-1] + (e[:, 1:] - e[:, :-1]) * np.clip(ts - ta, 0, dt) / dt
    den2 = rk - e_ts
    frac2 = np.where(np.abs(den2) > 1e-15, rk / np.where(np.abs(den2) > 1e-15, den2, 1.0), -1.0)
    z2 = np.where(inside & (frac2 > 0) & (frac2 < 1), ta + frac2 * np.clip(ts - ta, 0, dt), 0.0)
    tk = np.where(inside, ts, 0.0)
    T = np.concatenate([np.repeat(ta, B, 0), np.full((B, 1), K * dt), z1, z2, tk], 1)     # candidates (B, 4K+1)
    T = np.clip(T, 0.0, K * dt)
    vals = E_env(np.repeat(v, T.shape[1]), b, dt, T.ravel(), K).reshape(B, -1) - L_env(vp[:, None], bL[:, None], T)
    return np.maximum(vals.max(1), 0.0)


def prefix_max(v, u, vp, bL, dt):
    """max_{0<=s<=dt} X_u(s) - L(vp, s), X_u(s) = v s + u s^2 / 2 (candidates: s = dt and the zeros of the
    relative speed v + u s - (vp - bL s)_+ on each affine piece)."""
    ts = np.where(bL > 0, vp / np.where(bL > 0, bL, 1.0), np.inf)
    g = lambda s: v * s + 0.5 * u * s ** 2 - L_env(vp, bL, s)
    best = np.maximum(0.0, g(np.full_like(v, dt)))
    # piece 1: [0, min(ts, dt)], relative speed (v - vp) + (u + bL) s
    s1 = np.minimum(ts, dt)
    den = u + bL
    z = np.where(np.abs(den) > 1e-12, -(v - vp) / np.where(np.abs(den) > 1e-12, den, 1.0), -1.0)
    ok = (z > 0) & (z < s1)
    best = np.where(ok, np.maximum(best, g(np.clip(z, 0, dt))), best)
    # piece 2: [ts, dt] with l = 0, relative speed v + u s, zero at -v/u
    z2 = np.where(u < -1e-12, -v / np.where(u < -1e-12, u, -1.0), -1.0)
    ok2 = (ts < dt) & (z2 > ts) & (z2 < dt)
    best = np.where(ok2, np.maximum(best, g(np.clip(z2, 0, dt))), best)
    return best


def psi(u, v, vp, b, bL, dt):
    """Psi_dt(u) of eq. (psi): max of the prefix clearance loss and the terminal requirement."""
    vu = v + u * dt
    vpd = np.maximum(vp - bL * dt, 0.0)
    term = v * dt + 0.5 * u * dt ** 2 - L_env(vp, bL, dt) + D_delta(np.maximum(vu, 0.0), vpd, b, bL, dt)
    return np.maximum(prefix_max(v, u, vp, bL, dt), term)


def safe_front_max(v, vp, H, b, bL, dt, hi, iters=18):
    """Largest u in [beta(v), hi] with Psi(u) <= H (Theorem 1); NaN where the state is outside K_dt or hi < beta."""
    v = np.asarray(v, float); vp = np.asarray(vp, float); H = np.asarray(H, float); bL = np.asarray(bL, float)
    beta = -np.minimum(b, v / dt)
    inK = psi(beta, v, vp, b, bL, dt) <= H + 1e-9
    lo = beta.copy(); up = np.maximum(hi, beta)
    top_ok = psi(up, v, vp, b, bL, dt) <= H + 1e-9
    lo = np.where(top_ok, up, lo)
    for _ in range(iters):
        mid = 0.5 * (lo + up)
        ok = psi(mid, v, vp, b, bL, dt) <= H + 1e-9
        lo = np.where(ok, mid, lo); up = np.where(ok, up, mid)
    out = np.where(inK & (hi >= beta - 1e-12), lo, np.nan)
    return out, inK


# ----------------------------------------------------------------------------- terminal-safe commitment plans
def plan_feasible(v, u0, ut, N, dt, lanes, b, vmax, u_lo, u_hi, tgt_idx):
    """Feasibility of two-input plans (u0 for one step, then ut held) over a commitment of N steps.
    v: (B,) ego speed; u0, ut: (B, P) candidate plans; lanes: list of dicts per occupied lane with keys
    Hp, vp, bL (front), Hm, vm, am (rear: speed and upper acceleration bound), arrays (B,); tgt_idx: index in
    `lanes` of the target lane (terminal condition). Returns bool (B, P)."""
    B, P = u0.shape
    Tm = N * dt
    # ego sample speeds and positions under the plan
    vv = np.empty((B, P, N + 1)); XX = np.empty((B, P, N + 1))
    vv[:, :, 0] = v[:, None]; XX[:, :, 0] = 0.0
    for i in range(N):
        ui = u0 if i == 0 else ut
        vv[:, :, i + 1] = vv[:, :, i] + ui * dt
        XX[:, :, i + 1] = XX[:, :, i] + vv[:, :, i] * dt + 0.5 * ui * dt ** 2
    ok = np.ones((B, P), bool)
    ok &= (u0 >= u_lo - 1e-9) & (u0 <= u_hi + 1e-9) & (ut >= u_lo - 1e-9) & (ut <= u_hi + 1e-9)
    ok &= (vv >= -1e-9).all(2) & (vv <= vmax + 1e-9).all(2)

    def min_quad_on(a2, a1, a0, s_lo, s_hi):
        """min over s in [s_lo, s_hi] of a2 s^2 + a1 s + a0 (broadcast arrays)."""
        f = lambda s: a2 * s ** 2 + a1 * s + a0
        m = np.minimum(f(s_lo), f(s_hi))
        sv = np.where(np.abs(a2) > 1e-15, -a1 / (2 * np.where(np.abs(a2) > 1e-15, a2, 1.0)), s_lo)
        inside = (a2 > 0) & (sv > s_lo) & (sv < s_hi)
        return np.where(inside, np.minimum(m, f(np.clip(sv, s_lo, s_hi))), m)

    for ln in lanes:
        Hp, vp, bL = ln['Hp'][:, None], ln['vp'][:, None], ln['bL'][:, None]
        Hm, vm, am = ln['Hm'][:, None], ln['vm'][:, None], ln['am'][:, None]
        ts = np.where(bL > 0, vp / np.where(bL > 0, bL, 1.0), np.inf)
        Lstop = np.where(bL > 0, vp ** 2 / (2 * np.where(bL > 0, bL, 1.0)), np.inf)
        for i in range(N):
            ui = u0 if i == 0 else ut
            t0 = i * dt
            Xi, vi = XX[:, :, i], vv[:, :, i]
            # front: Hp + L(vp, t0 + s) - (Xi + vi s + ui s^2/2) >= 0, s in [0, dt]
            # piece a: t0 + s <= ts : L = vp (t0+s) - bL (t0+s)^2/2
            sa_hi = np.clip(ts - t0, 0.0, dt)
            # quadratic in s: coefficients
            a2 = -0.5 * bL - 0.5 * ui
            a1 = vp - bL * t0 - vi
            a0 = Hp + vp * t0 - 0.5 * bL * t0 ** 2 - Xi
            ma = np.where(sa_hi > 0, min_quad_on(a2, a1, a0, np.zeros_like(sa_hi), sa_hi), np.inf)
            # piece b: t0 + s >= ts : L = Lstop (constant)
            sb_lo = np.clip(ts - t0, 0.0, dt)
            b2 = -0.5 * ui; b1 = -vi; b0 = Hp + np.minimum(Lstop, 1e30) - Xi
            mb = np.where(sb_lo < dt, min_quad_on(b2, b1, b0, sb_lo, np.full_like(sb_lo, dt)), np.inf)
            ok &= (np.minimum(ma, mb) >= -1e-9)
            # rear: Hm + (Xi + vi s + ui s^2/2) - (vm (t0+s) + am (t0+s)^2/2) >= 0
            c2 = 0.5 * ui - 0.5 * am
            c1 = vi - vm - am * t0
            c0 = Hm + Xi - vm * t0 - 0.5 * am * t0 ** 2
            ok &= (min_quad_on(c2, c1, c0, np.zeros_like(sa_hi), np.full_like(sa_hi, dt)) >= -1e-9)
    # terminal condition in the target lane
    ln = lanes[tgt_idx]
    HF = ln['Hp'][:, None] + L_env(ln['vp'], ln['bL'], np.full_like(ln['vp'], Tm))[:, None] - XX[:, :, N]
    vF = np.maximum(ln['vp'] - ln['bL'] * Tm, 0.0)
    vN = np.maximum(vv[:, :, N], 0.0)
    Dn = D_delta(vN.ravel(), np.repeat(vF, P), b, np.repeat(ln['bL'], P), dt).reshape(B, P)
    ok &= HF >= Dn - 1e-9
    return ok
