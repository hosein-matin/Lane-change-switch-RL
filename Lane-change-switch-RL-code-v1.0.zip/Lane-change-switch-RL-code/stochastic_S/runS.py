#!/usr/bin/env python3
"""Parallel, resumable runner for the stochastic-traffic experiments (revision 3).

    python runS.py --lanes 2 --cores 16          # two lanes, 10 seeds (results_s2)
    python runS.py --lanes 3 --cores 16          # three lanes, 10 seeds (results_s3)
    python runS.py --lanes 2 --status            # progress
    python runS.py --lanes 2 --smoke --cores 4   # short end-to-end test on tiny settings (separate folder)

The longitudinal controllers are reused from the earlier runs (bundled in ppo2/ and ppo3/). Every job writes its
log to <results>/logs/<job>.log and, on success, a marker <results>/.done/<job>; re-running the same command
resumes. A progress summary is rewritten every minute to <results>/status.txt.
"""
import argparse, os, subprocess, sys, time, json, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, 'code')
SEEDS_ALL = list(range(10))
HEAVY = ['mc1', 'mc4', 'mc16', 'mc4_nolat', 'priv16', 'rollall4']


def build_jobs(R, lanes, smoke=False, seeds=SEEDS_ALL):
    ep = '96' if smoke else '6400'
    J = {}
    base_env = dict(STOCH='1', DUAL_LANE='1', DUAL_MODE='hold', CRITIC_NODIST='1', N_LANES=str(lanes), RESULTS_S=R)
    if smoke:
        base_env.update(N_TEST='4', N_VAL='12', N_LAB='96', N_DAG='64', N_CAL='20')

    def job(name, cmd, deps=(), env=None, prio=0):
        e = dict(base_env); e.update(env or {})
        J[name] = dict(cmd=[sys.executable] + cmd, deps=list(deps), env=e, prio=prio)

    for s in seeds:
        S = str(s); act = f'{R}/ppo_s{s}/actor.pkl'
        crit = []
        for tag, extra in [('c02', {'C0_TRAIN': '2'}), ('c010', {'C0_TRAIN': '10'}), ('acc', {'C0_TRAIN': '10', 'CRITIC_ACC': '1'})]:
            job(f'dqnS_{tag}_s{s}', ['dqnS.py', S, act, ep, f'{R}/dqnS_{tag}_s{s}'], [], extra, prio=90 if tag == 'c010' else 85)
            crit.append(f'dqnS_{tag}_s{s}')
        job(f'evalS_main_s{s}', ['evalS.py', S], crit, {'SKIP': ','.join(HEAVY)}, prio=80)
        job(f'evalS_mc_s{s}', ['evalS.py', S], crit, {'ONLY': 'mc1,mc4,mc16,mc4_nolat', 'TAG': 'mc'}, prio=70)
        job(f'evalS_ref_s{s}', ['evalS.py', S], crit, {'ONLY': 'priv16,rollall4', 'TAG': 'ref'}, prio=60)
    return J

def done_dir(R):
    d = os.path.join(R, '.done'); os.makedirs(d, exist_ok=True); return d


def is_done(R, name):
    return os.path.exists(os.path.join(done_dir(R), name))


def status(R, J, running=None, failed=None):
    n = len(J); d = sum(is_done(R, k) for k in J)
    lines = [time.strftime('%Y-%m-%d %H:%M:%S'), f'done {d}/{n}']
    if running:
        lines.append('running: ' + ', '.join(f'{k} ({(time.time()-t)/60:.0f} min)' for k, (_, t, _) in running.items()))
    if failed:
        lines.append('FAILED (see logs/<job>.log): ' + ', '.join(sorted(failed)))
    blocked = [k for k in J if not is_done(R, k) and failed and any(x in failed for x in J[k]['deps'])]
    if blocked:
        lines.append(f'blocked by failures: {len(blocked)} jobs')
    txt = '\n'.join(lines)
    open(os.path.join(R, 'status.txt'), 'w').write(txt + '\n')
    return txt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cores', type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument('--lanes', type=int, choices=[2, 3], required=True)
    ap.add_argument('--results', default=None)
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--smoke', action='store_true')
    ap.add_argument('--only', default=None, help='run only jobs whose name contains this text (and their dependencies)')
    a = ap.parse_args()
    R = os.path.abspath(a.results or os.path.join(HERE, f'results_s{a.lanes}'))
    seeds = SEEDS_ALL
    if a.smoke:
        R = os.path.join(HERE, f'smoke_s{a.lanes}'); seeds = [7]
    os.makedirs(R, exist_ok=True)
    # reuse the longitudinal controllers of the earlier runs
    for s in seeds:
        src = os.path.join(HERE, f'ppo{a.lanes}', f'ppo_s{s if not a.smoke else 0}')
        dst = os.path.join(R, f'ppo_s{s}')
        if not os.path.exists(os.path.join(dst, 'actor.pkl')):
            shutil.copytree(src, dst, dirs_exist_ok=True)
    J = build_jobs(R, a.lanes, a.smoke, seeds)
    if a.only:
        need = set(k for k in J if a.only in k)
        stack = list(need)
        while stack:
            for d in J[stack.pop()]['deps']:
                if d not in need:
                    need.add(d); stack.append(d)
        J = {k: v for k, v in J.items() if k in need}
    for d in [R, os.path.join(R, 'logs')]:
        os.makedirs(d, exist_ok=True)
    if a.status:
        print(status(R, J)); return
    print(f'{len(J)} jobs, {sum(is_done(R, k) for k in J)} already done, {a.cores} parallel workers; results in {R}', flush=True)
    running, failed = {}, set()
    last = 0
    try:
        while True:
            for k, (p, t0, lf) in list(running.items()):
                rc = p.poll()
                if rc is None:
                    continue
                lf.close(); del running[k]
                if rc == 0:
                    open(os.path.join(done_dir(R), k), 'w').write(time.strftime('%Y-%m-%d %H:%M:%S'))
                    print(f'[{time.strftime("%H:%M:%S")}] done   {k} ({(time.time()-t0)/60:.1f} min)', flush=True)
                else:
                    failed.add(k)
                    print(f'[{time.strftime("%H:%M:%S")}] FAILED {k} (exit {rc}), see {R}/logs/{k}.log', flush=True)
            todo = [k for k in J if not is_done(R, k) and k not in running and k not in failed]
            if not todo and not running:
                break
            ready = [k for k in todo if all(is_done(R, d) for d in J[k]['deps'])]
            ready.sort(key=lambda k: -J[k]['prio'])
            while ready and len(running) < a.cores:
                k = ready.pop(0)
                env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                           PYTHONUNBUFFERED='1', **J[k]['env'])
                lf = open(os.path.join(R, 'logs', f'{k}.log'), 'a')
                lf.write(f'\n===== start {time.strftime("%Y-%m-%d %H:%M:%S")}\n'); lf.flush()
                p = subprocess.Popen(J[k]['cmd'], cwd=CODE, env=env, stdout=lf, stderr=subprocess.STDOUT)
                running[k] = (p, time.time(), lf)
                print(f'[{time.strftime("%H:%M:%S")}] start  {k}', flush=True)
            if not running and not ready:
                break   # everything left is blocked by a failure
            if time.time() - last > 60:
                status(R, J, running, failed); last = time.time()
            time.sleep(2)
    except KeyboardInterrupt:
        print('\nInterrupted: stopping running jobs (they will restart next time).', flush=True)
        for k, (p, _, lf) in running.items():
            p.terminate()
        for k, (p, _, lf) in running.items():
            try:
                p.wait(10)
            except Exception:
                p.kill()
            lf.close()
    print(status(R, J, {}, failed), flush=True)
    if failed:
        sys.exit(1)


if __name__ == '__main__':
    main()
