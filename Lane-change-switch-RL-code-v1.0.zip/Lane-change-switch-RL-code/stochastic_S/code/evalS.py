"""Stochastic declared model (revision 3): labels, student and router, tuning, test, risk certification.
Usage: STOCH=1 DUAL_LANE=1 DUAL_MODE=hold CRITIC_NODIST=1 N_LANES=L RESULTS_S=dir python evalS.py SEED
Needs RESULTS_S/ppo_s{SEED}/actor.pkl and critics RESULTS_S/dqnS_{c02,c010,acc}_s{SEED}/q.pkl.
Writes RESULTS_S/evalS_s{SEED}.pkl (resumable by stage and method).
"""
import sys, os, time, pickle, json
import numpy as np
import math
from config import Cfg
from env import Env
from nn import MLP
from hl import metrics
from hl3 import run3, rule_stay3, make_rule_greedy3, make_rule_stay_then, make_rule_mobil3
from stochhl import GateS, RolloutAll, Stats, labels_to_arrays, train_models, feats, rollout_M
from hl3 import DIRS

RS = os.environ.get('RESULTS_S', os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, 'results_s'))
N_TEST = int(os.environ.get('N_TEST', 100)); N_VAL = int(os.environ.get('N_VAL', 300))
N_LAB = int(os.environ.get('N_LAB', 2048)); N_DAG = int(os.environ.get('N_DAG', 1024)); N_CAL = int(os.environ.get('N_CAL', 500))
LAMS = [float(x) for x in os.environ.get('LAMS', '0,0.5,2,8').split(',')]
EPS_L = [1.0, 2.0, 5.0]; ALPHA = 0.1; BETA = 0.1


def sets(c):
    if c.n_lanes == 3:
        from scenarios3 import FAMILIES3 as F, make_test_set3, load_set3, Sampler3
        test = {f: make_test_set3(c, f, N_TEST, seed=20_000 + 17 * i)[0] for i, f in enumerate(F)}
        return F, test, load_set3, Sampler3
    from scenarios import FAMILIES as F, make_test_set, load_set, Sampler
    test = {f: make_test_set(c, f, N_TEST, seed=10_000 + 17 * i)[0] for i, f in enumerate(F)}
    return F, test, load_set, Sampler


def binom_cdf(r, n, p):
    if p <= 0: return 1.0
    if p >= 1: return 1.0 if r >= n else 0.0
    lg = math.lgamma
    return min(1.0, sum(math.exp(lg(n + 1) - lg(k + 1) - lg(n - k + 1) + k * math.log(p) + (n - k) * math.log1p(-p)) for k in range(r + 1)))


def cp_upper(r, n, level):
    """One-sided Clopper-Pearson upper bound: the p with P(Bin(n, p) <= r) = 1 - level (= Beta^{-1}(level; r+1, n-r))."""
    if r >= n: return 1.0
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if binom_cdf(r, n, mid) > 1 - level: lo = mid
        else: hi = mid
    return hi


def make_rule_greedy_acc(q):
    """pi_b of the matched-information critic (critic input + measured leader accelerations)."""
    def rule(env, rows, M):
        y = np.concatenate([env.critic_obs(), env.meas_acc()], 1)[rows]
        qq = np.where(M, q.forward(y), -np.inf); best = np.argmax(qq, 1)
        return np.where(qq[np.arange(len(rows)), 0] >= qq[np.arange(len(rows)), best], 0, best)
    return rule


def main(seed):
    c = Cfg(); assert c.stoch
    t0 = time.time(); log = lambda *a: print(f'[{time.time()-t0:7.1f}s]', *a, flush=True)
    only = os.environ.get('ONLY'); tag = os.environ.get('TAG', '')
    fname = f'{RS}/evalS_s{seed}' + (f'_{tag}' if tag else '') + '.pkl'
    need_models = not only or any(m.startswith(('student', 'band', 'router')) for m in only.split(','))
    out = pickle.load(open(fname, 'rb')) if os.path.exists(fname) else dict(seed=seed, test={}, stats={})
    save = lambda: pickle.dump(out, open(fname, 'wb'))
    actor = MLP.load(f'{RS}/ppo_s{seed}/actor.pkl')
    q = MLP.load(f'{RS}/dqnS_c010_s{seed}/q.pkl'); q2 = MLP.load(f'{RS}/dqnS_c02_s{seed}/q.pkl')
    qa = MLP.load(f'{RS}/dqnS_acc_s{seed}/q.pkl')
    F, test, load_set, Smp = sets(c)

    def env_of(scen):
        e = Env(c, len(scen)); load_set(e, scen); e.done[:] = False; return e

    def env_smp(sd, n):
        e = Env(c, n); Smp(c, sd).reset_rows(e, range(n)); e.done[:] = False; return e

    venv = env_smp(55_555, N_VAL)

    def run_on(rule, src):
        e = src.subset(np.arange(src.B)); e.done[:] = False
        res = run3(e, actor, rule, c); return e, res

    student = router = student0 = None; tau = 0.0; delta = 1.0
    if need_models:
        # ---------------- labels: round 0 (privileged MC gate acts), round 1 (student acts)
        def label(act, student, n, sd):
            g = GateS(q, actor, c, 'label', act=act, student=student)
            B = 64; e = Env(c, B); s = Smp(c, sd)
            for k in range(max(1, n // B)):
                s.reset_rows(e, range(B)); e.done[:] = False; run3(e, actor, g, c)
            return g.rec
        if 'labels0' not in out:
            out['labels0'] = labels_to_arrays(label('priv', None, N_LAB, 70_000 + seed)); save()
            log('labels0', len(out['labels0']['g']))
        student0, router0, _ = train_models(out['labels0'], seed)
        if 'labels1' not in out:
            rec = label('student', student0, N_DAG, 90_000 + seed)
            out['labels1'] = labels_to_arrays(rec) if rec else {k: v[:0] for k, v in out['labels0'].items()}; save()
            log('labels1', len(out['labels1']['g']))
        D = {k: np.concatenate([out['labels0'][k], out['labels1'][k]]) for k in out['labels0']}
        student, router, info = train_models(D, seed)
        # held-out diagnostics of the predictors and of the routing (no simulation)
        va = info['va_router']; Xv = D['X'][va]
        gS = GateS(q, actor, c, 'student', student=student); gR = GateS(q, actor, c, 'router', router=router)
        gh = gS.ghat(Xv); rr, rho = gR.rhat(Xv)
        kappa = np.minimum(rr[:, 0], rr[:, 1])              # predicted charge of the best fixed decision
        diag = dict(n_labels=int(len(D['g'])), n_dag=int(len(out['labels1']['g'])),
                    sign_agree=float(np.mean((gh >= 0) == (D['g'][va] >= 0))),
                    mae=float(np.mean(np.abs(gh - D['g'][va]))), label_sd=float(np.mean(D['gs'][va].std(1))),
                    query_charge=float(np.mean(info['dq'][va])), kappa_mean=float(np.mean(kappa)),
                    student_charge=float(np.mean(np.where(gh >= 0, info['da'][va], info['dr'][va]))), route={})
        for lam in LAMS:
            score = np.stack([rr[:, 0], rr[:, 1], rr[:, 2] + lam * rho / 1000.0], 1); j = np.argmin(score, 1)
            chg = np.where(j == 0, info['da'][va], np.where(j == 1, info['dr'][va], info['dq'][va]))
            diag['route'][lam] = dict(q_frac=float(np.mean(j == 2)), charge=float(np.mean(chg)),
                                      stake_queried=float(np.mean(kappa[j == 2])) if (j == 2).any() else 0.0,
                                      stake_other=float(np.mean(kappa[j != 2])) if (j != 2).any() else 0.0)
        for dl in [1.0, 2.0, 4.0, 8.0]:
            qb = np.abs(gh) < dl
            chg = np.where(qb, info['dq'][va], np.where(gh >= 0, info['da'][va], info['dr'][va]))
            diag['route'][f'band{dl}'] = dict(q_frac=float(np.mean(qb)), charge=float(np.mean(chg)),
                                              stake_queried=float(np.mean(kappa[qb])) if qb.any() else 0.0,
                                              stake_other=float(np.mean(kappa[~qb])) if (~qb).any() else 0.0)
        out['diag'] = diag; log('diag', json.dumps({k: v for k, v in diag.items() if k != 'route'}))
        # ---------------- validation tuning
        if 'tuned' not in out:
            tv = {tau: float(run_on(GateS(q, actor, c, 'student', student=student, tau=tau), venv)[1]['G'].mean()) for tau in [-1.0, 0.0, 1.0]}
            bv = {}
            for dl in [1.0, 2.0, 4.0, 8.0]:
                g_ = GateS(q, actor, c, 'band', student=student, delta=dl); bv[dl] = (float(run_on(g_, venv)[1]['G'].mean()), g_.st.queries / N_VAL)
            out['tuned'] = dict(tau=max(tv, key=tv.get), tau_val=tv, delta=max(bv, key=lambda k: bv[k][0]), delta_val=bv); save()
            log('tuned', json.dumps(out['tuned'], default=str))
        tau, delta = out['tuned']['tau'], out['tuned']['delta']
    pm = (0.25, 0.3)
    methods = {
        'stay': lambda: rule_stay3, 'mobil': lambda: make_rule_mobil3(actor, c, p=pm[0], a_th=pm[1]),
        'critic_c02': lambda: make_rule_greedy3(q2), 'critic': lambda: make_rule_greedy3(q), 'critic_acc': lambda: make_rule_greedy_acc(qa),
        'student': lambda: GateS(q, actor, c, 'student', student=student, tau=tau),
        'student_r0': lambda: GateS(q, actor, c, 'student', student=student0, tau=0.0),
        'band': lambda: GateS(q, actor, c, 'band', student=student, delta=delta),
        **{f'router_{lam}': (lambda lam=lam: GateS(q, actor, c, 'router', router=router, lam=lam)) for lam in LAMS},
        'mc1': lambda: GateS(q, actor, c, 'mc', M=1), 'mc4': lambda: GateS(q, actor, c, 'mc', M=4),
        'mc16': lambda: GateS(q, actor, c, 'mc', M=16), 'mc4_nolat': lambda: GateS(q, actor, c, 'mc', M=4, latency=False),
        'priv16': lambda: GateS(q, actor, c, 'priv', M=16),
        'rollall4': lambda: RolloutAll(q, actor, c, M=4),
    }
    for name, mk in methods.items():
        if only and name not in only.split(','):
            continue
        if name in os.environ.get('SKIP', '').split(','):
            continue
        if name in out['test'] and len(out['test'][name]) == len(F):
            continue
        out['test'][name] = {}; out['stats'][name] = {}
        for f in F:
            rule = mk(); e = env_of(test[f]); res = run3(e, actor, rule, c); m = metrics(e, res)
            m['fail_mask'] = res['fail_mask'].astype(float); out['test'][name][f] = m
            st = getattr(rule, 'st', None); n = len(test[f])
            out['stats'][name][f] = dict(props=st.props / n, queries=st.queries / n, steps=st.sim_steps / n,
                                         rollouts=st.rollouts / n, late_drop=st.late_drop / n) if st is not None else {}
        G = np.concatenate([out['test'][name][f]['G'] for f in F])
        qn = np.mean([out['stats'][name][f].get('queries', 0) for f in F])
        log(name, f'G={G.mean():.2f}', f'queries/ep={qn:.2f}', 'LC', round(float(np.concatenate([out['test'][name][f]['n_sw'] for f in F]).mean()), 2))
        save()
    # ---------------- risk certification (Learn then Test on the realized episode loss)
    if 'ltt' not in out and not only:
        cal = env_smp(123_000 + seed, N_CAL)
        Gb = run_on(make_rule_greedy3(q), cal)[1]['G']; Gs = run_on(make_rule_stay_then(make_rule_greedy3(q)), cal)[1]['G']
        W = np.maximum(Gb, Gs); cands = {}
        cand_rules = {'student': lambda: GateS(q, actor, c, 'student', student=student, tau=tau),
                      'band': lambda: GateS(q, actor, c, 'band', student=student, delta=delta),
                      **{f'router_{lam}': (lambda lam=lam: GateS(q, actor, c, 'router', router=router, lam=lam)) for lam in LAMS},
                      'mc4': lambda: GateS(q, actor, c, 'mc', M=4)}
        for nm, mk in cand_rules.items():
            rule = mk(); _, res = run_on(rule, cal)
            cands[nm] = dict(L=np.maximum(W - res['G'], 0.0), G=res['G'], queries=rule.st.queries / N_CAL, steps=rule.st.sim_steps / N_CAL)
        Kc = len(cands); sel = {}
        for eps in EPS_L:
            sel[eps] = {}
            for nm, d in cands.items():
                r = int((d['L'] > eps).sum())
                U = cp_upper(r, N_CAL, 1 - BETA / Kc)
                sel[eps][nm] = dict(r=r, U=U, ok=U <= ALPHA)
        out['ltt'] = dict(cands=cands, sel=sel, Gb=Gb, Gs=Gs, K=Kc, alpha=ALPHA, beta=BETA, n=N_CAL); save()
        log('ltt', json.dumps({e: {k: (v['r'], round(v['U'], 3)) for k, v in s.items()} for e, s in sel.items()}))
    # ---------------- wall clock (seed 0)
    if seed == 0 and 'timing' not in out and not only:
        e1 = env_smp(4242, 1); r = np.array([0]); acts = np.array([1 if e1.lane[0] > 0 else 2]); tt = {}
        gS = GateS(q, actor, c, 'student', student=student); gR = GateS(q, actor, c, 'router', router=router)
        base = make_rule_greedy3(q)
        t1 = time.perf_counter()
        for _ in range(200):
            f = np.concatenate([feats(e1)[r], DIRS[acts][:, None].astype(float)], 1); gS.ghat(f); gR.rhat(f); q.forward(e1.critic_obs())
        tt['student_router_critic_ms'] = 1e3 * (time.perf_counter() - t1) / 200
        for M in [1, 4, 16]:
            t1 = time.perf_counter(); rollout_M(e1, r, acts, actor, base, c, 'mc', M); tt[f'mc{M}_ms'] = 1e3 * (time.perf_counter() - t1)
        out['timing'] = tt; save(); log('timing', tt)
    save(); log('saved', fname)


if __name__ == '__main__':
    main(int(sys.argv[1]))
