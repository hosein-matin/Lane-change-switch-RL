"""Stochastic declared traffic model (revision 3).

Leaders (lmode 3) track a piecewise-constant target speed with gain kappa; the acceleration is clipped to the
declared bound [-A|w|, A|w|], so Prop. 1 holds for every realization. Segment j lasts U(st_dur); its target is
the sinusoid's value at the segment end plus noise st_sig*A*U(-1,1), or, with probability st_pbrake, a hard-
braking target max(0, vbar - 1.5A - 2). Follower gains are drawn from U(st_alpha) per lane and, like the
desired speeds, hidden from the controller (the filter uses the worst case over the declared ranges).

Rollout models (common random numbers: both branches of a comparison use the same seeds):
  'true' (privileged; teacher and certificates): true follower parameters and the active leader segment are kept,
         all later segments are resampled from the true generator (no clairvoyance about the realized future);
  'mc'   (deployable query): the active target is inferred from the measured acceleration (exact unless
         saturated), its end and all later segments and the follower parameters are sampled from the prior.
"""
import numpy as np
from env import LEAD, FOLL


def param_seed(p):
    """Deterministic seed of a scenario from its parameters (same realization for every method)."""
    vals = []
    def walk(x):
        if isinstance(x, dict):
            for k in sorted(x):
                walk(x[k])
        elif isinstance(x, (list, tuple)):
            for y in x:
                walk(y)
        elif isinstance(x, (int, float, np.floating, np.integer)):
            vals.append(float(x))
    walk(p)
    h = 0
    for v in vals:
        h = (h * 1000003 + int(round(v * 1e6))) % (2 ** 61 - 1)
    return int(h % (2 ** 32))


def _segments(rng, c, t_start, K, vbar, A, w, phi):
    """K segments starting at t_start: returns start times (K,) and targets (K,)."""
    dur = rng.uniform(c.st_dur[0], c.st_dur[1], K)
    t = t_start + np.concatenate([[0.0], np.cumsum(dur)[:-1]])
    t_end = t + dur
    tgt = vbar + A * np.sin(w * t_end + phi) + c.st_sig * A * rng.uniform(-1.0, 1.0, K)
    brake = rng.random(K) < c.st_pbrake
    tgt = np.where(brake, max(0.0, vbar - 1.5 * A - 2.0), tgt)
    return t, np.clip(tgt, 0.0, c.vmax)


def apply_row(env, r, seed):
    """Realized stochastic traffic for row r (after the scenario's write_row)."""
    c = env.c; K = env.SCH_K
    rng = np.random.default_rng([seed, 17])
    for k in range(env.L):
        t, tg = _segments(rng, c, 0.0, K, env.vbar[r, k], env.A[r, k], env.w[r, k], env.phi[r, k])
        env.sch_t[r, k] = t; env.sch_a[r, k] = tg
        env.f_alpha[r, k] = rng.uniform(c.st_alpha[0], c.st_alpha[1])
    # the leaders start at their scenario speed; from t = 0 they track the schedule
    env.lmode[r] = 3
    env.invalidate()


def _state_seed(env, j):
    h = (int(round(float(env.t[j]) * 10)) * 1000003 + int(round(float(env.x[j, 0]) * 1000)) * 10007
         + int(round(float(env.v[j, 0]) * 1000)) * 101 + int(env.lane[j]))
    return h % (2 ** 31)


def resample(sub, src, rows, rep, kind, salt=0):
    """Resample the hidden future of a clone `sub` (= src.subset(rows, repeat=rep)), row-major replicates.
    kind 'true': privileged; kind 'mc': deployable. Common random numbers: the seed depends only on the source
    state, the replicate index, and `salt`."""
    c = src.c; K = sub.SCH_K
    v_all, a_all = src.leader_speed_acc(src.t)
    for i, r in enumerate(np.asarray(rows)):
        base = _state_seed(src, r)
        for m in range(rep):
            j = i * rep + m
            rng = np.random.default_rng([base, m, salt, 29])
            t = float(src.t[r])
            for k in range(src.L):
                if kind == 'true':
                    st = src.sch_t[r, k]
                    cur = max(int((st <= t).sum()) - 1, 0)
                    nxt = st[cur + 1] if cur + 1 < K and np.isfinite(st[cur + 1]) else t + rng.uniform(*c.st_dur)
                    keep_t = st[:cur + 1]; keep_a = src.sch_a[r, k, :cur + 1]
                    nt, na = _segments(rng, c, nxt, K - cur - 1, src.vbar[r, k], src.A[r, k], src.w[r, k], src.phi[r, k])
                    sub.sch_t[j, k] = np.concatenate([keep_t, nt]); sub.sch_a[j, k] = np.concatenate([keep_a, na])
                else:
                    vk = float(v_all[r, k]); ak = float(a_all[r, k]); b = float(src.A[r, k] * abs(src.w[r, k]))
                    if b > 1e-9 and abs(ak) >= b - 1e-6:            # saturated: target beyond v +- b/kappa
                        tg0 = vk + np.sign(ak) * (b / c.st_kappa + rng.uniform(0.0, 3.0))
                    else:
                        tg0 = vk + ak / c.st_kappa
                    end0 = t + rng.uniform(0.0, c.st_dur[1])
                    A_p = float(np.clip(b / 0.45, 0.0, 5.0)); A_p = min(A_p, vk, c.vmax - vk) if vk > 0 else 0.0
                    nt, na = _segments(rng, c, end0, K - 1, vk, A_p, rng.uniform(0.2, 0.7), rng.uniform(0, 2 * np.pi))
                    sub.sch_t[j, k] = np.concatenate([[t], nt]); sub.sch_a[j, k] = np.concatenate([[np.clip(tg0, 0, c.vmax)], na])
                    vf = float(src.v[r, FOLL[k]])
                    sub.f_alpha[j, k] = rng.uniform(c.st_alpha[0], c.st_alpha[1])
                    sub.fvmax[j, k] = max(rng.uniform(c.st_fv[0], c.st_fv[1]), vf + 1.0)
            sub.lmode[j] = 3
    sub.invalidate()
    return sub
