"""Lane selection under the stochastic declared model (revision 3), any number of lanes.

Rules act through run3 (actions 0 stay, 1 left, 2 right). pi_b: masked argmax of the critic; pi_s: stay when
admissible, else pi_b. A proposal epoch: pi_b proposes a change and stay is admissible.

Advantage g(y) = Q_b(y, change) - V_s(y) (expectation over the traffic). Estimates:
  privileged Monte Carlo ('true' model, M samples, common random numbers): teacher labels, references;
  deployable Monte Carlo ('mc' model): run-time queries.
Run-time simulation has latency: a query started at time t returns after ceil(LAT0 (T_f - t)/T_f / Delta)
samples (M samples assumed to run in parallel); the ego stays meanwhile, and an accepted change is executed
only if pi_b still proposes it and it is admissible (so the rule keeps the structure of Prop. 2).
"""
import os
import numpy as np
from nn import MLP, Adam
from hl3 import run3, masks3, make_rule_greedy3, make_rule_stay_then, DIRS
from hl import model_clone
from env import Env

LAT0 = float(os.environ.get('LAT0', '0.66'))   # seconds per simulated comparison at t = 0 (measured)


def feats(env):
    """Student/router features: lane-count independent observation (26) + measured leader accelerations (3)."""
    return np.concatenate([env.generic_obs(), env.meas_acc()], 1)


def latency_samples(env, rows, lat0=LAT0):
    c = env.c
    return np.ceil(lat0 * np.maximum(c.Tf - env.t[rows], 0.0) / c.Tf / c.dt - 1e-9).astype(int)


def rollout_specs(env, r, acts, actor, base, c, specs):
    """Estimates of g at rows r (proposed changes acts) for several (model, M, salt) specs in ONE batched
    simulation (both branches, all specs). Common random numbers between the two branches of each spec.
    Returns list of (mean (n,), samples (n, M)) and the total simulated steps."""
    n = len(r); parts = []; ff = []; stay = []
    for (model, M, salt) in specs:
        for branch in (0, 1):                       # 0: change then pi_b; 1: stay then pi_s
            sub = model_clone(env, r, M, model, salt=salt); parts.append(sub)
            ff.append(np.repeat(acts, M) if branch == 0 else np.zeros(n * M, int)); stay.append(np.full(n * M, branch == 1))
    big = Env.concat(parts); ff = np.concatenate(ff); is_stay = np.concatenate(stay)
    n0 = big.n_steps.copy()
    def rule(e_, rows_, M_):
        a_ = base(e_, rows_, M_)
        return np.where(is_stay[rows_] & M_[:, 0], 0, a_)
    res = run3(big, actor, rule, c, forced_first=ff)
    steps = int((big.n_steps - n0).sum())
    out = []; off = 0
    for (model, M, salt) in specs:
        Gc = res['G'][off:off + n * M]; Gs = res['G'][off + n * M:off + 2 * n * M]; off += 2 * n * M
        G = (Gc - Gs).reshape(n, M); out.append((G.mean(1), G))
    return out, steps


def rollout_M(env, r, acts, actor, base, c, model, M, salt=0):
    """M-sample estimate of g at rows r for proposed changes acts. Returns mean (n,), samples (n, M), steps."""
    (res,), steps = rollout_specs(env, r, acts, actor, base, c, [(model, M, salt)])
    return res[0], res[1], steps


class Stats:
    def __init__(self):
        self.props = 0; self.queries = 0; self.sim_steps = 0; self.rollouts = 0; self.late_drop = 0


class GateS:
    """Decision rule at proposals of pi_b.
    mode: 'mc' (deployable MC gate, M samples), 'priv' (privileged MC gate, reference), 'student' (g_hat > tau),
          'band' (query iff |g_hat| < delta), 'router' (argmin of predicted charges + lam * predicted work),
          'label' (record labels; act by 'act' in {'priv', 'student'}).
    Queries (deployable MC with Mq samples) have latency unless latency=False."""
    def __init__(self, q, actor, c, mode, M=4, Mq=4, student=None, router=None, tau=0.0, delta=None, lam=None,
                 latency=True, K_label=4, act='priv'):
        self.base = make_rule_greedy3(q); self.actor, self.c = actor, c
        self.mode, self.M, self.Mq = mode, M, Mq
        self.student, self.router, self.tau, self.delta, self.lam = student, router, tau, delta, lam
        self.latency, self.K_label, self.act = latency, K_label, act
        self.st = Stats(); self.rec = []; self._env = None
        self.qlog = []          # per query: [features..., predicted quantities]

    # -- predictions
    def ghat(self, f):
        net, mu, sd = self.student
        return net.forward((f - mu) / sd)[:, 0] * 10.0

    def rhat(self, f):
        net, mu, sd = self.router
        o = net.forward((f - mu) / sd)
        r = np.maximum(o[:, :3] * 10.0, 0.0); rho = np.maximum(o[:, 3] * 1000.0, 1.0)
        return r, rho

    def _reset_if_new(self, env):
        if self._env is not env:
            self._env = env; self.p_act = np.full(env.B, -1); self.p_due = np.zeros(env.B)

    def _query(self, env, r, acts):
        g, G, steps = rollout_M(env, r, acts, self.actor, self.base, self.c, 'mc', self.Mq)
        self.st.queries += len(r); self.st.sim_steps += steps; self.st.rollouts += 2 * self.Mq * len(r)
        return g >= 0.0

    def __call__(self, env, rows, M):
        self._reset_if_new(env)
        a = self.base(env, rows, M)
        out = a.copy()
        # pending queries
        pend = self.p_act[rows] >= 0
        if pend.any():
            pr = rows[pend]
            due = env.t[pr] >= self.p_due[pr] - 1e-9
            act_now = np.zeros(len(pr), int)
            ok = due & (self.p_act[pr] > 0) & (a[pend] == self.p_act[pr]) & M[pend][np.arange(len(pr)), np.maximum(self.p_act[pr], 0)]
            act_now[ok] = self.p_act[pr][ok]
            self.st.late_drop += int((due & (self.p_act[pr] > 0) & ~ok).sum())
            out[pend] = act_now
            self.p_act[pr[due]] = -1
        cand = np.where(~pend & (a > 0) & M[:, 0])[0]
        if len(cand) == 0:
            return out
        r = rows[cand]; acts = a[cand]; self.st.props += len(r)
        f = np.concatenate([feats(env)[r], DIRS[acts][:, None].astype(float)], 1)
        query = np.zeros(len(r), bool); dec = np.zeros(len(r), bool)
        if self.mode == 'label':
            ((g, G), (gq, Gq)), steps = rollout_specs(env, r, acts, self.actor, self.base, self.c,
                                                      [('true', self.K_label, 1), ('mc', self.Mq, 0)])
            steps_q = steps * self.Mq / (self.Mq + self.K_label)
            self.rec.append(dict(X=f, g=g, gs=G, aq=(gq >= 0).astype(float), gq=gq, steps_q=np.full(len(r), steps_q / len(r))))
            dec = (g >= 0) if self.act == 'priv' else (self.ghat(f) > self.tau)
        elif self.mode == 'priv':
            g, G, steps = rollout_M(env, r, acts, self.actor, self.base, self.c, 'true', self.M, salt=2)
            self.st.sim_steps += steps; self.st.rollouts += 2 * self.M * len(r); dec = g >= 0
        elif self.mode == 'mc':
            query[:] = True
        elif self.mode == 'student':
            dec = self.ghat(f) > self.tau
        elif self.mode == 'band':
            gh = self.ghat(f); query = np.abs(gh) < self.delta; dec = gh >= 0
        elif self.mode == 'router':
            rr, rho = self.rhat(f)
            score = np.stack([rr[:, 0], rr[:, 1], rr[:, 2] + self.lam * rho / 1000.0], 1)
            j = np.argmin(score, 1)
            dec = j == 0; query = j == 2
            self.qlog.append(np.concatenate([rr, rho[:, None], j[:, None]], 1))
        if query.any():
            qi = np.where(query)[0]
            Mq = self.M if self.mode == 'mc' else self.Mq
            g, G, steps = rollout_M(env, r[qi], acts[qi], self.actor, self.base, self.c, 'mc', Mq)
            self.st.queries += len(qi); self.st.sim_steps += steps; self.st.rollouts += 2 * Mq * len(qi)
            dq = g >= 0.0
            if self.latency:
                K = latency_samples(env, r[qi])
                late = K > 0
                self.p_act[r[qi][late]] = np.where(dq[late], acts[qi][late], 0)
                self.p_due[r[qi][late]] = env.t[r[qi][late]] + K[late] * self.c.dt
                dec[qi] = np.where(late, False, dq)
            else:
                dec[qi] = dq
        res = np.where(dec, acts, 0)
        out[cand] = res
        return out


class RolloutAll:
    """Rollout algorithm with base pi_b over all admissible options at every decision (deployable MC, M samples,
    common random numbers across options), with latency: stay while computing, then execute the best option
    if still admissible."""
    def __init__(self, q, actor, c, M=4, latency=True):
        self.base = make_rule_greedy3(q); self.actor, self.c, self.M, self.latency = actor, c, M, latency
        self.st = Stats(); self._env = None

    def __call__(self, env, rows, M):
        if self._env is not env:
            self._env = env; self.p_act = np.full(env.B, -1); self.p_due = np.zeros(env.B)
        out = np.zeros(len(rows), int)
        pend = self.p_act[rows] >= 0
        if pend.any():
            pr = rows[pend]; due = env.t[pr] >= self.p_due[pr] - 1e-9
            pa = np.maximum(self.p_act[pr], 0)
            ok = due & M[pend][np.arange(len(pr)), pa]
            out[pend] = np.where(ok, pa, 0)
            self.p_act[pr[due]] = -1
        free = np.where(~pend & (M.sum(1) >= 2) & M[:, 0])[0]
        if len(free) == 0:
            return np.where(pend, out, self.base(env, rows, M) * 0)   # stay elsewhere (single option handled by run3)
        r = rows[free]; Mm = M[free]
        opts = [(i, a_) for i in range(len(r)) for a_ in range(3) if Mm[i, a_]]
        rr = np.array([r[i] for i, _ in opts]); aa = np.array([a_ for _, a_ in opts])
        sub = model_clone(env, rr, self.M, 'mc'); n0 = sub.n_steps.copy()
        res = run3(sub, self.actor, self.base, self.c, forced_first=np.repeat(aa, self.M))
        self.st.queries += len(r); self.st.sim_steps += int((sub.n_steps - n0).sum()); self.st.rollouts += len(rr) * self.M
        Gm = res['G'].reshape(len(rr), self.M).mean(1)
        best = np.zeros(len(r), int); bestG = np.full(len(r), -np.inf)
        for (i, a_), g in zip(opts, Gm):
            if g > bestG[i] + 1e-9 or (a_ == 0 and g >= bestG[i] - 1e-9):
                bestG[i] = g; best[i] = a_
        if self.latency:
            K = latency_samples(env, r)
            late = K > 0
            self.p_act[r[late]] = best[late]; self.p_due[r[late]] = env.t[r[late]] + K[late] * self.c.dt
            best = np.where(late, 0, best)
        out[free] = best
        return out


# ---------------------------------------------------------------- learning
def fit(X, Y, seed, epochs=200, hidden=128, val_frac=0.2):
    """MSE regression (conditional means) of Y (n, k) on X; returns (net, mu, sd), held-out indices."""
    rng = np.random.default_rng(seed + 31)
    n = len(X); idx = rng.permutation(n); nv = int(n * val_frac); va, tr = idx[:nv], idx[nv:]
    mu = X[tr].mean(0); sd = X[tr].std(0) + 1e-6
    Xt = (X - mu) / sd
    Y = Y.reshape(n, -1)
    net = MLP([X.shape[1], hidden, hidden, Y.shape[1]], rng, out_scale=0.1); opt = Adam(net.params(), lr=1e-3, clip=5.0)
    bs = 256
    for ep in range(epochs):
        p = rng.permutation(tr)
        for j in range(0, len(p), bs):
            b = p[j:j + bs]
            out, hs = net.forward(Xt[b], cache=True)
            opt.step(net.backward(hs, (out - Y[b]) / len(b)))
    return (net, mu, sd), va


def labels_to_arrays(rec):
    X = np.concatenate([d['X'] for d in rec]); g = np.concatenate([d['g'] for d in rec])
    gs = np.concatenate([d['gs'] for d in rec]); aq = np.concatenate([d['aq'] for d in rec])
    gq = np.concatenate([d['gq'] for d in rec]); sq = np.concatenate([d['steps_q'] for d in rec])
    return dict(X=X, g=g, gs=gs, aq=aq, gq=gq, steps_q=sq)


def train_models(D, seed, gclip=60.0):
    """Student: E[g | o] (labels: K-sample privileged means). Router: E[d_accept], E[d_reject], E[d_query] and
    the query's work. d_accept = [-g]_+, d_reject = [g]_+, d_query = the charge of the query's actual decision."""
    X, g = D['X'], D['g']
    gc = np.clip(g, -gclip, gclip)
    student, va = fit(X, gc / 10.0, seed)
    da = np.maximum(-g, 0.0); dr = np.maximum(g, 0.0); dq = np.where(D['aq'] > 0.5, da, dr)
    Yr = np.stack([np.minimum(da, gclip) / 10.0, np.minimum(dr, gclip) / 10.0, np.minimum(dq, gclip) / 10.0,
                   D['steps_q'] / 1000.0], 1)
    router, va2 = fit(X, Yr, seed + 1)
    return student, router, dict(va=va, va_router=va2, da=da, dr=dr, dq=dq)
