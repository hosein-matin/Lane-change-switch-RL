"""Package Y, decision-charge audit (review point 4.4).
Usage: python an3/yaudit.py <dir with Vaudit_s*.pkl> [...]
Per proposal (the student drives): K_ref privileged rollout-pair samples (salt 1; the first 4 are the sweep's labels) and
16 deployable samples. Charges c(d, g) = |g| 1{d != [g >= 0]} against references from the first K samples, K in
{4, 16, 64, 128}, for the student, the critic (always accepts), deployable gates with 1/4/16 samples, and privileged
queries with m samples drawn from the samples K_ref/2+1.. (disjoint from the 128-sample reference)."""
import sys, glob, pickle, json, numpy as np
from scipy.stats import t as T

def ci(v):
    v = np.asarray(v); n = len(v)
    return float(T.ppf(.975, n - 1) * v.std(ddof=1) / np.sqrt(n)) if n > 1 else float('nan')

out = {}
for R in sys.argv[1:]:
    per_seed = []
    for f in sorted(glob.glob(f'{R}/Vaudit_s*.pkl')):
        x = pickle.load(open(f, 'rb')); A = x['audit']
        G = np.concatenate([d['gs'] for d in A]); Gq = np.concatenate([d['Gq'] for d in A])
        ds = np.concatenate([d['dec_student'] for d in A]).astype(bool)
        K = G.shape[1]; half = K // 2
        ch = lambda d, g: np.abs(g) * (d != (g >= 0))
        row = dict(n=len(G), K=K)
        for Kr in [4, 16, 64, half]:
            g = G[:, :Kr].mean(1)
            row[f'student_K{Kr}'] = ch(ds, g).mean(); row[f'critic_K{Kr}'] = ch(np.ones_like(ds), g).mean()
            for m in (1, 4, 16):
                row[f'mc{m}_K{Kr}'] = ch(Gq[:, :m].mean(1) >= 0, g).mean()
            row[f'absg_K{Kr}'] = np.abs(g).mean()
        g = G[:, :half].mean(1)
        for m in (1, 2, 4, 8, 16, 32):
            if half + m <= K:
                row[f'priv{m}_ref'] = ch(G[:, half:half + m].mean(1) >= 0, g).mean()
        # spread of a privileged sample per proposal (for Corollary 2)
        row['sigma_rms'] = float(np.sqrt((G.std(1, ddof=1) ** 2).mean())); row['sigma_med'] = float(np.median(G.std(1, ddof=1)))
        per_seed.append(row)
    if not per_seed:
        continue
    keys = per_seed[0].keys()
    agg = {k: dict(mean=float(np.mean([r[k] for r in per_seed])), ci=ci([r[k] for r in per_seed])) for k in keys}
    # rollouts a privileged query needs to match the student's charge (against the 128-sample reference), per seed
    need = []
    for r in per_seed:
        ms = [m for m in (1, 2, 4, 8, 16, 32) if f'priv{m}_ref' in r and r[f'priv{m}_ref'] <= r[f'student_K{per_seed[0]["K"] // 2}']]
        need.append(ms[0] if ms else np.inf)
    agg['priv_match_m'] = dict(per_seed=need)
    out[R] = agg
    print(f'== {R}: {len(per_seed)} seeds, {sum(r["n"] for r in per_seed)} proposals')
    for k, v in agg.items():
        if 'mean' in v:
            print(f'  {k:16s} {v["mean"]:8.3f} ± {v["ci"]:.3f}')
    print('  privileged rollouts matching the student, per seed:', need)
json.dump(out, open('aggV/yaudit.json', 'w'), indent=1)
