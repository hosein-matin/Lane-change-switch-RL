"""Fig. 1: gain over the student by uncertainty level. Run from the working folder after aggregate_S.py; writes aggV/fig_main.pdf."""
import pickle, glob, json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.stats import t as T
LV = ['0', '0.5', '1', '2']; U = [0, 0.5, 1, 2]
def load(R):
    return {u: [pickle.load(open(f, 'rb')) for f in sorted(glob.glob(f'{R}/u{u}/V_s*.pkl'))] for u in LV}
def diff(X, a, b):
    F = list(X[0]['test']['critic'].keys())
    G = lambda x, m: np.concatenate([x['test'][m][f]['G'] for f in F]).mean()
    d = np.array([G(x, a) - G(x, b) for x in X]); n = len(d)
    return d.mean(), T.ppf(.975, n - 1) * d.std(ddof=1) / np.sqrt(n)
D = {'two': load('backV2/results_v2'), 'three': load('backV3/results_v3')}
S = json.load(open('aggV/summary_S.json'))
plt.rcParams.update({'font.size': 7, 'axes.linewidth': 0.5, 'font.family': 'serif'})
STY = [('priv16', '#000000', '*', 'privileged gate, 16 rollouts'), ('mc16_K0', '#a63603', 's', 'prior-sampling gate, 16 rollouts'),
       ('mc4_K0', '#fd8d3c', 's', 'prior-sampling gate, 4 rollouts'), ('mc4_K1', '#7570b3', 'v', 'prior-sampling gate, 4 rollouts, 1-step delay'),
       ('band_K1', '#66a61e', 'D', 'cascade, 1-step delay')]
fig, ax = plt.subplots(1, 2, figsize=(3.5, 1.75))
for a, tag, title in [(ax[0], 'two', '(a) two lanes'), (ax[1], 'three', '(b) three lanes')]:
    for k, (m, col, mk, lab) in enumerate(STY):
        r = [diff(D[tag][u], m, 'student') for u in LV]; x = np.array(U) + (k - 2) * 0.03
        a.errorbar(x, [v[0] for v in r], yerr=[v[1] for v in r], color=col, marker=mk, ms=3, lw=0.8, capsize=1.2, label=lab)
    a.axhline(0, color='0.5', lw=0.5); a.set_xticks(U); a.set_xlabel(r'uncertainty level $\nu$'); a.set_title(title, fontsize=7.5); a.set_ylim(-1.7, 1.3)
ax[0].set_ylabel('gain over student')
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, loc='lower center', ncol=2, fontsize=5.4, frameon=False, bbox_to_anchor=(0.5, -0.02), handlelength=1.4, columnspacing=0.8)
fig.tight_layout(pad=0.3, rect=(0, 0.26, 1, 1), w_pad=0.5); fig.savefig('aggV/fig_main.pdf'); plt.close(fig)
