"""Samples a privileged MC query needs so that its expected decision charge matches a target, from the S labels.
Plug-in m ~ mean of K=4 privileged samples (shrunk), sigma ~ unbiased sd; Gaussian approximation of the sample mean."""
import pickle, glob, numpy as np, json, sys
from math import erf
Phi = np.vectorize(lambda z: 0.5 * (1 + erf(z / np.sqrt(2))))
out = {}
for R, tag, stud in [('backS2/results_s2', 'two', 0.2376), ('backS3/results_s3', 'three', 0.2077)]:
    G = []
    for f in sorted(glob.glob(f'{R}/evalS_s?.pkl')):
        x = pickle.load(open(f, 'rb'))
        for k in ['labels0', 'labels1']:
            G.append(np.asarray(x[k]['gs']))
    g = np.concatenate(G); K = g.shape[1]
    m = g.mean(1); s = g.std(1, ddof=1) + 1e-9
    # shrink |m| for its own sampling noise: E[mbar^2] = m^2 + s^2/K
    am = np.sqrt(np.maximum(m ** 2 - s ** 2 / K, 0))
    Ms = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
    ch = {M: float(np.mean(am * Phi(-np.sqrt(M) * am / s))) for M in Ms}
    # per-proposal M for P(wrong) <= 0.1 : sqrt(M) am/s >= 1.2816
    Mreq = (1.2816 * s / np.maximum(am, 1e-6)) ** 2
    hi = s > 20
    out[tag] = dict(charge=ch, student=stud, n=len(m), sd_median=float(np.median(s)), sd_mean=float(s.mean()), sd_rms=float(np.sqrt((s ** 2).mean())),
                    frac_hi=float(hi.mean()), share_absm_hi=float(am[hi].sum() / am.sum()),
                    Mreq_q=[float(np.quantile(Mreq, q)) for q in (0.5, 0.75, 0.9)])
    print(tag, {k: round(v, 3) for k, v in ch.items()}, 'student', stud)
    print('   sd median %.2f mean %.2f rms %.2f; frac sd>20 %.3f carrying %.2f of sum|m|; per-proposal M for P(wrong)<=.1: q50 %.1f q75 %.1f q90 %.1f' % (
        out[tag]['sd_median'], out[tag]['sd_mean'], out[tag]['sd_rms'], out[tag]['frac_hi'], out[tag]['share_absm_hi'], *out[tag]['Mreq_q']))
json.dump(out, open('bench/mreq.json', 'w'), indent=1)
