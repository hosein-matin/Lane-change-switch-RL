"""Package X: filters and guards of Theorems 1-2 against the held-input filter, frozen policies, nu = 1.
Usage: python an3/xfilt.py backX2/results_v2/u1 backX3/results_v3/u1   (any number of result dirs; prints and writes aggV/xfilt.json)"""
import sys, glob, pickle, json, numpy as np
from scipy.stats import t as T
VAR = [('base', 'hold'), ('kernel', 'hold'), ('kernel', 'const'), ('kernel', 'two')]
RULES = ['critic', 'student', 'band_K1', 'mc4_K0', 'priv16']
out = {}
for R in sys.argv[1:]:
    tag = R
    seeds = sorted(set(int(f.split('_s')[-1].split('.')[0]) for f in glob.glob(f'{R}/Vfilt_*_s*.pkl')))
    D = {}
    for fm, gm in VAR:
        for s in seeds:
            f = f'{R}/Vfilt_{fm}_{gm}_s{s}.pkl'
            try:
                D[(fm, gm, s)] = pickle.load(open(f, 'rb'))
            except FileNotFoundError:
                pass
    res = {}
    for fm, gm in VAR:
        for rule in RULES:
            rows = []
            for s in seeds:
                x = D.get((fm, gm, s)); b = D.get(('base', 'hold', s))
                if x is None or b is None or rule not in x['test'] or rule not in b['test']:
                    continue
                F = list(x['test'][rule].keys())
                cat = lambda d, k: np.concatenate([d[rule][f][k] for f in F])
                G = cat(x['test'], 'G'); Gb = cat(b['test'], 'G')
                fail = cat(x['test'], 'fail'); fc = cat(x['test'], 'fcause')
                rows.append(dict(G=G.mean(), dG=(G - Gb).mean(), fail=fail.mean(), front=((fc == 1) | (fc == 3)).mean(), rear=((fc == 2) | (fc == 3)).mean(),
                                 kout0=cat(x['test'], 'k_out0').mean(), kout=cat(x['test'], 'k_out').mean(), kact=cat(x['test'], 'k_act').mean(),
                                 grej=cat(x['test'], 'g_rej').mean(), nsw=cat(x['test'], 'n_sw').mean(), minf=cat(x['test'], 'min_front').min(),
                                 minr=cat(x['test'], 'min_rear').min(), col=cat(x['test'], 'collided').sum(), n=len(G),
                                 cut=cat(x['test'], 'n_cut_hard').mean()))
            if not rows:
                continue
            n = len(rows); a = {k: np.array([r[k] for r in rows]) for k in rows[0]}
            ci = lambda v: float(T.ppf(.975, n - 1) * v.std(ddof=1) / np.sqrt(n)) if n > 1 else float('nan')
            res[f'{fm}_{gm}/{rule}'] = dict(n_seeds=n, G=float(a['G'].mean()), dG=float(a['dG'].mean()), dG_ci=ci(a['dG']), dG_pos=int((a['dG'] > 0).sum()),
                                           fail_pct=float(100 * a['fail'].mean()), front_pct=float(100 * a['front'].mean()), rear_pct=float(100 * a['rear'].mean()),
                                           kout0_pct=float(100 * a['kout0'].mean()), kout_steps=float(a['kout'].mean()), kact_steps=float(a['kact'].mean()),
                                           grej=float(a['grej'].mean()), nsw=float(a['nsw'].mean()), min_front=float(a['minf'].min()), min_rear=float(a['minr'].min()),
                                           collisions=int(a['col'].sum()), runs=int(a['n'].sum()), cut=float(a['cut'].mean()))
    out[tag] = res
    print(f'== {R}  seeds {seeds}')
    print(f'{"variant/rule":28s} {"G":>7s} {"dG vs base":>14s} {"fail%":>7s} {"front%":>7s} {"rear%":>6s} {"out0%":>6s} {"kout":>6s} {"kact":>6s} {"grej":>6s} {"nsw":>5s} {"minF":>6s} {"col":>4s}')
    for k, v in res.items():
        print(f'{k:28s} {v["G"]:7.2f} {v["dG"]:+6.2f}±{v["dG_ci"]:4.2f} ({v["dG_pos"]:2d}/{v["n_seeds"]}) {v["fail_pct"]:7.2f} {v["front_pct"]:7.2f} {v["rear_pct"]:6.2f} {v["kout0_pct"]:6.2f} {v["kout_steps"]:6.2f} {v["kact_steps"]:6.2f} {v["grej"]:6.2f} {v["nsw"]:5.2f} {v["min_front"]:6.3f} {v["collisions"]:4d}')
json.dump(out, open('aggV/xfilt.json', 'w'), indent=1)
