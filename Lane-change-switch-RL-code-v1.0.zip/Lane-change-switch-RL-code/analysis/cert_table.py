"""Regenerate the Learn-then-Test certification table (Corollary 3) from per-seed calibration losses.
Usage: python an4/cert_table.py   -> aggV/cert_perseed.csv, explain/cert_counts.tex, prints summary.
Per seed and candidate: k = #{calibration scenarios with loss > eps}, U = Beta^{-1}(1 - gamma/J; k+1, n-k)."""
import pickle, glob, csv, numpy as np
from scipy.stats import beta as B
ROOT = '.'   # run from the folder that holds the collected results (see analysis/README.md)
NAMES = {'student': 'student', 'band': 'cascade', 'router_0.0': r'router, $\lambda=0$', 'router_0.5': r'router, $\lambda=0.5$',
         'router_2.0': r'router, $\lambda=2$', 'router_8.0': r'router, $\lambda=8$', 'mc4': 'prior-sampling gate, 4, measured latency'}
rows = []; agg = {}
for L in [2, 3]:
    for f in sorted(glob.glob(f'{ROOT}/backS{L}/results_s{L}/evalS_s[0-9].pkl')):
        s = int(f.split('_s')[-1][:-4]); d = pickle.load(open(f, 'rb'))['ltt']
        n, J, a, g = d['n'], d['K'], d['alpha'], d['beta']
        for eps in sorted(d['sel'], key=float):
            for c, x in d['cands'].items():
                k = int((np.asarray(x['L']) > float(eps)).sum())
                U = 1.0 if k >= n else float(B.ppf(1 - g / J, k + 1, n - k))
                assert k == d['sel'][eps][c]['r'] and abs(U - d['sel'][eps][c]['U']) < 1e-6, (L, s, eps, c)
                rows.append(dict(lanes=L, seed=s, candidate=c, eps=float(eps), n=n, J=J, gamma=g, alpha=a, k=k, U=round(U, 6), certified=int(U <= a)))
                agg.setdefault((L, float(eps), c), []).append((k, U, U <= a))
with open(f'{ROOT}/aggV/cert_perseed.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
kmax = max(k for k in range(500) if B.ppf(1 - 0.1 / 7, k + 1, 500 - k) <= 0.1)
print('threshold k <=', kmax, 'U(35), U(36) =', B.ppf(1 - 0.1 / 7, 36, 465), B.ppf(1 - 0.1 / 7, 37, 464))
epss = sorted({e for (_, e, _) in agg})
print('eps grid', epss, 'seeds', sorted({r['seed'] for r in rows}))
for L in [2, 3]:
    for e in epss:
        print(L, e, {c: (np.mean([k for k, _, _ in agg[(L, e, c)]]).round(1), round(float(np.mean([u for _, u, _ in agg[(L, e, c)]])), 3),
                         round(float(np.median([u for _, u, _ in agg[(L, e, c)]])), 3), sum(o for *_, o in agg[(L, e, c)]), len(agg[(L, e, c)])) for c in NAMES})
cell = lambda L, e, c: (lambda v: f"{np.mean([k for k,_,_ in v]):.1f} / {np.mean([u for _,u,_ in v]):.3f} / {sum(o for *_,o in v)}")(agg[(L, e, c)])
tex = [r"\subsection{Certification counts}\label{sec:certcounts}",
       r"Corollary~3 at $\nu=1$, $n=500$ calibration scenarios per seed, $\alpha=\gamma=0.1$, $J=7$ candidates frozen before calibration; a candidate is certified iff its number $k_j$ of scenarios with loss above $\varepsilon$ is at most $35$, i.e.\ iff the Clopper--Pearson bound $U_j=\mathrm{Beta}^{-1}(1-\gamma/J;\,k_j+1,\,n-k_j)$ is at most $\alpha$ ($U(35)=0.0992$, $U(36)=0.1015$). The tolerances $\varepsilon\in\{" + ",".join(f"{e:g}" for e in epss) + r"\}$ were fixed before calibration; each tolerance is a separate statement at confidence $1-\gamma$, not a simultaneous one. Entries: mean $k_j$ over the $10$ seeds / mean of the per-seed bounds $U_j$ / seeds certified. Every entry is computed from the per-seed counts, which are listed in Table~\ref{tab:certseed}. (Version~9 printed the median of the per-seed bounds next to the mean count, which made the two columns inconsistent; the certification decisions are unchanged.)",
       r"\begin{center}\footnotesize\setlength\tabcolsep{4pt}", r"\begin{tabular}{@{}lllll@{}}\toprule", r"& \multicolumn{2}{c}{two lanes} & \multicolumn{2}{c}{three lanes}\\",
       r"candidate & $\varepsilon=1$ & $\varepsilon=5$ & $\varepsilon=1$ & $\varepsilon=5$\\\midrule"]
for c, nm in NAMES.items():
    tex.append(nm + ' & ' + ' & '.join(cell(L, e, c) for L in [2, 3] for e in [1.0, 5.0]) + r'\\')
tex += [r"\bottomrule\end{tabular}\end{center}", "",
        r"\begin{table}[h]\centering\footnotesize\setlength\tabcolsep{2.5pt}\caption{Per-seed counts $k_j$ (certified iff $k_j\le35$).}\label{tab:certseed}",
        r"\begin{tabular}{@{}llrrrrrrrrrr@{}}\toprule lanes, $\varepsilon$ & candidate & \multicolumn{10}{c}{seed $0,\dots,9$}\\\midrule"]
for L in [2, 3]:
    for e in [1.0, 5.0]:
        for c, nm in NAMES.items():
            ks = [r['k'] for r in sorted(rows, key=lambda r: r['seed']) if r['lanes'] == L and r['eps'] == e and r['candidate'] == c]
            tex.append(f"{L}, {e:g} & {nm.replace(', measured latency','')} & " + ' & '.join((rf'\textbf{{{k}}}' if k <= 35 else str(k)) for k in ks) + r'\\')
        tex.append(r'\addlinespace')
tex[-1] = r'\bottomrule\end{tabular}\\[2pt]\raggedright Bold: certified. The full export (seed, candidate, $\varepsilon$, $n$, $J$, $\gamma$, $k$, $U$, pass) is in \texttt{cert\_perseed.csv}.\end{table}'
open(f'{ROOT}/aggV/cert_counts.tex', 'w').write('\n'.join(tex) + '\n')
