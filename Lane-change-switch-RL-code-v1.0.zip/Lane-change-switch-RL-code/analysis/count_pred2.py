import sys, os, pickle, numpy as np
os.environ.update(DUAL_LANE='1', DUAL_MODE='hold', CRITIC_NODIST='1')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, 'deterministic', 'code'))
from config import Cfg
from env import Env
from scenarios import load_set
from nn import MLP
from hl import run, make_rule_predictive
import evaluate as E
s = int(sys.argv[1]); R = 'backA/results_cn'
c = Cfg(); actor = MLP.load(f'{R}/ppo_s{s}/actor.pkl'); test, _ = E.build_sets(c)
rule = make_rule_predictive(actor, c, 'ca'); tot = 0; n = 0; G = []
for f in test:
    env = Env(c, len(test[f][0])); load_set(env, test[f][0]); env.done[:] = False
    rule.n_eval = 0; G.append(run(env, actor, rule, c)['G']); tot += rule.n_eval; n += env.B
print(s, 'decisions/ep', tot / n, 'G', np.concatenate(G).mean(), flush=True)
