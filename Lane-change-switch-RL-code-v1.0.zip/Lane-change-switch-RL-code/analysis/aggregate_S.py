"""Aggregation of the stochastic-model experiments (package S, and package T when present).
Usage: python aggregate_S.py RESULTS_S2 RESULTS_S3 OUTDIR"""
import pickle, json, os, sys, glob
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R2, R3, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(f'{OUT}/figs', exist_ok=True)
rng = np.random.default_rng(0); NB = 2000
S = list(range(10))


def boot_hw(D):
    Sn, N = D.shape; reps = np.empty(NB)
    for b in range(NB):
        cm = D[rng.integers(Sn, size=Sn)].mean(0); reps[b] = cm[rng.integers(N, size=N)].mean()
    lo, hi = np.percentile(reps, [2.5, 97.5]); return (hi - lo) / 2


def load(R):
    L = lambda t: [pickle.load(open(f'{R}/evalS_s{s}{t}.pkl', 'rb')) for s in S]
    m, mc, rf = L(''), L('_mc'), L('_ref')
    F = list(m[0]['test']['critic'].keys())
    src = {}
    for d in (m, mc, rf):
        for k in d[0]['test']:
            src[k] = d
    T = {}
    for mode in ['lat', 'acc', 'budget', 'shift']:
        fs = [f'{R}/T_{mode}_s{s}.pkl' for s in S]
        if all(os.path.exists(f) for f in fs):
            T[mode] = [pickle.load(open(f, 'rb')) for f in fs]
    return m, src, F, T


def arr(srcs, name, F, key='G'):
    return np.stack([np.concatenate([x['test'][name][f][key] for f in F]) for x in srcs[name]])


def stat(srcs, name, F, key):
    return float(np.mean([np.mean([x['stats'][name][f].get(key, 0) for f in F]) for x in srcs[name]]))


ROWS = [('stay', 'Stay', 'base'), ('mobil', 'MOBIL (nominal model)', 'base'), ('critic_c02', 'Critic, $\\bar c_0=c_0$', 'base'),
        ('critic', 'Critic, $\\bar c_0=10$', 'base'), ('critic_acc', 'Critic + measured accel.', 'base'),
        ('mc4_nolat', 'MC gate, 4 samples, no latency$^\\ast$', 'sim'), ('mc1', 'MC gate, 1 sample', 'sim'), ('mc4', 'MC gate, 4 samples', 'sim'),
        ('mc16', 'MC gate, 16 samples', 'sim'), ('rollall4', 'Full rollout, 4 samples', 'sim'),
        ('priv16', 'Privileged gate, 16 samples$^\\dagger$', 'ref'),
        ('student_r0', 'Student, teacher labels', 'ours'), ('student', 'Student, on-policy labels', 'ours'),
        ('band', 'Band cascade', 'ours'), ('router_2.0', 'Router, $\\lambda=2$', 'ours'), ('router_8.0', 'Router, $\\lambda=8$', 'ours')]


def summarize(R):
    m, src, F, T = load(R)
    B = arr(src, 'critic', F); out = {}
    for key, lab, grp in ROWS:
        G = arr(src, key, F); D = G - B
        r = dict(label=lab, group=grp, G=float(G.mean()), d=float(D.mean()), hw=float(boot_hw(D)) if key != 'critic' else 0.0,
                 se=float(D.mean(1).std(ddof=1) / np.sqrt(len(S))), pos=int((D.mean(1) > 0).sum()),
                 lc=float(arr(src, key, F, 'n_sw').mean()), hc=float(arr(src, key, F, 'n_cut_hard').mean()),
                 fail=float(arr(src, key, F, 'fail').mean()), q=stat(src, key, F, 'queries'), steps=stat(src, key, F, 'steps'))
        out[key] = r
    mf = min(min(arr(src, k, F, 'min_front').min(), arr(src, k, F, 'min_rear').min()) for k, _, _ in ROWS)
    col = int(sum(arr(src, k, F, 'collided').sum() for k, _, _ in ROWS)); nruns = int(sum(arr(src, k, F).size for k, _, _ in ROWS))
    ltt = {}
    for eps in m[0]['ltt']['sel']:
        ltt[eps] = {k: dict(r=float(np.mean([x['ltt']['sel'][eps][k]['r'] for x in m])), ok=int(sum(x['ltt']['sel'][eps][k]['ok'] for x in m)),
                            U=float(np.median([x['ltt']['sel'][eps][k]['U'] for x in m]))) for k in m[0]['ltt']['sel'][eps]}
    meanL = {k: float(np.mean([x['ltt']['cands'][k]['L'].mean() for x in m])) for k in m[0]['ltt']['cands']}
    diag = {k: float(np.mean([x['diag'][k] for x in m])) for k in m[0]['diag'] if k != 'route'}
    route = {k: {kk: float(np.mean([x['diag']['route'][k][kk] for x in m])) for kk in m[0]['diag']['route'][k]} for k in m[0]['diag']['route']}
    timing = m[0].get('timing')
    # package T
    TT = {}
    if 'lat' in T:
        lat = {}
        Bt = np.stack([np.concatenate([x['test']['critic'][f]['G'] for f in F]) for x in T['lat']])
        for name in T['lat'][0]['test']:
            G = np.stack([np.concatenate([x['test'][name][f]['G'] for f in F]) for x in T['lat']]); D = G - Bt
            lat[name] = dict(d=float(D.mean()), se=float(D.mean(1).std(ddof=1) / np.sqrt(len(S))), pos=int((D.mean(1) > 0).sum()))
        TT['lat'] = lat
    for mode in ['acc', 'budget', 'shift']:
        if mode in T:
            Bt = np.stack([np.concatenate([x['test']['critic'][f]['G'] for f in F]) for x in T[mode]]); res = {}
            for name in T[mode][0]['test']:
                G = np.stack([np.concatenate([x['test'][name][f]['G'] for f in F]) for x in T[mode]]); D = G - Bt
                hc = np.stack([np.concatenate([x['test'][name][f]['n_cut_hard'] for f in F]) for x in T[mode]])
                res[name] = dict(G=float(G.mean()), d=float(D.mean()), se=float(D.mean(1).std(ddof=1) / np.sqrt(len(S))),
                                 pos=int((D.mean(1) > 0).sum()), hc=float(hc.mean()))
            if mode == 'budget':
                res['n_labels'] = float(np.mean([x['n_labels'] for x in T[mode]]))
            if mode == 'shift':
                res['loss_eps'] = {e: float(np.mean([x['loss']['eps'][e]['student'] for x in T[mode]])) for e in [1.0, 2.0, 5.0]}
            TT[mode] = res
    return dict(rows=out, min_clear=float(mf), collisions=col, runs=nruns, ltt=ltt, meanL=meanL, diag=diag, route=route, timing=timing, T=TT)


A2, A3 = summarize(R2), summarize(R3)
json.dump(dict(two=A2, three=A3), open(f'{OUT}/summary_S.json', 'w'), indent=1, default=float)

# main table (both lane counts)
L = ['\\begin{tabular}{lrrrrrr}', '\\toprule',
     ' & \\multicolumn{3}{c}{Two lanes} & \\multicolumn{3}{c}{Three lanes} \\\\', '\\cmidrule(lr){2-4}\\cmidrule(lr){5-7}',
     'Rule & $\\Delta$ (95\\% CI) & $+$ & Sim. & $\\Delta$ (95\\% CI) & $+$ & Sim. \\\\', '\\midrule']
grp = None
for key, lab, g in ROWS:
    if grp is not None and g != grp: L.append('\\midrule')
    grp = g
    cells = []
    for A in (A2, A3):
        r = A['rows'][key]
        d = f"{r['G']:.1f}" if key == 'critic' else f"{r['d']:+.2f}$\\pm${r['hw']:.2f}"
        sim = '0' if r['steps'] == 0 and key != 'priv16' else (f"{r['steps']/1000:.1f}k" if r['steps'] >= 1000 else f"{r['steps']:.0f}")
        cells += [d, '---' if key == 'critic' else f"{r['pos']}", sim]
    L.append(f"{lab} & " + ' & '.join(cells) + ' \\\\')
L += ['\\bottomrule', '\\end{tabular}']
open(f'{OUT}/tab_stoch.tex', 'w').write('\n'.join(L) + '\n')

# certification table
names = [('student', 'Student'), ('band', 'Band cascade'), ('router_2.0', 'Router, $\\lambda=2$'), ('router_8.0', 'Router, $\\lambda=8$'), ('mc4', 'MC gate, 4 samples')]
L = ['\\begin{tabular}{lrrrrrr}', '\\toprule', ' & \\multicolumn{3}{c}{Two lanes} & \\multicolumn{3}{c}{Three lanes} \\\\',
     '\\cmidrule(lr){2-4}\\cmidrule(lr){5-7}', 'Candidate & $\\bar L$ & $\\varepsilon=1$ & $\\varepsilon=5$ & $\\bar L$ & $\\varepsilon=1$ & $\\varepsilon=5$ \\\\', '\\midrule']
for k, lab in names:
    c = []
    for A in (A2, A3):
        c += [f"{A['meanL'][k]:.2f}", f"{A['ltt']['1.0'][k]['ok']}/10" if '1.0' in A['ltt'] else f"{A['ltt'][1.0][k]['ok']}/10",
              f"{A['ltt']['5.0'][k]['ok']}/10" if '5.0' in A['ltt'] else f"{A['ltt'][5.0][k]['ok']}/10"]
    L.append(f'{lab} & ' + ' & '.join(c) + ' \\\\')
L += ['\\bottomrule', '\\end{tabular}']
open(f'{OUT}/tab_stoch_cert.tex', 'w').write('\n'.join(L) + '\n')
print(json.dumps({k: {kk: A[kk] for kk in ['min_clear', 'collisions', 'runs', 'timing']} for k, A in [('two', A2), ('three', A3)]}, indent=1))
for k, A in [('two', A2), ('three', A3)]:
    print(k, 'T keys', list(A['T'].keys()))

# ------------------------------------------------------------------ latency figure (package T)
plt.rcParams.update({'font.size': 7, 'axes.linewidth': 0.5, 'font.family': 'serif'})
if 'lat' in A2['T'] and 'lat' in A3['T']:
    fig, ax = plt.subplots(1, 2, figsize=(3.45, 1.75), sharey=False)
    Ks = [0, 1, 2, 4, 7]
    for a, (A, title) in zip(ax, [(A2, 'Two lanes'), (A3, 'Three lanes')]):
        lat = A['T']['lat']
        LO = -2.0
        for key, lab, col, mk in [('mc4', 'MC gate, 4 samples', '#d95f02', 's'), ('band', 'band cascade', '#1b9e77', 'D')]:
            y = np.array([lat[f'{key}_K{K}']['d'] for K in Ks]); e = [lat[f'{key}_K{K}']['se'] for K in Ks]
            x = np.array([100 * K for K in Ks]); yc = np.maximum(y, LO)
            a.errorbar(x, yc, yerr=np.where(y < LO, 0, e), color=col, marker=mk, ms=3, lw=0.9, capsize=1.5, label=lab)
            for xi, yi in zip(x, y):
                if yi < LO:
                    a.annotate(f'{yi:.1f}', (xi, LO), xytext=(0, 5), textcoords='offset points', ha='center', fontsize=5.5, color=col)
                    a.plot([xi], [LO], marker='v', color=col, ms=3.5)
        y16 = np.array([lat[f'mc16_K{K}']['d'] for K in [0, 1, 4]])
        a.plot([0, 100, 400], np.maximum(y16, LO), color='#d95f02', ls=':', marker='^', ms=3, lw=0.8, label='MC gate, 16 samples')
        a.axhline(lat['student']['d'], color='#1b9e77', ls='--', lw=0.8, label='student (no query)')
        a.axhline(A['rows']['priv16']['d'], color='k', ls='-.', lw=0.7, label='privileged reference')
        a.axhline(0, color='0.5', lw=0.5)
        a.set_title(title, fontsize=7.5); a.set_xlabel('query delay (ms)')
        a.set_ylim(LO - 0.15, 1.0)
        a.set_xticks([0, 100, 200, 400, 700]); a.set_xticklabels(['0', '100', '200', '400', '700'], fontsize=5.8)
    ax[0].set_ylabel('$\\Delta$ return vs. critic')
    h, l = ax[0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=3, fontsize=5.6, frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.tight_layout(pad=0.3, rect=(0, 0.17, 1, 1)); fig.savefig(f'{OUT}/figs/fig_latency.pdf'); plt.close(fig)

# package T table: matched critic, label budget, shift
if all(k in A2['T'] for k in ['acc', 'budget', 'shift']) and all(k in A3['T'] for k in ['acc', 'budget', 'shift']):
    L = ['\\begin{tabular}{lrrrr}', '\\toprule', ' & \\multicolumn{2}{c}{Two lanes} & \\multicolumn{2}{c}{Three lanes} \\\\',
         '\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}', 'Rule & $\\Delta$ & $+$ & $\\Delta$ & $+$ \\\\', '\\midrule']
    def row(lab, mode, key):
        c = []
        for A in (A2, A3):
            r = A['T'][mode][key]; c += [f"{r['d']:+.2f}$\\pm${r['se']:.2f}", f"{r['pos']}"]
        L.append(f'{lab} & ' + ' & '.join(c) + ' \\\\')
    L.append('\\multicolumn{5}{l}{\\emph{Critic with measured accelerations as base}} \\\\')
    row('\\quad critic + accel.', 'acc', 'critic_acc'); row('\\quad student on it', 'acc', 'student_acc'); row('\\quad privileged gate on it', 'acc', 'priv16_acc')
    L.append('\\multicolumn{5}{l}{\\emph{Label budget (share of the teacher labels)}} \\\\')
    for fr, lab in [('0.0625', '1/16'), ('0.25', '1/4'), ('1', 'all')]:
        row(f'\\quad student, {lab}', 'budget', f'student_f{fr}')
    L.append('\\multicolumn{5}{l}{\\emph{Shifted traffic (twice the hard braking, noisier leaders)}} \\\\')
    row('\\quad student', 'shift', 'student'); row('\\quad privileged gate', 'shift', 'priv16')
    L += ['\\bottomrule', '\\end{tabular}']
    open(f'{OUT}/tab_T.tex', 'w').write('\n'.join(L) + '\n')
    for k, A in [('two', A2), ('three', A3)]:
        print(k, 'shift loss rates', A['T']['shift']['loss_eps'])
