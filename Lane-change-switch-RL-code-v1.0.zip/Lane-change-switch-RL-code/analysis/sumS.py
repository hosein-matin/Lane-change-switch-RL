import pickle, numpy as np, json, sys
R = sys.argv[1]; S = range(10)
L = lambda t: [pickle.load(open(f'{R}/evalS_s{s}{t}.pkl', 'rb')) for s in S]
m, mc, rf = L(''), L('_mc'), L('_ref')
F = list(m[0]['test']['critic'].keys())
def get(name):
    src = mc if name in mc[0]['test'] else rf if name in rf[0]['test'] else m
    return src
def arr(name, key='G'):
    src = get(name); return np.stack([np.concatenate([x['test'][name][f][key] for f in F]) for x in src])
def stat(name, key):
    src = get(name); return float(np.mean([np.mean([x['stats'][name][f].get(key, 0) for f in F]) for x in src]))
B = arr('critic'); Bh = arr('critic', 'n_cut_hard')
names = ['stay','mobil','critic_c02','critic','critic_acc','student_r0','student','band'] + [k for k in m[0]['test'] if k.startswith('router')] + ['mc1','mc4','mc16','mc4_nolat','priv16','rollall4']
for n in names:
    G = arr(n); d = (G - B).mean(1); hc = arr(n, 'n_cut_hard').mean(); lc = arr(n, 'n_sw').mean(); fl = arr(n, 'fail').mean()
    print(f"{n:12s} G={G.mean():7.2f} d={d.mean():+.2f}±{d.std(ddof=1)/np.sqrt(10):.2f} pos={int((d>0).sum())}/10 LC={lc:.2f} hc={hc:.3f} fail={fl:.4f} q/ep={stat(n,'queries'):.2f} steps/ep={stat(n,'steps'):.0f} drop={stat(n,'late_drop'):.2f}")
mf = min(min(arr(n,'min_front').min(), arr(n,'min_rear').min()) for n in names); col = sum(arr(n,'collided').sum() for n in names)
print('min clearance', mf, 'collisions', col)
print('tuned', [ (x['tuned']['tau'], x['tuned']['delta']) for x in m])
dg = [x['diag'] for x in m]
print('diag', {k: round(float(np.mean([d[k] for d in dg])), 3) for k in dg[0] if k != 'route'})
for k in dg[0]['route']:
    print(' route', k, {kk: round(float(np.mean([d['route'][k][kk] for d in dg])), 3) for kk in dg[0]['route'][k]})
for eps in m[0]['ltt']['sel']:
    print('ltt eps', eps, {k: (round(float(np.mean([x['ltt']['sel'][eps][k]['r'] for x in m])),1), sum(x['ltt']['sel'][eps][k]['ok'] for x in m)) for k in m[0]['ltt']['sel'][eps]})
print('ltt queries', {k: round(float(np.mean([x['ltt']['cands'][k]['queries'] for x in m])),2) for k in m[0]['ltt']['cands']})
print('ltt meanL', {k: round(float(np.mean([x['ltt']['cands'][k]['L'].mean() for x in m])),2) for k in m[0]['ltt']['cands']})
print('timing', m[0].get('timing'))
