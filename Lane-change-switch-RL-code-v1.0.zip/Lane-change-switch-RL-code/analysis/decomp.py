import pickle, glob, json, numpy as np
C0, CF = 2.0, 200.0
out = {}
for tag, R in [('two', 'backV2/results_v2'), ('three', 'backV3/results_v3')]:
    out[tag] = {}
    for u in ['0', '0.5', '1', '2']:
        X = [pickle.load(open(f, 'rb')) for f in sorted(glob.glob(f'{R}/u{u}/V_s*.pkl'))]
        F = list(X[0]['test']['critic'].keys())
        def arr(x, m, k): return np.concatenate([x['test'][m][f][k] for f in F])
        rows = {}
        for m in X[0]['test']:
            dG, dsw, dfail = [], [], []
            for x in X:
                dG.append(arr(x, m, 'G').mean() - arr(x, 'critic', 'G').mean())
                dsw.append(arr(x, m, 'n_sw').mean() - arr(x, 'critic', 'n_sw').mean())
                dfail.append(arr(x, m, 'fail').mean() - arr(x, 'critic', 'fail').mean())
            dG, dsw, dfail = map(np.array, (dG, dsw, dfail))
            rows[m] = dict(dG=dG.mean(), switch=-C0 * dsw.mean(), fail=-CF * dfail.mean(), progress=(dG + C0 * dsw + CF * dfail).mean(),
                           progress_hw=2.262 * (dG + C0 * dsw + CF * dfail).std(ddof=1) / np.sqrt(len(dG)) if len(dG) == 10 else 2.093 * (dG + C0 * dsw + CF * dfail).std(ddof=1) / np.sqrt(len(dG)))
        out[tag][u] = rows
        print(f'== {tag} u={u}')
        for m in ['priv16', 'mc16_K0', 'mc4_K0', 'mc4_K1', 'student', 'band_K1', 'margin', 'stay']:
            r = rows[m]; print(f'  {m:9s} dG={r["dG"]:+6.2f} = progress {r["progress"]:+6.2f}±{r["progress_hw"]:.2f} + switch {r["switch"]:+5.2f} + fail {r["fail"]:+5.2f}')
json.dump(out, open('aggV/decomp.json', 'w'), indent=1, default=float)
