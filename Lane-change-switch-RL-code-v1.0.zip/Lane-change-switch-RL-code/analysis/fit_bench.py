import json, sys, numpy as np
B = json.load(open(sys.argv[1]))['results']
D = 0.1
out = {}
for L in (2, 3):
    R = [r for r in B if r['L'] == L]
    # t = (H/D)(k0 + k1 N) + t0   [microseconds]
    X = np.array([[r['H'] / D, r['H'] / D * r['N'], 1.0] for r in R]); y = np.array([r['us_per_rollout'] for r in R])
    k0, k1, t0 = np.linalg.lstsq(X, y, rcond=None)[0]
    pred = X @ [k0, k1, t0]; rel = np.max(np.abs(pred - y) / y)
    out[L] = dict(k0=k0, k1=k1, t0=t0, maxrel=rel, Nbal=k0 / k1)
    print(f'L={L}: k0={k0:.3f} us/step, k1={k1:.4f} us/(veh step), t0={t0:.1f} us, max rel err {rel:.1%}, N where terms equal {k0/k1:.0f}')
# requirement M = sigma^2/(4 eps^2); samples per 100 ms on P cores
for L, sig in [(2, 8.13), (3, 5.21)]:
    f = out[L]
    for eps in (1.0, 0.5, 0.25):
        M = sig ** 2 / (4 * eps ** 2)
        for bd1, lab in [(2, 'd=1'), (10, 'd=2,b=3')]:
            for H in (15.0, 30.0):
                budget = 4 * eps ** 2 * D * 1e6 / (sig ** 2 * bd1 * H / D)  # us per step per vehicle-term, P=1
                Ns = (budget - f['k0']) / f['k1']
                Pmin7 = M * bd1 * (H / D * (f['k0'] + f['k1'] * 7) + f['t0']) / (D * 1e6)
                print(f'L={L} sig={sig} eps={eps} M={M:.0f} {lab} H={H:g}: N*(P=1)={Ns:.0f}  cores needed at N=7: {Pmin7:.2f}')
json.dump({str(k): v for k, v in out.items()}, open(sys.argv[2], 'w'), indent=1)
