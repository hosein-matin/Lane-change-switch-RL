"""Value of simulation and recovered shares by uncertainty level (Table I, Fig. 1, Sec. V-B).
Paired by seed: for each pair (a, b), the mean over seeds of G(a) - G(b), the 95% t half-width, the number of seeds
with a positive difference and the number of seeds. Shares: mean gain over the critic divided by the privileged
gate's mean gain. Usage (from the working folder): python value_of_sim.py   -> aggV/value_of_sim.json"""
import glob, json, os, pickle, numpy as np
from scipy.stats import t as T

PAIRS = [('mc16_K0', 'student'), ('mc4_K0', 'student'), ('mc4_K1', 'student'), ('band_K1', 'student'),
         ('mc16_K0', 'band_K1'), ('priv16', 'student')]


def G(x, m):
    return np.concatenate([x['test'][m][f]['G'] for f in x['test'][m]]).mean()


out = {}
for tag, L in [('two', 2), ('three', 3)]:
    out[tag] = {}
    for u in ['0', '0.5', '1', '2']:
        D = [pickle.load(open(f, 'rb')) for f in sorted(glob.glob(f'backV{L}/results_v{L}/u{u}/V_s*.pkl'))]
        row = {}
        for a, b in PAIRS:
            v = np.array([G(x, a) - G(x, b) for x in D]); n = len(v)
            row[f'{a}-{b}'] = [round(float(v.mean()), 3), round(float(T.ppf(.975, n - 1) * v.std(ddof=1) / np.sqrt(n)), 3), int((v > 0).sum()), n]
        gain = lambda m: np.mean([G(x, m) - G(x, 'critic') for x in D])
        gp = gain('priv16')
        row['share'] = {'student': round(gain('student') / gp, 2), 'cascade': round(gain('band_K1') / gp, 2), 'mc16': round(gain('mc16_K0') / gp, 2)}
        out[tag][u] = row
os.makedirs('aggV', exist_ok=True)
json.dump(out, open('aggV/value_of_sim.json', 'w'), indent=1)
print(json.dumps(out['two']['1']))
