"""Aggregation of package V (uncertainty sweep) and benchmark B.
Usage: python aggregate_V.py RESULTS_V2 RESULTS_V3 OUTDIR [bench_compiled.json] [fit.json]"""
import pickle, json, os, sys, glob, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R2, R3, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
BENCH = sys.argv[4] if len(sys.argv) > 4 else None
os.makedirs(f'{OUT}/figs', exist_ok=True)
LEVELS = [0.0, 0.5, 1.0, 2.0]
METH = ['stay', 'critic', 'margin', 'student_r0', 'student', 'band_K1', 'mc1_K0', 'mc4_K0', 'mc16_K0', 'mc4_K1', 'priv16']


def sign_p(k, n):
    return sum(math.comb(n, i) for i in range(k, n + 1)) / 2 ** n


def tcrit(n):
    return {5: 2.571, 9: 2.262, 10: 2.228, 19: 2.093, 20: 2.086}.get(n - 1, 2.0)


def load_level(R, u):
    fs = sorted(glob.glob(f'{R}/u{u:g}/V_s*.pkl')); X = []
    for f in fs:
        x = pickle.load(open(f, 'rb'))
        if 'loss' in x and 'charges' in x:
            X.append(x)
        else:
            print('incomplete, skipped:', f)
    return X


def seedstat(X, name, F, key='G', base='critic'):
    v = np.array([np.concatenate([x['test'][name][f][key] for f in F]).mean() for x in X])
    b = np.array([np.concatenate([x['test'][base][f][key] for f in F]).mean() for x in X])
    d = v - b; n = len(d)
    return dict(mean=float(v.mean()), d=float(d.mean()), hw=float(tcrit(n) * d.std(ddof=1) / np.sqrt(n)) if n > 1 else 0.0,
                pos=int((d > 0).sum()), n=n, p=float(sign_p(int((d > 0).sum()), n)))


def summarize(R):
    S = {}
    for u in LEVELS:
        X = load_level(R, u)
        if not X:
            continue
        F = list(X[0]['test']['critic'].keys()); r = {}
        for mth in METH:
            if mth not in X[0]['test']:
                continue
            s = seedstat(X, mth, F)
            for key in ['n_sw', 'n_cut_hard', 'fail', 'hb_time', 'jerk_rms']:
                s[key] = float(np.mean([np.concatenate([x['test'][mth][f][key] for f in F]).mean() for x in X]))
            s['queries'] = float(np.mean([np.mean([x['stats'][mth][f].get('queries', 0) for f in F]) for x in X]))
            s['steps'] = float(np.mean([np.mean([x['stats'][mth][f].get('steps', 0) for f in F]) for x in X]))
            fc = np.concatenate([np.concatenate([x['test'][mth][f]['fcause'] for f in F]) for x in X])
            s['fail_front'] = float(np.mean(fc == 1)); s['fail_rear'] = float(np.mean(fc == 2)); s['fail_joint'] = float(np.mean(fc == 3))
            s['minclear'] = float(min(min(np.concatenate([x['test'][mth][f]['min_front'] for f in F]).min(),
                                          np.concatenate([x['test'][mth][f]['min_rear'] for f in F]).min()) for x in X))
            s['coll'] = int(sum(np.concatenate([x['test'][mth][f]['collided'] for f in F]).sum() for x in X))
            r[mth] = s
        ch = {k: float(np.mean([x['charges'][k] for x in X])) for k in X[0]['charges'] if k != 'mc'}
        ch['mc'] = {M: float(np.mean([x['charges']['mc'][M] for x in X])) for M in X[0]['charges']['mc']}
        loss = {}
        for nm in X[0]['loss']:
            for eps in [1.0, 2.0, 5.0]:
                loss[(nm, eps)] = float(np.mean([np.mean(x['loss'][nm] > eps) for x in X]))
        S[u] = dict(rows=r, charges=ch, loss={f'{k[0]}@{k[1]:g}': v for k, v in loss.items()}, n=len(X),
                    tuned=[x['tuned'] for x in X])
    # extras at u = 1
    xs = sorted(glob.glob(f'{R}/u1/Vbig_s*.pkl'))
    if xs:
        Xb = [pickle.load(open(f, 'rb')) for f in xs]; F = list(Xb[0]['test']['critic'].keys())
        S['big'] = seedstat(Xb, 'student', F); S['big']['labels'] = float(np.mean([len(x['labels0']['g']) + len(x['labels1']['g']) for x in Xb]))
    xs = sorted(glob.glob(f'{R}/u1/Vc0_s*.pkl'))
    if xs:
        Xc = [pickle.load(open(f, 'rb')) for f in xs]; F = list(Xc[0]['test']['critic_c010'].keys())
        best = [x['best'] for x in Xc]
        vals = {t: float(np.mean([np.concatenate([x['test'][f'critic_{t}'][f]['G'] for f in F]).mean() for x in Xc])) for t in ['c05', 'c010', 'c014']}
        sel = float(np.mean([np.concatenate([x['test'][f"critic_{x['best']}"][f]['G'] for f in F]).mean() for x in Xc]))
        S['c0'] = dict(best=best, test=vals, selected=sel)
    return S


A2, A3 = summarize(R2), summarize(R3)
json.dump(dict(two=A2, three=A3), open(f'{OUT}/summary_V.json', 'w'), indent=1, default=float)

# ---------- figure: return difference vs uncertainty, and offline decision charge vs samples
plt.rcParams.update({'font.size': 7, 'axes.linewidth': 0.5, 'font.family': 'serif'})
STY = {'student': ('#1b9e77', 'o', 'student'), 'band_K1': ('#66a61e', 'D', 'cascade (1-sample delay)'), 'margin': ('#7570b3', 'v', 'critic + margin'),
       'mc1_K0': ('#fdae6b', 's', 'MC gate, 1 sample$^\\ast$'), 'mc4_K0': ('#e6550d', 's', 'MC gate, 4 samples$^\\ast$'),
       'mc16_K0': ('#a63603', 's', 'MC gate, 16 samples$^\\ast$'), 'mc4_K1': ('#d95f02', 'x', 'MC gate, 4 samples, 1-sample delay'),
       'priv16': ('#000000', '*', 'privileged gate')}
fig, ax = plt.subplots(1, 3, figsize=(7.16, 2.0), gridspec_kw=dict(width_ratios=[1, 1, 1]))
for a, (A, title) in zip(ax[:2], [(A2, 'Two lanes'), (A3, 'Three lanes')]):
    us = [u for u in LEVELS if u in A]
    for mth, (col, mk, lab) in STY.items():
        y = [A[u]['rows'][mth]['d'] for u in us]; e = [A[u]['rows'][mth]['hw'] for u in us]
        y = np.maximum(y, -2.0)
        a.errorbar(us, y, yerr=e, color=col, marker=mk, ms=3, lw=0.8, capsize=1.2, label=lab)
    a.axhline(0, color='0.5', lw=0.5); a.set_xlabel('uncertainty level $u$'); a.set_title(title, fontsize=7.5)
    a.set_ylim(-2.1, None); a.set_xticks(us)
ax[0].set_ylabel('return diff. vs critic')
a = ax[2]
for A, ls, lab in [(A2, '-', 'two lanes'), (A3, '--', 'three lanes')]:
    for u, col in zip(LEVELS, ['#c6dbef', '#6baed6', '#2171b5', '#08306b']):
        if u not in A: continue
        ch = A[u]['charges']; Ms = sorted(int(k) for k in ch['mc'])
        a.plot(Ms, [ch['mc'][str(M)] if str(M) in ch['mc'] else ch['mc'][M] for M in Ms], ls=ls, color=col, marker='.', lw=0.8)
        a.axhline(ch['student'], color=col, ls=':', lw=0.6)
a.set_xscale('log', base=2); a.set_xlabel('samples per query $M$'); a.set_ylabel('charge per proposal')
a.set_title('Deployable query vs. student (dotted)', fontsize=7)
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, loc='lower center', ncol=4, fontsize=5.6, frameon=False, bbox_to_anchor=(0.36, -0.03))
fig.tight_layout(pad=0.3, rect=(0, 0.16, 1, 1)); fig.savefig(f'{OUT}/figs/fig_sweep.pdf'); plt.close(fig)

# ---------- table: sweep (selected rows)
rows = [('critic', 'Critic ($\\bar c_0=10$)'), ('margin', 'Critic + validated margin'), ('student', 'Student'), ('band_K1', 'Cascade, 1-sample delay'),
        ('mc4_K0', 'MC gate, 4 samples$^\\ast$'), ('mc16_K0', 'MC gate, 16 samples$^\\ast$'), ('mc4_K1', 'MC gate, 4 samples, 1-sample delay'),
        ('priv16', 'Privileged gate$^\\dagger$')]
for tag, A in [('two', A2), ('three', A3)]:
    us = [u for u in LEVELS if u in A]
    L = ['\\begin{tabular}{l' + 'r' * len(us) + '}', '\\toprule', 'Rule & ' + ' & '.join(f'$u={u:g}$' for u in us) + ' \\\\', '\\midrule']
    for k, lab in rows:
        cells = []
        for u in us:
            r = A[u]['rows'][k]
            cells.append(f"{r['mean']:.1f}" if k == 'critic' else f"{r['d']:+.2f}$\\pm${r['hw']:.2f} ({r['pos']})")
        L.append(f'{lab} & ' + ' & '.join(cells) + ' \\\\')
    L.append('\\midrule')
    L.append('$\\sigma$ of a sampled advantage & ' + ' & '.join(f"{A[u]['charges']['label_sd']:.1f}" for u in us) + ' \\\\')
    L.append('student charge / proposal & ' + ' & '.join(f"{A[u]['charges']['student']:.2f}" for u in us) + ' \\\\')
    L.append('query charge, $M=4$ / $16$ & ' + ' & '.join(f"{A[u]['charges']['mc'].get('4', A[u]['charges']['mc'].get(4)):.2f} / {A[u]['charges']['mc'].get('16', A[u]['charges']['mc'].get(16)):.2f}" for u in us) + ' \\\\')
    L += ['\\bottomrule', '\\end{tabular}']
    open(f'{OUT}/tab_sweep_{tag}.tex', 'w').write('\n'.join(L) + '\n')

# ---------- compute needed per uncertainty level, from the privileged labels and the fitted benchmark
from math import erf
_Phi = np.vectorize(lambda z: 0.5 * (1 + erf(z / np.sqrt(2))))
MS = [1, 2, 4, 8, 16, 32, 64, 128, 256]


def priv_curve(X):
    """Expected decision charge of a privileged M-sample query (Gaussian plug-in from the K-sample labels)."""
    g = np.concatenate([np.asarray(x[k]['gs']) for x in X for k in ('labels0', 'labels1')]); K = g.shape[1]
    m = g.mean(1); sd = g.std(1, ddof=1) + 1e-9; am = np.sqrt(np.maximum(m ** 2 - sd ** 2 / K, 0))
    return dict(curve={M: float(np.mean(am * _Phi(-np.sqrt(M) * am / sd))) for M in MS},
                sd_med=float(np.median(sd)), sd_rms=float(np.sqrt(np.mean(sd ** 2))))


FIT = sys.argv[5] if len(sys.argv) > 5 else None
comp = {}
for tag, R, A in [('two', R2, A2), ('three', R3, A3)]:
    comp[tag] = {}
    for u in LEVELS:
        X = load_level(R, u)
        if not X: continue
        pc = priv_curve(X); st = A[u]['charges']['student']
        Mm = next((M for M in MS if pc['curve'][M] <= st), None)
        comp[tag][u] = dict(pc, student=st, M_match=Mm)
if FIT and os.path.exists(FIT):
    fit = json.load(open(FIT)); D = 0.1
    for tag, Lk in [('two', '2'), ('three', '3')]:
        f = fit[Lk]
        for u, c in comp[tag].items():
            per = (15.0 / D) * (f['k0'] + f['k1'] * 7) / (D * 1e6)   # core-fraction of one rollout per sample
            c['cores_d1'] = None if c['M_match'] is None else c['M_match'] * 2 * per
            c['cores_d2'] = None if c['M_match'] is None else c['M_match'] * 10 * per
L = ['\\begin{tabular}{ll' + 'r' * 4 + '}', '\\toprule', 'Lanes & quantity & ' + ' & '.join(f'$u={u:g}$' for u in LEVELS) + ' \\\\', '\\midrule']
fmt = lambda v, f: '--' if v is None else f.format(v)
for tag in ('two', 'three'):
    C = comp[tag]
    row = lambda k, f: ' & '.join(fmt(C[u].get(k), f) if u in C else '--' for u in LEVELS)
    L.append(f'{tag} & $\\sigma$, median / rms & ' + ' & '.join(f"{C[u]['sd_med']:.1f} / {C[u]['sd_rms']:.0f}" if u in C else '--' for u in LEVELS) + ' \\\\')
    L.append(' & $M$ to match student & ' + row('M_match', '{:d}') + ' \\\\')
    L.append(' & cores, $d=1$ / $d=2$ & ' + ' & '.join(f"{fmt(C[u].get('cores_d1'), '{:.2f}')} / {fmt(C[u].get('cores_d2'), '{:.2f}')}" if u in C else '--' for u in LEVELS) + ' \\\\')
    L.append('\\midrule' if tag == 'two' else '\\bottomrule')
L.append('\\end{tabular}')
open(f'{OUT}/tab_compute.tex', 'w').write('\n'.join(L) + '\n')
json.dump({t: {str(u): v for u, v in c.items()} for t, c in comp.items()}, open(f'{OUT}/compute_V.json', 'w'), indent=1, default=str)

# ---------- failure causes per method and level
L = ['\\begin{tabular}{ll' + 'r' * 4 + '}', '\\toprule', 'Lanes & rule & ' + ' & '.join(f'$u={u:g}$' for u in LEVELS) + ' \\\\', '\\midrule']
for tag, A in [('two', A2), ('three', A3)]:
    for k, lab in [('critic', 'critic'), ('student', 'student'), ('mc4_K0', 'MC, 4'), ('priv16', 'privileged')]:
        cells = []
        for u in LEVELS:
            if u not in A or k not in A[u]['rows']: cells.append('--'); continue
            r = A[u]['rows'][k]
            cells.append(f"{100*r['fail']:.2f} ({100*r['fail_front']:.2f}/{100*r['fail_rear']:.2f}/{100*r['fail_joint']:.2f})")
        L.append(f'{tag} & {lab} & ' + ' & '.join(cells) + ' \\\\')
    L.append('\\midrule' if tag == 'two' else '\\bottomrule')
L.append('\\end{tabular}')
open(f'{OUT}/tab_fail.tex', 'w').write('\n'.join(L) + '\n')
print('ok', list(A2.keys()), list(A3.keys()))
