import pickle, numpy as np, sys, json
R = sys.argv[1]; S = range(10)
for mode in ['lat', 'acc', 'budget', 'shift']:
    X = [pickle.load(open(f'{R}/T_{mode}_s{s}.pkl', 'rb')) for s in S]
    F = list(X[0]['test']['critic'].keys())
    B = np.stack([np.concatenate([x['test']['critic'][f]['G'] for f in F]) for x in X])
    print('==', mode)
    for n in X[0]['test']:
        G = np.stack([np.concatenate([x['test'][n][f]['G'] for f in F]) for x in X]); d = (G - B).mean(1)
        hc = np.mean([np.concatenate([x['test'][n][f]['n_cut_hard'] for f in F]).mean() for x in X])
        lc = np.mean([np.concatenate([x['test'][n][f]['n_sw'] for f in F]).mean() for x in X])
        q = np.mean([np.mean([x['stats'][n][f].get('queries', 0) for f in F]) for x in X])
        mn = min(min(np.concatenate([x['test'][n][f]['min_front'] for f in F]).min(), np.concatenate([x['test'][n][f]['min_rear'] for f in F]).min()) for x in X)
        print(f'{n:16s} G={G.mean():7.2f} d={d.mean():+.2f}±{d.std(ddof=1)/np.sqrt(10):.2f} pos={int((d>0).sum())}/10 LC={lc:.2f} hc={hc:.3f} q/ep={q:.2f} minclear={mn:.3f}')
    if mode == 'shift':
        print('loss rates', {e: round(float(np.mean([x['loss']['eps'][e]['student'] for x in X])), 3) for e in [1.0, 2.0, 5.0]})
    if mode == 'acc':
        print('tau', [x['tau'] for x in X], 'labels', np.mean([len(x['labels0']['g']) + len(x['labels1']['g']) for x in X]))
    if mode == 'budget':
        print('n_labels', np.mean([x['n_labels'] for x in X]))
