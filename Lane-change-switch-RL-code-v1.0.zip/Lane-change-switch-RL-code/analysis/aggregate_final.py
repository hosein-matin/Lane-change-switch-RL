"""Final aggregation: two lanes (commitment model, 15 seeds) and three lanes (10 seeds); tables, figures, summary.
Paired differences to the validated critic; 95% two-way bootstrap half-widths (seeds x scenarios, paired)."""
import pickle, json, os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

A = 'backA/results_cn'; AC = 'backC/results_cn'
B3 = 'back3/results3'; B3C = 'backC/results3'
OUT = sys.argv[1] if len(sys.argv) > 1 else 'out'
os.makedirs(f'{OUT}/figs', exist_ok=True)
rng = np.random.default_rng(0); NB = 2000
KEYS = ['G', 'n_sw', 'n_cut_hard', 'hb_time', 'jerk_rms', 'fail', 'collided', 'min_front', 'min_rear']


def boot_hw(D):
    """D: (S, N) paired differences -> 95% half-width of the mean (two-way bootstrap)."""
    S, N = D.shape; reps = np.empty(NB)
    for b in range(NB):
        cm = D[rng.integers(S, size=S)].mean(0)
        reps[b] = cm[rng.integers(N, size=N)].mean()
    lo, hi = np.percentile(reps, [2.5, 97.5]); return (hi - lo) / 2


def load(path, seeds):
    return [pickle.load(open(path.format(s=s), 'rb')) for s in seeds]


def stack(per_seed_dicts, fams, key):
    """list over seeds of {family: metrics} -> (S, N) array."""
    return np.stack([np.concatenate([d[f][key] for f in fams]) for d in per_seed_dicts])


# ------------------------------------------------------------------ two lanes
S2 = list(range(15))
e2 = load(A + '/eval2_s{s}.pkl', S2); e3 = load(A + '/eval3_s{s}.pkl', S2); e5 = load(A + '/eval5_best_s{s}.pkl', S2)
e6 = load(A + '/eval6_s{s}.pkl', S2); e8 = load(A + '/eval8_best_s{s}.pkl', S2); em = load(A + '/evalmis_s{s}.pkl', S2)
c2 = load(AC + '/cert2_best_s{s}.pkl', S2)
F2 = list(e5[0]['test']['pib'].keys())
cnt = json.load(open('aggV/counts2.json'))   # measured decision counts (2 seeds) for gate/predictive
M2 = {  # name -> (per-seed family dicts, simulated decisions per episode or None, group)
    'Stay': ([x['test']['stay_only'] for x in e2], 0.0, 'base'),
    'MOBIL': ([x['test']['mobil'] for x in e2], 0.0, 'base'),
    'Critic, $\\bar c_0=c_0$': ([x['test']['greedy'] for x in e2], 0.0, 'base'),
    'Critic, validated $\\bar c_0$': ([x['test']['pib'] for x in e5], 0.0, 'base'),
    'Gate, forecast': ([x['test']['gate_ca'] for x in e5], cnt['gate_ca'], 'sim'),
    'Predictive, every decision': ([x['test']['predictive_ca'] for x in e3], cnt['predictive_ca'], 'sim'),
    'Predictive, $\\le$1/3\\,s, $T_h$=5\\,s': ([x['test']['pred_ca_T5_P3'] for x in e6],
                                             float(np.mean([np.mean(list(x['n_eval']['pred_ca_T5_P3'].values())) for x in e6])), 'sim'),
    'Exact gate (teacher)$^\\dagger$': ([x['test']['best_teacher_true'] for x in e8],
                                       float(np.mean([np.mean([x['rollouts']['best_teacher_true'][f]['rolled'] for f in F2]) for x in e8])), 'ref'),
    'Student, teacher labels': ([x['test']['best_student'] for x in e8], 0.0, 'ours'),
    'Cascade, teacher labels': ([x['test']['best_cascade_conf_ca'] for x in e8],
                                float(np.mean([np.mean([x['rollouts']['best_cascade_conf_ca'][f]['rolled'] for f in F2]) for x in e8])), 'ours'),
    'Student, on-policy labels': ([x['test'] for x in c2], 0.0, 'ours'),
    'Cascade, on-policy labels': ([x['cascade']['test'] for x in c2],
                                  float(np.mean([np.mean([x['cascade']['test'][f]['decisions'] for f in F2]) for x in c2])), 'ours'),
}
BASE = 'Critic, validated $\\bar c_0$'


def summarize(M, fams, base):
    Gb = stack(M[base][0], fams, 'G'); out = {}
    for name, (dd, sim, grp) in M.items():
        r = dict(sim=sim, group=grp)
        for k in KEYS:
            if k not in dd[0][fams[0]]:
                continue
            X = stack(dd, fams, k).astype(float)
            if k in ('min_front', 'min_rear'):
                r[k] = float(np.min(X)); continue
            r[k] = float(X.mean())
            if k in ('G', 'n_sw', 'n_cut_hard', 'hb_time', 'jerk_rms'):
                Xb = stack(M[base][0], fams, k).astype(float); D = X - Xb
                r['d_' + k] = float(D.mean()); r['hw_' + k] = float(boot_hw(D)) if name != base else 0.0
                if k == 'G':
                    r['pos'] = int((D.mean(1) > 0).sum()); r['n_seeds'] = int(D.shape[0])
                    r['se_seed'] = float(D.mean(1).std(ddof=1) / np.sqrt(D.shape[0]))
        out[name] = r
    return out


R2 = summarize(M2, F2, BASE)

# per-family returns (two lanes) for the main rules
FAMNAME = {'random': 'Random', 'equal': 'Equal lanes', 'faster_target': 'Faster target', 'fast_follower': 'Fast target follower',
           'leader_braking': 'Leader braking', 'squeeze': 'Front/rear conflict', 'late': 'Late advantage',
           'faster_adjacent': 'Faster adjacent', 'faster_far': 'Faster two lanes away'}


def per_family(M, fams, names, base):
    t = {}
    for f in fams:
        gb = np.stack([d[f]['G'] for d in M[base][0]])
        t[f] = {n: (float(np.stack([d[f]['G'] for d in M[n][0]]).mean()), float((np.stack([d[f]['G'] for d in M[n][0]]) - gb).mean()),
                    float(np.stack([d[f]['n_sw'] for d in M[n][0]]).mean())) for n in names}
    return t


# ------------------------------------------------------------------ mismatch (two lanes)
F2m = F2
MM = {
    'Stay': ([x['test']['stay_only'] for x in em], 0.0, 'base'),
    'MOBIL': ([x['test']['mobil'] for x in em], 0.0, 'base'),
    'Critic, validated $\\bar c_0$': ([x['test']['best_pib'] for x in em], 0.0, 'base'),
    'Gate, forecast': ([x['test']['best_gate_ca'] for x in em], float(np.mean([np.mean(list(x['rollouts']['best_gate_ca'].values())) for x in em])), 'sim'),
    'Predictive, every decision': ([x['test']['predictive_ca'] for x in em], float(np.mean([np.mean(list(x['rollouts']['predictive_ca'].values())) for x in em])), 'sim'),
    'Predictive, $\\le$1/3\\,s, $T_h$=5\\,s': ([x['test']['pred_ca_T5_P3'] for x in em], float(np.mean([np.mean(list(x['rollouts']['pred_ca_T5_P3'].values())) for x in em])), 'sim'),
    'Exact gate (oracle)$^\\ddagger$': ([x['test']['best_teacher_oracle'] for x in em], float(np.mean([np.mean(list(x['rollouts']['best_teacher_oracle'].values())) for x in em])), 'ref'),
    'Student, teacher labels': ([x['test']['best_student'] for x in em], 0.0, 'ours'),
    'Student, on-policy labels': ([x['test_mis'] for x in c2], 0.0, 'ours'),
    'Cascade, on-policy labels': ([x['cascade']['test_mis'] for x in c2],
                                  float(np.mean([np.mean([x['cascade']['test_mis'][f]['decisions'] for f in F2]) for x in c2])), 'ours'),
}
RM = summarize(MM, F2m, BASE)

# ------------------------------------------------------------------ three lanes
S3 = list(range(10))
l3 = load(B3 + '/eval3l_s{s}.pkl', S3); c3 = load(B3C + '/cert3_s{s}.pkl', S3)
F3 = list(l3[0]['test']['best_pib'].keys())
def ro3(name, key='decisions'):
    return float(np.mean([np.mean([x['rollouts'][name][f][key] for f in F3]) for x in l3]))
M3 = {
    'Stay': ([x['test']['stay_only'] for x in l3], 0.0, 'base'),
    'MOBIL': ([x['test']['mobil'] for x in l3], 0.0, 'base'),
    'Critic, $\\bar c_0=c_0$': ([x['test']['greedy'] for x in l3], 0.0, 'base'),
    'Critic, validated $\\bar c_0$': ([x['test']['best_pib'] for x in l3], 0.0, 'base'),
    'Gate, forecast': ([x['test']['best_gate_ca'] for x in l3], ro3('best_gate_ca'), 'sim'),
    'Predictive, every decision': ([x['test']['predictive_ca'] for x in l3], ro3('predictive_ca'), 'sim'),
    'Predictive, $\\le$1/3\\,s, $T_h$=5\\,s': ([x['test']['pred_ca_T5_P3'] for x in l3], ro3('pred_ca_T5_P3'), 'sim'),
    'Exact gate (teacher)$^\\dagger$': ([x['test']['best_teacher_true'] for x in l3], ro3('best_teacher_true'), 'ref'),
    'Student, teacher labels': ([x['test']['best_student'] for x in l3], 0.0, 'ours'),
    'Cascade, teacher labels': ([x['test']['best_cascade_conf_ca'] for x in l3], ro3('best_cascade_conf_ca'), 'ours'),
    'Student, on-policy labels': ([x['test'] for x in c3], 0.0, 'ours'),
    'Cascade, on-policy labels': ([x['cascade']['test'] for x in c3],
                                  float(np.mean([np.mean([x['cascade']['test'][f]['decisions'] for f in F3]) for x in c3])), 'ours'),
}
R3 = summarize(M3, F3, BASE)
rollouts3 = {n: ro3(k, 'rollouts') for n, k in [('teacher', 'best_teacher_true'), ('predictive', 'predictive_ca'), ('gate', 'best_gate_ca')]}

# ------------------------------------------------------------------ certificates
def cert_summary(C, mixkey='mix_check', miskey=None, testkey='test', fams=None):
    o = {}
    for a in ['0.05', '0.1', '0.2']:
        o[a] = dict(q_med=float(np.median([x['q'][a] for x in C])), q_max=float(np.max([x['q'][a] for x in C])),
                    q_zero=int(sum(x['q'][a] == 0 for x in C)),
                    cov=float(np.mean([x[mixkey][a]['cov_charge'] for x in C])), cov_min=float(np.min([x[mixkey][a]['cov_charge'] for x in C])),
                    covret=float(np.mean([x[mixkey][a]['cov_return'] for x in C])))
        if miskey:
            o[a]['cov_mis'] = float(np.mean([x[miskey][a]['cov_charge'] for x in C])); o[a]['cov_mis_min'] = float(np.min([x[miskey][a]['cov_charge'] for x in C]))
        o[a]['cov_fam_min'] = float(min(np.mean([(x[testkey][f]['C'] <= x['q'][a]).mean() for x in C]) for f in fams))
        o[a]['cov_fam'] = float(np.mean([np.mean([(x[testkey][f]['C'] <= x['q'][a]).mean() for f in fams]) for x in C]))
    o['pathwise'] = float(min(min(x[mixkey]['pathwise_bound_holds'] for x in C), 1.0))
    allC = np.concatenate([x['cal']['C'] for x in C]); o['cal_zero'] = float(np.mean(allC == 0))
    o['n_check'] = int(sum(len(x['mix']['C']) for x in C) + (sum(len(x['mix_mis']['C']) for x in C) if miskey else 0))
    o['n_cal'] = int(len(C[0]['cal']['C']))
    # wrong decisions on own proposals (rounds), excluding exact ties g == 0
    def wr(rec, tau=None):
        if len(rec) == 0: return 0.0
        nz = rec[:, 2] != 0
        return float(np.mean(((rec[:, 4] > 0.5) != (rec[:, 2] >= 0))[nz]))
    o['wrong_final'] = float(np.mean([wr(x['mix']['rec']) for x in C]))
    o['wrong_r1_prev'] = float(np.mean([x['rounds'][1]['wrong_prev_student'] for x in C]))
    o['wrong_r2_prev'] = float(np.mean([x['rounds'][2]['wrong_prev_student'] for x in C]))
    return o

CS2 = cert_summary(c2, 'mix_check', 'mix_mis_check', fams=F2)
CS3 = cert_summary(c3, 'mix_check', None, fams=F3)
pathwise_all = float(min(CS2['pathwise'], CS3['pathwise'], min(x['mix_mis_check']['pathwise_bound_holds'] for x in c2)))

# teacher-label coverage (per proposal) for the text
def prop_cov(E, fams):
    v = []; w = []
    for x in E:
        d = x['tuned']['delta_conf']
        for f, a in x['coverage'].items():
            if len(a): v.append((np.abs(a[:, 0] - a[:, 1]) <= d).mean()); w.append(len(a))
    return float(np.average(v, weights=w))
PC2 = prop_cov(e8, F2); PC3 = prop_cov(l3, F3)

# safety over all stored runs
def safety(paths):
    n = 0; mf = np.inf; mr = np.inf; col = 0; fl = []
    for p in paths:
        d = pickle.load(open(p, 'rb'))
        tests = [d.get('test', {})]
        if 'cascade' in d:
            tests += [{'cascade': d['cascade'][k]} for k in ('test', 'test_mis') if k in d['cascade']]
        for T in tests:
            for m in T.values():
                if not isinstance(m, dict): continue
                for f, x in m.items():
                    if isinstance(x, dict) and 'min_front' in x:
                        n += len(x['G']); mf = min(mf, float(np.min(x['min_front']))); mr = min(mr, float(np.min(x['min_rear'])))
                        col += int(np.sum(x.get('collided', 0))); fl.append(np.asarray(x.get('fail', np.zeros(len(x['G'])))))
    return dict(runs=n, min_front=mf, min_rear=mr, collisions=col, fail=float(np.concatenate(fl).mean()))
import glob
SAF2 = safety(sorted(glob.glob(A + '/eval*.pkl')))
SAF3 = safety(sorted(glob.glob(B3 + '/eval3l_s*.pkl')))
timing2 = json.load(open(A + '/timing.json')); timing3 = l3[0]['extra']['timing']
c0sel2 = [json.load(open(f'{A}/c0_select_s{s}.json')).get('best_c0') for s in S2]
c0sel3 = [x['best_c0'] for x in l3]

# ------------------------------------------------------------------ tables
def fmt(v, d=2): return f'{v:.{d}f}'

def main_table(R, path, names, comfort=True):
    L = ['\\begin{tabular}{lrrrrrr}', '\\toprule',
         'Rule & Return & $\\Delta$ & $+$ & LCs & Hard & Sim. \\\\',
         ' & & (95\\% CI) & seeds & /ep & cut-ins & /ep \\\\', '\\midrule']
    grp = None
    for n in names:
        r = R[n]
        if grp is not None and r['group'] != grp: L.append('\\midrule')
        grp = r['group']
        d = '---' if n == BASE else f"{r['d_G']:+.2f}$\\pm${r['hw_G']:.2f}"
        pos = '---' if n == BASE else f"{r['pos']}/{r['n_seeds']}"
        sim = '0' if r['sim'] == 0 else (f"{r['sim']:.1f}" if r['sim'] >= 1 else f"{r['sim']:.2f}")
        nm = f'\\textbf{{{n}}}' if r['group'] == 'ours' and 'on-policy' in n else n
        L.append(f"{nm} & {r['G']:.1f} & {d} & {pos} & {r['n_sw']:.2f} & {r['n_cut_hard']:.2f} & {sim} \\\\")
    L += ['\\bottomrule', '\\end{tabular}']
    open(path, 'w').write('\n'.join(L) + '\n')

names2 = list(M2.keys()); names3 = list(M3.keys())
main_table(R2, f'{OUT}/tab_two.tex', names2); main_table(R3, f'{OUT}/tab_three.tex', names3)

# mismatch table (compact)
L = ['\\begin{tabular}{lrrrr}', '\\toprule', 'Rule & Return & $\\Delta$ (95\\% CI) & $+$ seeds & Sim./ep \\\\', '\\midrule']
for n in MM:
    r = RM[n]; d = '---' if n == BASE else f"{r['d_G']:+.2f}$\\pm${r['hw_G']:.2f}"; pos = '---' if n == BASE else f"{r['pos']}/15"
    sim = '0' if r['sim'] == 0 else (f"{r['sim']:.1f}" if r['sim'] >= 1 else f"{r['sim']:.2f}")
    L.append(f"{n} & {r['G']:.1f} & {d} & {pos} & {sim} \\\\")
L += ['\\bottomrule', '\\end{tabular}']; open(f'{OUT}/tab_mis.tex', 'w').write('\n'.join(L) + '\n')

# certificate table
L = ['\\begin{tabular}{lrrrrrr}', '\\toprule',
     ' & \\multicolumn{3}{c}{Two lanes (15 seeds)} & \\multicolumn{3}{c}{Three lanes (10 seeds)} \\\\',
     '\\cmidrule(lr){2-4}\\cmidrule(lr){5-7}',
     '$1-\\alpha$ & 0.95 & 0.90 & 0.80 & 0.95 & 0.90 & 0.80 \\\\', '\\midrule']
row = lambda lab, f2, f3: L.append(lab + ' & ' + ' & '.join([f2(CS2[a]) for a in ['0.05', '0.1', '0.2']] + [f3(CS3[a]) for a in ['0.05', '0.1', '0.2']]) + ' \\\\')
row('$q_\\alpha$, median over seeds', lambda o: f"{o['q_med']:.1f}", lambda o: f"{o['q_med']:.1f}")
row('seeds with $q_\\alpha=0$', lambda o: f"{o['q_zero']}/15", lambda o: f"{o['q_zero']}/10")
row('coverage, new scenarios', lambda o: f"{o['cov']:.3f}", lambda o: f"{o['cov']:.3f}")
row('\\quad worst seed', lambda o: f"{o['cov_min']:.2f}", lambda o: f"{o['cov_min']:.2f}")
row('coverage, mismatch$^\\ast$', lambda o: f"{o['cov_mis']:.3f}", lambda o: '---')
row('coverage, worst family$^\\ast$', lambda o: f"{o['cov_fam_min']:.2f}", lambda o: f"{o['cov_fam_min']:.2f}")
L += ['\\bottomrule', '\\end{tabular}']; open(f'{OUT}/tab_cert.tex', 'w').write('\n'.join(L) + '\n')

# ------------------------------------------------------------------ figures
plt.rcParams.update({'font.size': 7, 'axes.linewidth': 0.5, 'font.family': 'serif'})
COL = {'base': '#7f7f7f', 'sim': '#d95f02', 'ref': '#000000', 'ours': '#1b9e77'}
PTS = [  # name, marker, short label, label offsets (2 lanes), (3 lanes)
    ('Student, on-policy labels', 'o', 'student', (5, 2), (5, 2)),
    ('Cascade, on-policy labels', 'D', 'cascade', (4, -9), (-12, 6)),
    ('Exact gate (teacher)$^\\dagger$', '*', 'exact gate', (-36, 2), (-36, 2)),
    ('Gate, forecast', 's', 'gate, forecast', (5, -4), (5, -4)),
    ('Predictive, every decision', '^', 'predictive', (-36, 3), (-36, -3)),
    ('Predictive, $\\le$1/3\\,s, $T_h$=5\\,s', 'v', 'predictive, periodic', (5, -3), (5, -3)),
]
fig, ax = plt.subplots(1, 3, figsize=(7.16, 2.1), gridspec_kw=dict(width_ratios=[1, 1, 1.05]))
for j, (R, title) in enumerate([(R2, 'Two lanes (15 seeds)'), (R3, 'Three lanes (10 seeds)')]):
    a = ax[j]
    for n, m, lab, o2, o3 in PTS:
        r = R[n]; x = max(r['sim'], 0.03); filled = 'teacher labels' not in n
        a.errorbar(x, r['d_G'], yerr=r['hw_G'], fmt=m, ms=4.5 if m != '*' else 7, color=COL[r['group']],
                   mfc=COL[r['group']] if filled else 'white', elinewidth=0.6, capsize=1.5, lw=0)
        a.annotate(lab, (x, r['d_G']), xytext=o2 if j == 0 else o3, textcoords='offset points', fontsize=5.5, color=COL[r['group']] if r['group'] != 'ref' else 'k')
    a.axhline(0, color='0.5', lw=0.5, ls='--'); a.set_xscale('log'); a.set_xlim(0.02, 90)
    a.set_xlabel('simulated decisions per episode'); a.set_title(title, fontsize=7.5)
    a.set_xticks([0.03, 0.1, 1, 10]); a.set_xticklabels(['0', '0.1', '1', '10'])
ax[0].set_ylabel('$\\Delta$ return vs. critic (95% CI)')
# comfort panel: relative change of hard cut-ins and lane changes vs the critic
a = ax[2]
rules = [('Gate, forecast', 'gate, forecast'), ('Predictive, every decision', 'predictive'), ('Exact gate (teacher)$^\\dagger$', 'exact gate'),
         ('Student, on-policy labels', 'student'), ('Cascade, on-policy labels', 'cascade')]
y = np.arange(len(rules))[::-1]
for k, (R, off, lab, hatch) in enumerate([(R2, 0.18, 'two lanes', None), (R3, -0.18, 'three lanes', '////')]):
    base_c = R[BASE]['n_cut_hard']
    v = [100 * R[n]['d_n_cut_hard'] / base_c for n, _ in rules]; e = [100 * R[n]['hw_n_cut_hard'] / base_c for n, _ in rules]
    cols = [COL[R[n]['group']] for n, _ in rules]
    a.barh(y + off, v, height=0.34, xerr=e, color=cols if k == 0 else 'white', edgecolor=cols, hatch=hatch, lw=0.6,
           error_kw=dict(elinewidth=0.5, capsize=1), label=lab)
a.set_yticks(y); a.set_yticklabels([l for _, l in rules], fontsize=6); a.axvline(0, color='0.5', lw=0.5)
a.set_xlabel('hard cut-ins vs. critic (%)'); a.set_title('Hard cut-ins', fontsize=7.5)
fig.tight_layout(pad=0.3, w_pad=0.5); fig.savefig(f'{OUT}/figs/fig_results.pdf'); plt.close(fig)

# ------------------------------------------------------------------ summary
summary = dict(two=R2, three=R3, mis=RM, cert2=CS2, cert3=CS3, pathwise_all=pathwise_all, propcov2=PC2, propcov3=PC3,
               safety2=SAF2, safety3=SAF3, timing2=timing2, timing3=timing3, c0sel2=c0sel2, c0sel3=c0sel3, rollouts3=rollouts3,
               fam2=per_family(M2, F2, ['Critic, validated $\\bar c_0$', 'Student, on-policy labels', 'Exact gate (teacher)$^\\dagger$', 'Predictive, every decision'], BASE),
               fam3=per_family(M3, F3, ['Critic, validated $\\bar c_0$', 'Student, on-policy labels', 'Exact gate (teacher)$^\\dagger$', 'Predictive, every decision'], BASE),
               counts2=cnt)
json.dump(summary, open(f'{OUT}/summary_final.json', 'w'), indent=1, default=float)
print(json.dumps({k: summary[k] for k in ['cert2', 'cert3', 'pathwise_all', 'propcov2', 'propcov3', 'safety2', 'safety3', 'c0sel2', 'c0sel3', 'rollouts3']}, indent=1, default=float))
