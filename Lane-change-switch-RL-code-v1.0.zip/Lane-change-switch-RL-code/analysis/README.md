# Analysis scripts

Run the scripts from a working folder that holds the collected results under the names below (copy or symlink the
runners' results folders there). Outputs go to `aggV/` (create it first) unless a script takes an output path.

| Name in the working folder | Produced by |
|---|---|
| `backA/results_cn` | `deterministic/run_two_lanes.py` (`deterministic/results_cn`) |
| `backC/results_cn` | the same folder (the certification jobs `cert2_*` write there) |
| `back3/results3`, `backC/results3` | `deterministic/run_three_lanes.py` (`deterministic/results3`; certification jobs `cert3_*`) |
| `backS2/results_s2`, `backS3/results_s3` | `stochastic_S/runS.py`, then package T in the same folder |
| `backV2/results_v2`, `backV3/results_v3` | `stochastic_V/runV.py --lanes 2/3` |

Packages W, W2, X, Y and Z are jobs of `runV.py` and write into `results_v2`/`results_v3`; where a script below
asks for a W, X, Y or Z folder, pass the same `results_vL` folder (or its `u1` subfolder where stated).

| Paper | Script | Command (two lanes; repeat with 3 for three lanes) |
|---|---|---|
| Sec. V-B, deterministic traffic (gate, student, cascade, MOBIL, pathwise check) | `aggregate_final.py` | `python aggregate_final.py out` (needs `aggV/counts2.json`, below) |
| Simulated decisions per episode of the deterministic gate and cascade | `count_gate2.py`, `count_pred2.py` | `python count_gate2.py <seed>`; the printed values go into `aggV/counts2.json` as `{"gate_ca": ..., "predictive_ca": ...}` |
| Table I, sweep numbers, value of simulation | `aggregate_V.py` | `python aggregate_V.py backV2/results_v2 backV3/results_v3 aggV [bench_compiled.json] [fit.json]` |
| Value of simulation and recovered shares by level | `value_of_sim.py` | `python value_of_sim.py` (writes `aggV/value_of_sim.json`) |
| Return decomposition (progress / switching / failures) | `decomp.py` | `python decomp.py` (writes `aggV/decomp.json`) |
| Fig. 1 | `fig_main.py` | `python fig_main.py` (after `aggregate_S.py`; writes `aggV/fig_main.pdf`) |
| Companion result tables (sweep, information split) | `tables_v6.py` | `python tables_v6.py` (after `aggregate_V.py`, `value_of_sim.py`, `decomp.py`, `aggregate_S.py`; writes `aggV/tables_v6.tex`) |
| Information split, packages W and Z | `zsplit.py` | `python zsplit.py backV2/results_v2 backV2/results_v2 backV2/results_v2` |
| Kernel filter and terminal-safe guards (package X) | `xfilt.py` | `python xfilt.py backV2/results_v2/u1 backV3/results_v3/u1` |
| Frozen-policy sweep and stale-state sensitivity (package Y) | `yfix_lat.py` | `python yfix_lat.py backV2/results_v2 backV2/results_v2/u1` |
| Decision-charge audit (package Y) | `yaudit.py` | `python yaudit.py backV2/results_v2/u1 backV3/results_v3/u1` |
| Decision charges on the student's held-out split | `recharge.py` | `python recharge.py aggV/recharge.json backV2/results_v2/u1 ...` |
| Certification (Corollary 3), companion Sec. 15.1 | `cert_table.py` | `python cert_table.py` (reads `backS2`, `backS3`; writes `aggV/cert_perseed.csv`, `aggV/cert_counts.tex`) |
| Package S and T summaries (MOBIL at ν = 1, routers, delay sweep, labels, shift) | `aggregate_S.py`, `sumS.py`, `sumT.py` | `python aggregate_S.py backS2/results_s2 backS3/results_s3 aggV`; `python sumS.py backS2/results_s2`; `python sumT.py backS2/results_s2` |
| Rollouts a privileged query needs (companion) | `mreq.py` | `python mreq.py` |
| Compute constants κ0, κ1 (Sec. V-C) | `fit_bench.py` | `python fit_bench.py bench_compiled.json fit.json` |
| Delay control: critic with its own acceptances delayed | `delay_control.py` | `python delay_control.py backV2/results_v2/u1 0 700` |

`data/cert_perseed.csv` in the repository root is the output of `cert_table.py` on the paper's runs.

Checked before release: on the paper's raw results, `aggregate_final.py`, `aggregate_S.py`, `aggregate_V.py`,
`value_of_sim.py`, `tables_v6.py` and `cert_table.py` reproduce the stored summaries and tables exactly.
