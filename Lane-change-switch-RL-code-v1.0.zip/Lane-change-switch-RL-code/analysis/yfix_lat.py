"""Package Y: fixed-policy uncertainty sweep (4.5) and sensing latency (4.3).
Usage: python an3/yfix_lat.py <results_v dir (with u0, u0.5, u1, u2)> <sweep results dir (V_s*.pkl at u1)>
Fixed: nu = 1 critic/student/gates, frozen, in traffic at nu in {0, 0.5, 2} (+ the sweep's own nu = 1 values).
Latency: query sees the state j substeps (j * 10 ms) before the decision instant; j = 0 is the sweep's K0 run."""
import sys, glob, pickle, json, os, numpy as np
from scipy.stats import t as T
R, RS = sys.argv[1], sys.argv[2]

def G(x, m):
    d = x['test'][m]; return np.concatenate([d[f]['G'] for f in d]).mean()

def paired(D, a, b):
    v = np.array([G(x, a) - G(x, b) for x in D if a in x['test'] and b in x['test']]); n = len(v)
    return (float(v.mean()), float(T.ppf(.975, n - 1) * v.std(ddof=1) / np.sqrt(n)), int((v > 0).sum()), n) if n > 1 else None

res = {'fixed': {}, 'lat': {}}
sweep = {int(f.split('_s')[-1][:-4]): pickle.load(open(f, 'rb')) for f in glob.glob(f'{RS}/V_s*.pkl')}
sweep = {s: x for s, x in sweep.items() if s < 10}
print('== fixed-policy sweep (gain over the student; over the critic for the student)')
for u in ['0', '0.5', '1', '2']:
    if u == '1':
        D = [sweep[s] for s in sorted(sweep)]
    else:
        D = [pickle.load(open(f, 'rb')) for f in sorted(glob.glob(f'{R}/u{u}/Vfix_s*.pkl'))]
    if not D:
        continue
    row = {}
    for m in ['mc4_K0', 'mc16_K0', 'mc4_K1', 'band_K1', 'priv16']:
        row[m + '-student'] = paired(D, m, 'student')
    row['student-critic'] = paired(D, 'student', 'critic')
    res['fixed'][u] = row
    print(f' nu={u:4s}', '  '.join(f'{k}: {v[0]:+.2f}±{v[1]:.2f} ({v[2]}/{v[3]})' for k, v in row.items() if v))
print('== sensing latency at nu = 1 (gain over the critic, paired with the sweep seed)')
for j in [0, 1, 3, 5]:
    row = {}
    for m in ['mc4_K0', 'mc16_K0', 'band_K0', 'priv16']:
        v = []
        for s, xs in sorted(sweep.items()):
            if j == 0:
                mm = 'band_K1' if m == 'band_K0' else m
                if mm in xs['test']:
                    v.append(G(xs, mm) - G(xs, 'critic'))
                continue
            f = f'{R}/u1/Vlat_j{j}_s{s}.pkl'
            if os.path.exists(f):
                x = pickle.load(open(f, 'rb'))
                if m in x['test']:
                    v.append(G(x, m) - G(xs, 'critic'))
        if len(v) > 1:
            v = np.array(v); row[m] = (float(v.mean()), float(T.ppf(.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))), int((v > 0).sum()), len(v))
    stu = np.array([G(xs, 'student') - G(xs, 'critic') for xs in sweep.values()])
    res['lat'][j] = row
    print(f' lag {10 * j:2d} ms', '  '.join(f'{k}: {v[0]:+.2f}±{v[1]:.2f} ({v[2]}/{v[3]})' for k, v in row.items()), f'  [student {stu.mean():+.2f}; j=0 band is the K1 cascade]')
json.dump(res, open(f'aggV/yfix_lat_{os.path.basename(R.rstrip("/"))}.json', 'w'), indent=1)
