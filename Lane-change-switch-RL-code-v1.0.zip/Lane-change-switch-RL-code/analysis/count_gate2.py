import sys, os, pickle, numpy as np
os.environ.update(DUAL_LANE='1', DUAL_MODE='hold', CRITIC_NODIST='1')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, 'deterministic', 'code'))
from config import Cfg
from env import Env
from scenarios import load_set
from nn import MLP
from hl import run, PredictionGate
import evaluate as E
s = int(sys.argv[1]); R = 'backA/results_cn'
c = Cfg(); actor = MLP.load(f'{R}/ppo_s{s}/actor.pkl'); qb = MLP.load(f'{R}/dqn_best_s{s}/q.pkl')
rho = pickle.load(open(f'{R}/eval5_best_s{s}.pkl', 'rb'))['tuned']['gate_rho']
test, _ = E.build_sets(c); rule = PredictionGate([qb], actor, c, rho=rho, model='ca'); n = 0; G = []
rule.stats = dict(proposals=0, accepted=0)
for f in test:
    env = Env(c, len(test[f][0])); load_set(env, test[f][0]); env.done[:] = False
    G.append(run(env, actor, rule, c)['G']); n += env.B
print(s, 'gate_ca proposals/ep', rule.stats['proposals'] / n, 'G', np.concatenate(G).mean(), flush=True)
