"""Companion result tables (sweep, information split W/W2, package T). Run from the working folder after aggregate_V.py,
value_of_sim.py, decomp.py and aggregate_S.py; writes aggV/tables_v6.tex. W_DIR/W2_DIR override where Vpost/Vpost2 results are
(default: the sweep folder backV<L>/results_v<L>, where runV.py writes them)."""
import os
import json, pickle, glob, numpy as np
from scipy.stats import t as T
out=[]
d=json.load(open('aggV/summary_V.json')); v=json.load(open('aggV/value_of_sim.json')); dec=json.load(open('aggV/decomp.json'))
U=['0.0','0.5','1.0','2.0']; NAMES=[('priv16','privileged gate (16 rollouts)'),('mc16_K0','prior-sampling gate, 16, no delay'),('mc4_K0','prior-sampling gate, 4, no delay'),('mc1_K0','prior-sampling gate, 1, no delay'),('mc4_K1','prior-sampling gate, 4, 1-step delay'),('student','student'),('student_r0','student, teacher labels only'),('band_K1','cascade, 1-step delay'),('margin','critic + validated margin'),('stay','always stay')]
for tag,title in [('two','Two lanes'),('three','Three lanes')]:
    out.append('\\subsection*{%s}\\begin{center}\\footnotesize\\setlength{\\tabcolsep}{3pt}\\resizebox{\\textwidth}{!}{\\begin{tabular}{@{}lrrrr@{}}\\toprule rule & $\\nu=0$ & $\\nu=0.5$ & $\\nu=1$ & $\\nu=2$\\\\\\midrule'%title)
    out.append('critic, mean return & '+' & '.join('%.1f'%d[tag][u]['rows']['critic']['mean'] for u in U)+'\\\\')
    out.append('critic, failures (\\%) & '+' & '.join('%.2f'%(100*d[tag][u]['rows']['critic']['fail']) for u in U)+'\\\\')
    out.append('critic, lane changes/episode & '+' & '.join('%.2f'%d[tag][u]['rows']['critic']['n_sw'] for u in U)+'\\\\\\midrule')
    for k,lab in NAMES:
        out.append(lab+' & '+' & '.join('$%+.2f\\pm%.2f$ (%d/%d)'%(d[tag][u]['rows'][k]['d'],d[tag][u]['rows'][k]['hw'],d[tag][u]['rows'][k]['pos'],d[tag][u]['rows'][k]['n']) for u in U)+'\\\\')
    out.append('\\midrule value of simulation (16, no delay $-$ student) & '+' & '.join('$%+.2f\\pm%.2f$ (%d/%d)'%tuple(v[tag][u]['mc16_K0-student']) for u in ['0','0.5','1','2'])+'\\\\')
    out.append('cascade $-$ student & '+' & '.join('$%+.2f\\pm%.2f$ (%d/%d)'%tuple(v[tag][u]['band_K1-student']) for u in ['0','0.5','1','2'])+'\\\\')
    out.append('\\midrule student: progress / switch / fail & '+' & '.join('%+.2f/%+.2f/%+.2f'%(dec[tag][u]['student']['progress'],dec[tag][u]['student']['switch'],dec[tag][u]['student']['fail']) for u in ['0','0.5','1','2'])+'\\\\')
    out.append('prior gate 16: progress / switch / fail & '+' & '.join('%+.2f/%+.2f/%+.2f'%(dec[tag][u]['mc16_K0']['progress'],dec[tag][u]['mc16_K0']['switch'],dec[tag][u]['mc16_K0']['fail']) for u in ['0','0.5','1','2'])+'\\\\')
    out.append('delayed gate 4: progress / switch / fail & '+' & '.join('%+.2f/%+.2f/%+.2f'%(dec[tag][u]['mc4_K1']['progress'],dec[tag][u]['mc4_K1']['switch'],dec[tag][u]['mc4_K1']['fail']) for u in ['0','0.5','1','2'])+'\\\\')
    out.append('\\bottomrule\\end{tabular}}\\end{center}')
# information split
out.append('\\subsection*{Information split (paired differences to the prior-sampling gate with 16 rollouts; 10 seeds)}\\begin{center}\\footnotesize\\setlength{\\tabcolsep}{3pt}\\resizebox{\\textwidth}{!}{\\begin{tabular}{@{}llrrr@{}}\\toprule lanes & query & $\\nu=0$ & $\\nu=1$ & $\\nu=2$\\\\\\midrule')
for tag,L in [('two','2'),('three','3')]:
    rows={}
    for u in ['0','1','2']:
        P={pickle.load(open(f,'rb'))['seed']:pickle.load(open(f,'rb')) for f in glob.glob(f'{os.environ.get("W_DIR", f"backV{L}/results_v{L}")}/u{u}/Vpost_s*.pkl')}
        P2={pickle.load(open(f,'rb'))['seed']:pickle.load(open(f,'rb')) for f in glob.glob(f'{os.environ.get("W2_DIR", f"backV{L}/results_v{L}")}/u{u}/Vpost2_s*.pkl')}
        V={pickle.load(open(f,'rb'))['seed']:pickle.load(open(f,'rb')) for f in glob.glob(f'backV{L}/results_v{L}/u{u}/V_s*.pkl')}
        seeds=sorted(P); F=list(V[seeds[0]]['test']['critic'].keys()); G=lambda x,m: np.concatenate([x['test'][m][f]['G'] for f in F]).mean()
        def pd(a,sa,b,sb):
            dd=np.array([G(sa[s],a)-G(sb[s],b) for s in seeds]); n=len(dd); return '$%+.2f\\pm%.2f$ (%d/%d)'%(dd.mean(),T.ppf(.975,n-1)*dd.std(ddof=1)/np.sqrt(n),(dd>0).sum(),n)
        for name,a,sa in [('true follower parameters','mcf16_K0',P),('true leader state and generator (target, segment end, pattern)','mcl16_K0',P),('identified follower parameters','mcid16_K0',P),('observable leader history (deployable)','mcidl16_K0',P2),('privileged gate','priv16',V),('student','student',V)]:
            rows.setdefault(name,[]).append(pd(a,sa,'mc16_K0',V))
    for name,cells in rows.items(): out.append(f'{tag} & {name} & '+' & '.join(cells)+'\\\\')
    out.append('\\midrule')
out.append('\\bottomrule\\end{tabular}}\\end{center}')
# T package
S=json.load(open('aggV/summary_S.json'))
out.append('\\subsection*{Package T at $\\nu=1$ (10 seeds): gain over the base critic, mean $\\pm$ one standard error, seeds positive}\\begin{center}\\footnotesize\\resizebox{\\textwidth}{!}{\\begin{tabular}{@{}lll@{}}\\toprule rule & two lanes & three lanes\\\\\\midrule')
for key,lab in [('lat','delay sweep'),('acc','information'),('budget','label budget'),('shift','shifted test traffic')]:
    ks=list(S['two']['T'][key].keys())
    for k in ks:
        a=S['two']['T'][key][k]; b=S['three']['T'][key].get(k)
        f=lambda r: '$%+.2f\\pm%.2f$ (%d/10)'%(r['d'],r['se'],r['pos']) if isinstance(r,dict) and 'd' in r else '--'
        if not isinstance(a,dict): continue
        out.append(f'{lab}: {k.replace("_","\\_")} & {f(a)} & {f(b)}\\\\')
    out.append('\\midrule')
out.append('\\bottomrule\\end{tabular}}\\end{center}')
open('aggV/tables_v6.tex','w').write('\n'.join(out)+'\n')
print(len(out))
