"""Control for the delay protocol: critic with its own acceptances delayed by K steps (no simulation)."""
import sys, os, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, 'stochastic_V', 'code'))
from config import Cfg; from env import Env; from nn import MLP; from hl import metrics
from hl3 import run3, make_rule_greedy3; from stochhl import GateS; from evalS import sets
RV = sys.argv[1]; seed = int(sys.argv[2]); n = int(sys.argv[3])
c = Cfg(); actor = MLP.load(f'{RV}/ppo_s{seed}/actor.pkl'); q = MLP.load(f'{RV}/dqnV_c010_s{seed}/q.pkl')
F, test, load_set, Smp = sets(c)
def env_smp(sd, n):
    e = Env(c, n); Smp(c, sd).reset_rows(e, range(n)); e.done[:] = False; return e
src = env_smp(777, n)
def run(rule):
    e = src.subset(np.arange(src.B)); e.done[:] = False; res = run3(e, actor, rule, c); m = metrics(e, res)
    return m['G'].mean(), m['n_sw'].mean(), m['fail'].mean(), getattr(rule, 'st', None)
G0, sw0, f0, _ = run(make_rule_greedy3(q)); print(f'critic           G={G0:.2f} sw={sw0:.3f} fail={f0:.4f}')
for K in [0, 1, 2]:
    G, sw, f, st = run(GateS(q, actor, c, 'accept', lat_k=K)); print(f'critic delayed K={K}  dG={G-G0:+.2f} sw={sw:.3f} fail={f:.4f} late_drop/ep={st.late_drop/n:.3f}')
for K in [0, 1]:
    G, sw, f, st = run(GateS(q, actor, c, 'mc', M=4, lat_k=K)); print(f'mc4 K={K}            dG={G-G0:+.2f} sw={sw:.3f} fail={f:.4f} queries/ep={st.queries/n:.2f}')
