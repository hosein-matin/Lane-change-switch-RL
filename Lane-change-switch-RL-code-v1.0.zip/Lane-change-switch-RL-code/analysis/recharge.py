"""Recompute offline decision charges with the student scored on its own held-out split.
Usage: python recharge.py OUT.json DIR [DIR ...]   (DIR: folders with V_s*.pkl or evalS_s?.pkl)"""
import sys, glob, json, pickle, time, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, 'stochastic_V', 'code'))
from stochhl import fit
from math import erf
Phi = np.vectorize(lambda z: 0.5 * (1 + erf(z / np.sqrt(2))))
res = {}
for d in sys.argv[2:]:
    fs = sorted(glob.glob(f'{d}/V_s*.pkl')) or sorted(glob.glob(f'{d}/evalS_s?.pkl'))
    R = []
    for f in fs:
        t0 = time.time(); x = pickle.load(open(f, 'rb'))
        D = {k: np.concatenate([x['labels0'][k], x['labels1'][k]]) for k in x['labels0']}
        seed = x['seed']; tau = x.get('tuned', {}).get('tau', 0.0)
        (net, mu, sd), va = fit(D['X'], np.clip(D['g'], -60, 60) / 10.0, seed)
        g = D['g'][va]; gh = net.forward((D['X'][va] - mu) / sd)[:, 0] * 10.0
        ch = lambda acc: float(np.mean(np.where(acc, np.maximum(-g, 0), np.maximum(g, 0))))
        r = dict(seed=seed, n=len(va), student=ch(gh > tau), student_tau0=ch(gh >= 0),
                 sign_student=float(np.mean((gh >= 0) == (g >= 0))), mae_student=float(np.mean(np.abs(gh - g))))
        if 'Gq' in D:
            Gq = D['Gq'][va]; r['mc'] = {M: ch(Gq[:, :M].mean(1) >= 0) for M in [1, 2, 4, 8, 16]}
        # privileged M-sample query, plug-in Gaussian, same split
        gs = D['gs'][va]; K = gs.shape[1]; m = gs.mean(1); s = gs.std(1, ddof=1) + 1e-9
        am = np.sqrt(np.maximum(m ** 2 - s ** 2 / K, 0))
        r['priv_plugin'] = {M: float(np.mean(am * Phi(-np.sqrt(M) * am / s))) for M in [1, 2, 4, 8, 16, 32, 64]}
        R.append(r); print(f, f'{time.time()-t0:.0f}s', {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items() if k not in ('mc', 'priv_plugin')}, flush=True)
    res[d] = R
json.dump(res, open(sys.argv[1], 'w'), indent=1)
