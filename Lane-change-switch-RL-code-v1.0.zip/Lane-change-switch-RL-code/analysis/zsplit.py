"""Package Z: separate the leader's current state (mcls) from its generator (mclg); compare with the grouped oracle (mcl,
package W) and the plain prior query (mc16, sweep). Gains over mc16_K0 of the same seed, 95% t-intervals.
Writes aggV/zsplit_<name of the Z folder>.json.
Usage: python zsplit.py <Z results_v dir> <W results_v dir> <V sweep results_v dir>"""
import sys, glob, os, json, pickle, numpy as np
RES = {}
from scipy.stats import t as T
RZ, RW, RV = sys.argv[1:4]
G = lambda x, m: np.concatenate([x['test'][m][f]['G'] for f in x['test'][m]]).mean()
for u in ['0', '1', '2']:
    rows = {k: [] for k in ['mcls', 'mclg', 'mcl', 'mcls-student', 'mclg-student', 'mcl-student', 'priv-mcl']}
    for s in range(10):
        fz = f'{RZ}/u{u}/Vpost3_s{s}.pkl'; fw = f'{RW}/u{u}/Vpost_s{s}.pkl'; fv = f'{RV}/u{u}/V_s{s}.pkl'
        if not (os.path.exists(fz) and os.path.exists(fv)):
            continue
        z = pickle.load(open(fz, 'rb')); v = pickle.load(open(fv, 'rb'))
        base = G(v, 'mc16_K0'); st = G(v, 'student')
        rows['mcls'].append(G(z, 'mcls16_K0') - base); rows['mclg'].append(G(z, 'mclg16_K0') - base)
        rows['mcls-student'].append(G(z, 'mcls16_K0') - st); rows['mclg-student'].append(G(z, 'mclg16_K0') - st)
        if os.path.exists(fw):
            w = pickle.load(open(fw, 'rb'))
            rows['mcl'].append(G(w, 'mcl16_K0') - base); rows['mcl-student'].append(G(w, 'mcl16_K0') - st)
            rows['priv-mcl'].append(G(v, 'priv16') - G(w, 'mcl16_K0'))
    out = []; RES[u] = {}
    for k, a in rows.items():
        a = np.array(a)
        if len(a) > 1:
            RES[u][k] = dict(mean=float(a.mean()), ci=float(T.ppf(.975, len(a) - 1) * a.std(ddof=1) / np.sqrt(len(a))), pos=int((a > 0).sum()), n=len(a))
            out.append(f'{k}: {a.mean():+.2f}±{T.ppf(.975, len(a) - 1) * a.std(ddof=1) / np.sqrt(len(a)):.2f} ({(a > 0).sum()}/{len(a)})')
    print(f'nu={u}: ' + ' | '.join(out))
os.makedirs('aggV', exist_ok=True)
json.dump(RES, open(f'aggV/zsplit_{os.path.basename(os.path.normpath(RZ))}.json', 'w'), indent=1)
